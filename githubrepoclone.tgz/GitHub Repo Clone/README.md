# GitHub Repo Clone (Splunk SOAR)

A Splunk SOAR app, built on the **Splunk SOAR SDK 3.x**, that takes a
GitHub repository URL and "clones" it into a brand-new SOAR container
by snapshotting the repo via the GitHub `zipball` API. Every file in
the repo is uploaded to the SOAR Vault, and one artifact is emitted per
file.

The new container is named **`<repo-name> - <UTC timestamp>`** so
repeated clones are easy to tell apart.

---

## Asset configuration

Only four fields - everything else has sensible defaults baked in.

| Field | Required | Default | Notes |
|---|---|---|---|
| `url` | **yes** | `https://github.com/splunk-soar-connectors/splunk.git` | Repository URL. Validated by Test Connectivity. Accepts the `.git`, `https://github.com/owner/repo`, or `git@github.com:owner/repo` forms. |
| `branch` | **yes** | `main` | Branch / tag / commit SHA. Validated by Test Connectivity. |
| `token` | no (sensitive) | — | GitHub PAT. Required for private repos; recommended for public to avoid the 60-req/hr anonymous limit. |
| `max_file_bytes` | yes | `10485760` (10 MiB) | Files larger than this are skipped. |

**Test Connectivity** verifies, in order:

1. The asset's `url` parses as a GitHub repo and `branch` is non-empty.
2. GitHub's API is reachable, and the supplied `token` (if any) is accepted.
3. The configured repository exists and is visible to the credentials supplied.
4. The configured branch exists on that repository.

A failure at any step produces a specific error message in the SOAR UI.

---

## Actions

### `clone repo`

Ad-hoc clone with optional overrides.

| Parameter | Type | Required | Default | Description |
|---|---|---|---|---|
| `repo_url` | string (`url`) | no | asset's `url` | Override the repository URL for this single run. |
| `branch` | string | no | asset's `branch` | Override the branch / tag / commit for this single run. |
| `container_label` | string | no | `events` | Label applied to the new container. |

Output:

| Field | Type | Description |
|---|---|---|
| `container_id` | int | The newly-created container's ID |
| `container_name` | string | `<repo> - <UTC timestamp>` |
| `file_count` | int | Number of files uploaded to the Vault |
| `repo` | string | `owner/repo` |
| `branch` | string | The branch that was actually cloned |
| `container_label` | string | The label applied to the new container |
| `vault_ids` | list[string] | One Vault ID per uploaded file |

### `on pull`

A thin wrapper that always uses the asset's configured `url` and
`branch`. Designed to be invoked from a **playbook** that fires on a
"pull" event - e.g. a webhook handler, a cron-style trigger, or a
manual button - so the action itself takes no URL parameters.

| Parameter | Type | Required | Default | Description |
|---|---|---|---|---|
| `container_label` | string | no | `events` | Label applied to the new container. |

Output is the same `CloneOutput` schema as `clone repo`.

---

## How it works

1. Parse `owner/repo` out of the URL.
2. `GET https://api.github.com/repos/{owner}/{repo}/zipball/{branch}`
   with the (optional) PAT in the `Authorization` header.
3. Create a new container with `soar.container.create(...)`.
4. Iterate every file in the zip, strip GitHub's
   `owner-repo-<sha>/` top-level folder, and:
   - Save the file content to the Vault via `soar.vault.add_attachment(...)`
     using a tmp file (works for both text and binary content).
   - Emit an artifact with `soar.artifact.create(...)` whose CEF
     contains the path, file size, vault ID, repo, and branch.
5. Return the list of vault IDs from the action handler.

The implementation is in [src/app.py](src/app.py).

---

## Build & install

This app uses the SDK 3.x packaging layout (`pyproject.toml` + `src/`).

```bash
# Generate the dependency lock file (only needed once or after editing
# pyproject.toml).
uv lock

# Build the .tgz package.
python3 package_build.py package build . -o githubrepoclone.tgz
```

The `package_build.py` wrapper patches the SDK's `DEPENDENCIES_TO_SKIP`
set so that Windows-only and email-parsing transitive dependencies that
SOAR (Linux) doesn't need are omitted from the bundle. Without it, the
build fails with `Could not find a suitable x86_64 wheel for
win-unicode-console`.

To install the resulting `.tgz`: SOAR UI -> **Apps** -> **Install App
from a file** -> upload `githubrepoclone.tgz`.

---

## Notes & limits

- The repo is fetched as a **single archive**, not via `git clone`, so
  no working `git` binary is required on the SOAR worker.
- Git history is **not** preserved - this is a content snapshot.
- Symlinks inside the repo are stored as text files containing the link
  target (zipball default).
- Binary files are uploaded as-is.
- Files larger than `max_file_bytes` are **skipped** and listed in the
  app log; everything else gets a vault entry and an artifact.
- File names in the Vault are flattened: `src/app.py` becomes
  `src__app.py` (Vault doesn't allow path separators). The original
  path is preserved on the artifact's `filePath` CEF field and in the
  Vault metadata as `original_path`.
