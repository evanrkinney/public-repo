"""GitHub Repo Clone - Splunk SOAR SDK app."""

import io
import os
import re
import tempfile
import zipfile
from datetime import datetime, timezone
from typing import Optional
from urllib.parse import urlparse

import requests

from soar_sdk.abstract import SOARClient
from soar_sdk.action_results import ActionOutput, OutputField
from soar_sdk.app import App
from soar_sdk.asset import AssetField, BaseAsset
from soar_sdk.logging import getLogger
from soar_sdk.params import Param, Params

logger = getLogger()
logger.info("githubrepoclone module loading.")


PLACEHOLDER_REPO_URL = "https://github.com/splunk-soar-connectors/splunk.git"


class Asset(BaseAsset):
    url: str = AssetField(
        description="GitHub repository URL.",
        default=PLACEHOLDER_REPO_URL,
    )
    branch: str = AssetField(
        description="Branch, tag, or commit SHA to clone.",
        default="main",
    )
    token: Optional[str] = AssetField(
        description="GitHub Personal Access Token (required for private repos).",
        sensitive=True,
        default=None,
    )
    max_file_bytes: int = AssetField(
        description="Skip files larger than this many bytes.",
        default=10 * 1024 * 1024,
    )


app = App(
    asset_cls=Asset,
    name="GitHub Repo Clone",
    appid="3b495ad8-1c95-49af-a64d-4314cf881209",
    app_type="information",
    product_vendor="GitHub",
    product_name="GitHub",
    publisher="Splunk SOAR Community",
    logo="logo.svg",
    logo_dark="logo_dark.svg",
    min_phantom_version="7.0.0",
    fips_compliant=False,
)


_GITHUB_API_BASE = "https://api.github.com"
_USER_AGENT = "splunk-soar-githubrepoclone/1.0"
_DEFAULT_CONTAINER_LABEL = "events"


def _parse_github_url(url: str) -> tuple[str, str]:
    """Accepts https URLs, ssh URLs, and bare ``owner/repo`` shorthand."""
    if not url:
        raise ValueError("Repository URL is empty.")
    s = url.strip()
    s = re.sub(r"\.git$", "", s)
    s = re.sub(r"^git@github\.com:", "https://github.com/", s)
    if "://" not in s and "/" in s and not s.startswith("/"):
        s = f"https://github.com/{s.lstrip('/')}"
    parsed = urlparse(s)
    parts = [p for p in (parsed.path or "").split("/") if p]
    if len(parts) < 2:
        raise ValueError(f"Cannot parse owner/repo from URL: {url!r}")
    return parts[0], parts[1]


def _gh_headers(token: Optional[str]) -> dict:
    headers = {
        "Accept": "application/vnd.github+json",
        "User-Agent": _USER_AGENT,
        "X-GitHub-Api-Version": "2022-11-28",
    }
    if token:
        headers["Authorization"] = f"Bearer {token}"
    return headers


def _download_repo_zip(owner: str, repo: str, ref: str, token: Optional[str]) -> bytes:
    api_url = f"{_GITHUB_API_BASE}/repos/{owner}/{repo}/zipball"
    if ref:
        api_url = f"{api_url}/{ref}"
    logger.info(f"GET {api_url}")
    resp = requests.get(
        api_url,
        headers=_gh_headers(token),
        allow_redirects=True,
        timeout=180,
    )
    if resp.status_code >= 400:
        raise RuntimeError(
            f"GitHub zipball download failed: HTTP {resp.status_code} "
            f"{resp.text[:300]}"
        )
    return resp.content


def _safe_vault_filename(inner_path: str) -> str:
    """SOAR Vault filenames cannot contain path separators - flatten."""
    flat = inner_path.replace("\\", "/").strip("/").replace("/", "__")
    flat = re.sub(r"[^A-Za-z0-9._\-]+", "_", flat)
    return flat or "file"


def _unpack_vault_add_result(result: object) -> str:
    """``phantom.vault.vault_add`` returns either a dict or a
    ``(success, message, vault_id)`` tuple depending on the SOAR build.
    The SDK shim only handles the dict form and crashes with
    ``'tuple' object has no attribute 'get'`` on the tuple form, so we
    call ``vault_add`` directly and handle both.
    """
    if isinstance(result, tuple):
        if len(result) >= 3:
            success, message, vault_id = result[0], result[1], result[2]
        else:
            raise RuntimeError(f"vault_add returned malformed tuple: {result!r}")
        if not success:
            raise RuntimeError(f"vault_add failed: {message}")
        return str(vault_id)
    if isinstance(result, dict):
        if not result.get("succeeded", True):
            raise RuntimeError(
                f"vault_add failed: {result.get('message', 'unknown')}"
            )
        vault_id = result.get("vault_id") or result.get("hash")
        if not vault_id:
            raise RuntimeError(f"vault_add returned no vault_id: {result!r}")
        return str(vault_id)
    raise RuntimeError(
        f"vault_add returned unexpected type {type(result).__name__}: {result!r}"
    )


def _save_vault_file(
    soar: SOARClient,
    container_id: int,
    file_name: str,
    content: bytes,
    inner_path: str,
) -> str:
    metadata = {"contains": ["github_repo_file"], "original_path": inner_path}
    tmp_dir = soar.vault.get_vault_tmp_dir()
    try:
        os.makedirs(tmp_dir, exist_ok=True)
    except (PermissionError, OSError):
        # Fall back for dev/test where /opt/phantom/vault/tmp doesn't exist.
        tmp_dir = tempfile.gettempdir()
    tmp_path = os.path.join(tmp_dir, file_name)
    with open(tmp_path, "wb") as fh:
        fh.write(content)
    try:
        try:
            from phantom.vault import vault_add as _phantom_vault_add
        except ImportError:
            _phantom_vault_add = None

        if _phantom_vault_add is not None:
            result = _phantom_vault_add(container_id, tmp_path, file_name, metadata)
            return _unpack_vault_add_result(result)

        return str(
            soar.vault.add_attachment(
                container_id=container_id,
                file_location=tmp_path,
                file_name=file_name,
                metadata=metadata,
            )
        )
    finally:
        try:
            os.remove(tmp_path)
        except OSError:
            pass


def _clone_to_container(
    soar: SOARClient,
    asset: Asset,
    repo_url: str,
    branch: str,
    requested_by: str,
    container_label: str,
    existing_container_id: Optional[int] = None,
) -> tuple[int, str, list[str], list[str]]:
    """When ``existing_container_id`` is set, uploads into it without
    creating a new container; otherwise creates a new container with
    ``container_label``. ``container_name`` in the return tuple is
    empty in the existing-container case.
    """
    owner, repo = _parse_github_url(repo_url)
    token = (asset.token or "").strip() or None
    effective_branch = (branch or "").strip()

    logger.info(
        f"Cloning {owner}/{repo} branch={effective_branch or '(default)'} "
        f"requested_by={requested_by}"
    )
    zip_bytes = _download_repo_zip(owner, repo, effective_branch, token)

    timestamp = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")

    if existing_container_id:
        container_id = int(existing_container_id)
        container_name = ""
        logger.info(
            f"Uploading into existing container id={container_id} "
            f"(no new container created)."
        )
    else:
        effective_label = (container_label or "").strip() or _DEFAULT_CONTAINER_LABEL
        container_name = f"{repo} - {timestamp}"
        soar.container.set_executing_asset(soar.get_asset_id())
        container_id = int(
            soar.container.create({
                "name": container_name,
                "description": (
                    f"Snapshot of {owner}/{repo} "
                    f"(branch={effective_branch or 'default'}) "
                    f"requested by {requested_by}."
                ),
                "label": effective_label,
                "severity": "low",
                "status": "new",
                "source_data_identifier": (
                    f"{owner}/{repo}@{effective_branch or 'default'}-{timestamp}"
                ),
                "run_automation": False,
                "tags": ["github", "repo-clone", f"{owner}/{repo}"],
            })
        )
        logger.info(
            f"Created container id={container_id} name={container_name!r}"
        )

    vault_ids: list[str] = []
    max_bytes = int(asset.max_file_bytes or 0)
    skipped: list[str] = []

    with zipfile.ZipFile(io.BytesIO(zip_bytes)) as zf:
        for member in zf.infolist():
            if member.is_dir():
                continue
            # Strip GitHub's "owner-repo-<sha>/" zipball wrapper folder.
            parts = member.filename.split("/", 1)
            inner_path = parts[1] if len(parts) > 1 else parts[0]
            if not inner_path:
                continue

            if max_bytes and member.file_size > max_bytes:
                logger.info(
                    f"Skipping oversized file {inner_path} "
                    f"({member.file_size} bytes > {max_bytes})."
                )
                skipped.append(inner_path)
                continue

            with zf.open(member) as fh:
                content = fh.read()

            file_name = _safe_vault_filename(inner_path)
            vault_id = _save_vault_file(
                soar, container_id, file_name, content, inner_path
            )
            vault_ids.append(vault_id)

            soar.artifact.create({
                "container_id": container_id,
                "name": inner_path,
                "label": "repo file",
                "type": "file",
                "severity": "low",
                "cef": {
                    "fileName": os.path.basename(inner_path) or file_name,
                    "filePath": inner_path,
                    "vaultId": vault_id,
                    "fileSize": member.file_size,
                    "repo": f"{owner}/{repo}",
                    "branch": effective_branch or "default",
                },
                "source_data_identifier": f"{owner}/{repo}/{inner_path}",
                "run_automation": False,
            })

    logger.info(
        f"Clone complete: {len(vault_ids)} files uploaded, "
        f"{len(skipped)} skipped (size limit), container_id={container_id}."
    )
    return container_id, container_name, vault_ids, skipped


@app.test_connectivity()
def test_connectivity(soar: SOARClient, asset: Asset):
    logger.info("=> ACTION START: test_connectivity")

    url = (asset.url or "").strip()
    if not url:
        raise RuntimeError(
            "Asset 'url' is required and must be a GitHub repository URL "
            f"(e.g. {PLACEHOLDER_REPO_URL})."
        )
    try:
        owner, repo = _parse_github_url(url)
    except ValueError as exc:
        raise RuntimeError(f"Asset 'url' is invalid: {exc}") from exc

    branch = (asset.branch or "").strip()
    if not branch:
        raise RuntimeError("Asset 'branch' is required.")

    token = (asset.token or "").strip() or None

    rate_resp = requests.get(
        f"{_GITHUB_API_BASE}/rate_limit",
        headers=_gh_headers(token),
        timeout=30,
    )
    if rate_resp.status_code >= 400:
        raise RuntimeError(
            f"GitHub API unreachable or token rejected: "
            f"HTTP {rate_resp.status_code} {rate_resp.text[:200]}"
        )
    core = (rate_resp.json().get("resources") or {}).get("core") or {}
    logger.info(
        f"GitHub API reachable. Auth={'token' if token else 'anonymous'}, "
        f"rate_limit={core.get('limit')}, remaining={core.get('remaining')}"
    )

    repo_resp = requests.get(
        f"{_GITHUB_API_BASE}/repos/{owner}/{repo}",
        headers=_gh_headers(token),
        timeout=30,
    )
    if repo_resp.status_code == 404:
        raise RuntimeError(
            f"Configured repository {owner}/{repo} not found "
            "(or not visible to the supplied token, if private)."
        )
    if repo_resp.status_code >= 400:
        raise RuntimeError(
            f"Repository check failed: HTTP {repo_resp.status_code} "
            f"{repo_resp.text[:200]}"
        )
    repo_meta = repo_resp.json()
    logger.info(
        f"Repository {owner}/{repo} OK: "
        f"private={repo_meta.get('private')}, "
        f"default_branch={repo_meta.get('default_branch')!r}"
    )

    branch_resp = requests.get(
        f"{_GITHUB_API_BASE}/repos/{owner}/{repo}/branches/{branch}",
        headers=_gh_headers(token),
        timeout=30,
    )
    if branch_resp.status_code == 404:
        raise RuntimeError(
            f"Branch {branch!r} not found on {owner}/{repo}. "
            f"Repository default branch is "
            f"{repo_meta.get('default_branch')!r}."
        )
    if branch_resp.status_code >= 400:
        raise RuntimeError(
            f"Branch check failed: HTTP {branch_resp.status_code} "
            f"{branch_resp.text[:200]}"
        )

    logger.info("<= ACTION OK: test_connectivity")
    soar.set_message("Test Connectivity Passed")


class CloneRepoOutput(ActionOutput):
    container_id: int = OutputField(
        column_name="Container ID", example_values=[42]
    )
    file_count: int = OutputField(
        column_name="Files Uploaded", example_values=[128]
    )
    skipped_count: int = OutputField(
        column_name="Files Skipped", example_values=[2]
    )
    repo: str = OutputField(
        column_name="Repository", example_values=["splunk-soar-connectors/splunk"]
    )
    branch: str = OutputField(
        column_name="Branch", example_values=["main"]
    )
    vault_ids: list[str] = OutputField(column_name="Vault IDs")
    skipped_paths: list[str] = OutputField(column_name="Skipped Paths")


class OnPullOutput(ActionOutput):
    container_id: int = OutputField(
        column_name="Container ID", example_values=[42]
    )
    container_name: str = OutputField(
        column_name="Container Name",
        example_values=["splunk - 2026-05-08 14:32:01 UTC"],
    )
    file_count: int = OutputField(
        column_name="Files Uploaded", example_values=[128]
    )
    skipped_count: int = OutputField(
        column_name="Files Skipped", example_values=[2]
    )
    repo: str = OutputField(
        column_name="Repository", example_values=["splunk-soar-connectors/splunk"]
    )
    branch: str = OutputField(
        column_name="Branch", example_values=["main"]
    )
    container_label: str = OutputField(
        column_name="Container Label", example_values=["events"]
    )
    vault_ids: list[str] = OutputField(column_name="Vault IDs")
    skipped_paths: list[str] = OutputField(column_name="Skipped Paths")


class CloneRepoParams(Params):
    repo_url: Optional[str] = Param(
        description="GitHub repo URL. Defaults to the asset's url.",
        cef_types=["url"],
        default=None,
    )
    branch: Optional[str] = Param(
        description="Branch, tag, or commit. Defaults to the asset's branch.",
        default=None,
    )


@app.action(
    name="clone repo",
    identifier="clone_repo",
    description=(
        "Clone a GitHub repository into the *executing* container "
        "(the container the playbook is running in). Uploads every file "
        "to the Vault and emits one artifact per file. Does not create a "
        "new container - use 'on pull' for that."
    ),
    action_type="generic",
    read_only=False,
)
def clone_repo(
    params: CloneRepoParams, soar: SOARClient, asset: Asset
) -> CloneRepoOutput:
    repo_url = (params.repo_url or "").strip() or (asset.url or "").strip()
    if not repo_url:
        raise ValueError(
            "No repository URL: pass repo_url to the action or set "
            "'url' on the asset."
        )
    branch = (params.branch or "").strip() or (asset.branch or "").strip()
    if not branch:
        raise ValueError(
            "No branch: pass branch to the action or set 'branch' on the asset."
        )

    executing_container_id = int(soar.get_executing_container_id() or 0)
    if not executing_container_id:
        raise ValueError(
            "'clone repo' must be invoked from a playbook that has a "
            "container context. Use the 'on pull' action if you want a "
            "new container created instead."
        )

    logger.info(
        f"=> ACTION START: clone_repo url={repo_url} branch={branch!r} "
        f"container_id={executing_container_id} (existing)"
    )
    container_id, _container_name, vault_ids, skipped = _clone_to_container(
        soar, asset, repo_url, branch,
        requested_by="clone_repo",
        container_label="",
        existing_container_id=executing_container_id,
    )
    owner, repo = _parse_github_url(repo_url)
    logger.info(
        f"<= ACTION OK: clone_repo container_id={container_id} "
        f"uploaded={len(vault_ids)} skipped={len(skipped)}"
    )
    return CloneRepoOutput(
        container_id=container_id,
        file_count=len(vault_ids),
        skipped_count=len(skipped),
        repo=f"{owner}/{repo}",
        branch=branch,
        vault_ids=vault_ids,
        skipped_paths=skipped,
    )


class OnPullParams(Params):
    container_label: Optional[str] = Param(
        description="Container label.",
        default=_DEFAULT_CONTAINER_LABEL,
    )


@app.action(
    name="on pull",
    identifier="on_pull",
    description=(
        "Clone the asset's configured url / branch into a new SOAR "
        "container. Takes no URL parameters - intended to be invoked "
        "from a playbook on a 'pull' trigger."
    ),
    action_type="generic",
    read_only=False,
)
def on_pull(
    params: OnPullParams, soar: SOARClient, asset: Asset
) -> OnPullOutput:
    repo_url = (asset.url or "").strip()
    branch = (asset.branch or "").strip()
    if not repo_url:
        raise ValueError(
            "Asset 'url' is required for 'on pull'. Configure it in the "
            "asset settings."
        )
    if not branch:
        raise ValueError(
            "Asset 'branch' is required for 'on pull'. Configure it in "
            "the asset settings."
        )
    container_label = (params.container_label or "").strip() or _DEFAULT_CONTAINER_LABEL

    logger.info(
        f"=> ACTION START: on_pull url={repo_url} branch={branch!r} "
        f"label={container_label!r}"
    )
    container_id, container_name, vault_ids, skipped = _clone_to_container(
        soar, asset, repo_url, branch,
        requested_by="on_pull", container_label=container_label,
    )
    owner, repo = _parse_github_url(repo_url)
    logger.info(
        f"<= ACTION OK: on_pull container_id={container_id} "
        f"uploaded={len(vault_ids)} skipped={len(skipped)}"
    )
    return OnPullOutput(
        container_id=container_id,
        container_name=container_name,
        file_count=len(vault_ids),
        skipped_count=len(skipped),
        repo=f"{owner}/{repo}",
        branch=branch,
        container_label=container_label,
        vault_ids=vault_ids,
        skipped_paths=skipped,
    )
