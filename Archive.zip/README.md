# playbook_to_drawio

Convert a Splunk SOAR playbook `.py` file (or a whole folder of them) into a
styled draw.io diagram and PDF. The output uses Splunk's Enterprise Dark
palette, Splunk Platform Sans typography, type-coded block accents, sticky-
note descriptions with markdown support, and a dot-grid canvas in the SOAR
style.

## Quick start

```bash
# One playbook → <input>.drawio + <input>.pdf next to the input
python3 playbook_to_drawio.py /path/to/Playbook.py --pdf

# A whole folder — recurses, skips non-playbook .py files automatically
python3 playbook_to_drawio.py /path/to/playbooks_folder --pdf

# Folder → custom output directory
python3 playbook_to_drawio.py /path/to/playbooks_folder -o /path/to/diagrams --pdf
```

## CLI

```
playbook_to_drawio.py [-h] [-o OUTPUT] [--pdf] INPUT
```

| Flag             | Meaning |
|------------------|---------|
| `INPUT`          | A SOAR playbook `.py` file **or** a directory containing playbook `.py` files. Directories are recursed. |
| `-o`, `--output` | Output `.drawio` path (single-file input) **or** output directory (folder input). Defaults to writing next to the input. |
| `--pdf`          | Also export a PDF. Uses the draw.io CLI / desktop app if available; falls back to a self-contained `reportlab` renderer otherwise. |

The directory mode prints one line per playbook and exits non-zero only if
nothing was found or some files failed to convert.

## Requirements

- **Python 3.9+** (uses `from __future__ import annotations` so it runs on
  3.9; `match` is *not* used).
- **draw.io desktop** (optional) — gives the prettiest PDF export. On macOS
  the script auto-detects `/Applications/draw.io.app/Contents/MacOS/draw.io`,
  so `brew install --cask drawio` is enough to enable it.
- **`reportlab`** (optional) — `pip install reportlab`. Only used as a PDF
  fallback when draw.io isn't installed. The `.drawio` output never needs
  it.
- No other third-party packages.

## What gets parsed

The script reads the source with `ast` and recognizes:

| Block type | Detection cue (in priority order) |
|-----------|------------------------------------|
| START     | `def on_start(...)` |
| END       | `def on_finish(...)` |
| ES        | Any phantom call referencing `splunk_es` / `enterprise_security` / `es_correlation` / `notable_event` |
| DECISION  | `phantom.decision(...)` |
| PLAYBOOK  | `phantom.playbook(...)` |
| FILTER    | `phantom.condition(...)` |
| ACTION    | `phantom.act(...)` |
| PROMPT    | `phantom.prompt(...)` / `prompt2(...)` |
| FORMAT    | `phantom.format(...)` |
| UTILITY   | `phantom.custom_function(...)` / `phantom.comment(...)` |
| CODE      | fallback for blocks with no recognized phantom call |

For each function decorated with `@phantom.playbook_block()` the script
extracts:

- **Descriptions** — the first non-scaffold banner comment block at the top
  of the function (the `###` blocks; `## Custom Code Start/End` boilerplate
  is ignored). Markdown is supported inside: headings, paragraphs, bullet
  lists, **bold**, *italic*, `inline code`, and `| ... |` tables.
- **Edges** — from `callback=...` keyword args, from direct calls to other
  block functions in the body, and from each branch of a top-level `if/else`
  (which become numbered `condition N` labels).
- **Reachability** — blocks not reachable from `on_start` are rendered with
  a dashed border below the main flow under an "UNREACHABLE BLOCKS" label,
  and outgoing edges from those blocks are suppressed so they can't
  visually cut across the main flow.
- **Title / description** — playbook title is derived from the filename
  (`Active_Directory_Disable_Account_Dispatch.py` → "Active Directory
  Disable Account Dispatch"). The full module docstring becomes the
  paragraph below the title.

## Output layout

```
┌──────────────────────────────────────────────────────────┐
│  SPLUNK SOAR PLAYBOOK                                    │
│  <title from filename>                                   │  <- header card
│  <module docstring as the description paragraph>         │
└──────────────────────────────────────────────────────────┘
┌──────────────────────────────────────────────────────────┐
│ . . . . . . . . . . . . . . . . . . . . . . . . . . . . .│
│            ┌──────┐                                       │
│  ┌──────┐  │      │       ┌──────────────────────────┐    │
│  │ note │··│ blk  │       │ note                     │    │  <- workflow
│  └──────┘  └──────┘       └──────────────────────────┘    │     card
│                                                            │     (dot grid
│  UNREACHABLE BLOCKS — defined but not called from on_start │     background)
│  ┌──────┐                                                  │
│  │ orph │··[note]                                          │
│  └──────┘                                                  │
└────────────────────────────────────────────────────────────┘
```

Notes are placed in left/right gutters based on which branch their block
sits in — left-branch blocks get left notes, right-branch blocks get right
notes, spine blocks alternate. Connectors are straight horizontal lines.

Decision branch labels are filled pill chips colored per-condition:
condition 1 violet, 2 mint, 3 lime, 4 rose, 5 peach. Block-to-block edges
use Splunk's orthogonal L-bend routing.

## Color palette (top of `playbook_to_drawio.py`)

Per-block accent colors (Splunk-aligned):

| Block | Color |
|---|---|
| START / END   | `#6E7079` neutral gray |
| ACTION        | `#A8DD9D` leaf green |
| DECISION      | `#7CD2BB` mint |
| FILTER        | `#8AA0FF` light indigo |
| CODE          | `#5066D6` Splunk blue |
| FORMAT        | `#EE7B92` light pink |
| UTILITY       | `#9D6FF0` violet |
| PLAYBOOK      | `#B043C1` magenta |
| PROMPT        | `#FAD476` yellow |
| ES            | `#5FA15B` forest green |

Page chrome uses Splunk Enterprise Dark tokens: page `#111215`, surface
`#1a1c20`, borders `#3d3e43`/`#717275`, text `#fafafa`/`#b5b5b5`/`#909090`.
Description cards are white (`#ffffff`) with a per-type accented border.

To tweak any of these, edit the constants at the top of
[`playbook_to_drawio.py`](playbook_to_drawio.py) — they're all hex strings
near the top of the file.

## Tests

```bash
python3 -m unittest discover -s tests -v
```

The fixture in [`tests/fixtures/all_features.py`](tests/fixtures/all_features.py)
exercises every block type, a decision with two branches, a filter, an
unreachable block, and a description containing a markdown table + list +
inline code. The test suite covers parsing, markdown, layout, draw.io
emission, and the reportlab PDF fallback.

## Editing in draw.io

Open the generated `.drawio` in [app.diagrams.net](https://app.diagrams.net),
the draw.io desktop app, or the **Draw.io Integration** VS Code extension.
Everything is normal mxGraph cells — drag blocks, edit any sticky note's
HTML inline, then `File → Export As → PDF` for the final.

Regenerating from the script overwrites the `.drawio` file. If you want to
keep manual edits, save the edited version under a different filename.

## File list

| Path | What |
|---|---|
| [`playbook_to_drawio.py`](playbook_to_drawio.py) | The script. Single self-contained module — no package, no setup.py. |
| [`tests/test_playbook_to_drawio.py`](tests/test_playbook_to_drawio.py) | unittest-based test suite (57 tests). |
| [`tests/fixtures/all_features.py`](tests/fixtures/all_features.py) | End-to-end fixture playbook covering every block type. |
| [`README.md`](README.md) | This file. |
