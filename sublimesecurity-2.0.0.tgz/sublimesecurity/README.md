<img src="logo_dark.svg" width="300">

# Sublime Security — Splunk SOAR App

Publisher: Splunk SOAR Community
Connector Version: 1.0.0
Product Vendor: Sublime Security
Product Name: Sublime Platform
Minimum Product Version: 6.3.0

A community-maintained Splunk SOAR connector for the [Sublime Security
Platform](https://sublime.security) API. Integrates with the Sublime Security Platform
API to perform email security operations including binexplode analysis, link analysis,
audit log management, hunt jobs, list management, message group actions, message
analysis, rule management, and SCIM user provisioning — plus an inbound REST handler
for Sublime webhooks.

## Features

- **Full Sublime Platform API coverage** — audit log, hunt jobs, lists, message groups,
  messages, rules, SCIM, tasks, user reports, and enrichment actions
- **Binexplode analysis** — submit files via Vault ID or base64 and retrieve scan trees
- **Link analysis (`ml.link_analysis`)** — returns disposition, brand, confidence, and
  automatically saves page screenshots to the SOAR Vault
- **Vault integration everywhere** — any action that accepts or returns a file works with
  Splunk SOAR Vault IDs. EML downloads, rendered message images, attachment renders, and
  link analysis screenshots are automatically stored in the Vault
- **List entry CSV workflow** — export list entries to Vault as CSV, and bulk-import
  entries from a CSV Vault file
- **Inbound webhook handler** — receive Sublime webhooks at
  `https://<soar-host>/rest/handler/sublimesecurity/<asset_name>/webhook` to
  automatically create containers and artifacts per message group

## Asset Configuration

| Parameter | Required | Description |
|-----------|----------|-------------|
| `region` | Yes | Sublime Security region. One of: NA-East, NA-West, Canada, UK (London), Europe (Dublin), Australia, Custom. |
| `base_url` | No | Custom base URL (only used when region is set to Custom). |
| `api_key` | Yes | API key for Sublime Security. Found in the Sublime dashboard under Automate > API. |
| `verify_server_cert` | No | Verify the server certificate. Default: true. |

### Regional Base URLs

| Region | Base URL |
|--------|----------|
| NA-East | https://platform.sublime.security |
| NA-West | https://na-west.platform.sublime.security |
| Canada | https://ca.platform.sublime.security |
| UK (London) | https://uk.platform.sublime.security |
| Europe (Dublin) | https://eu.platform.sublime.security |
| Australia | https://au.platform.sublime.security |

## File Inputs

Actions that accept file data (upload binary, process raw message, analyze raw message,
render attachment image, get attack score raw, create message) support two input modes:

- **`vault_id`** — a Vault ID of a file already stored in Splunk SOAR
- **`base64_data`** — the raw base64-encoded file contents

Provide exactly one. When a Vault ID is supplied, the connector retrieves the file
contents from the SOAR Vault before sending to Sublime Security.

## Inbound Webhook (REST Handler)

The app exposes a REST handler for receiving webhooks from Sublime Security. Configure
Sublime to POST events to:

```
https://<soar-host>/rest/handler/sublimesecurity/<asset_name>/webhook
```

For each event received, the handler will:

1. Create a SOAR container (deduplicated on the canonical message ID)
2. Create one artifact per message, populated with CEF fields for message ID, subject,
   sender email, mailbox, recipients, flagged rules, and triggered actions
3. Run playbook automation on each created artifact

### Authenticating inbound webhooks with `ph-auth-token`

The webhook REST handler is declared with `"requires_auth": true`, which means Splunk
SOAR expects every inbound POST to carry a `ph-auth-token` header bound to an
**Automation** user. You must provision this automation account before enabling the
webhook.

**Provision the automation user** (see the Splunk Phantom
[PlatformAPI docs](https://docs.splunk.com/Documentation/Phantom/4.10.7/PlatformAPI/Using)):

1. Log in to Splunk SOAR / Phantom as an administrative user.
2. From the Main Menu, select **Administration**.
3. Select **User Management > Users**.
4. Click **+ User** to add a new user.
5. Select **Automation** as the user type.
6. Provide a user name and fill in **Allowed IPs**. Use `any` for unrestricted access,
   or enter the Sublime Security webhook egress IPs (see below) as a comma-separated
   list of single IPs or netmasks.
7. Choose one or more roles. The default **Automation** role has a broad set of
   permissions suitable for a service account. If you want a narrower permission set,
   create a custom role and assign it here.
8. Click **Create**.

After the user is created, SOAR will surface a configuration block that looks like:

```json
{
  "ph-auth-token": "cs76HmsNcWjkd6kWmGzUa18LcbtQx95vMW1bsdeP7gU=",
  "server": "https://172.16.210.137"
}
```

| Parameter | Type | Description |
|-----------|------|-------------|
| `ph-auth-token` | String | Generated authorization token. Only valid from the IPs listed in the user's **Allowed IPs** panel. |
| `server` | String/URL | Base URL to POST to this SOAR instance. |

Copy the `ph-auth-token` and add it to the Sublime webhook Action. In the Sublime
dashboard, open your webhook Action, scroll to **Headers**, and add:

| Header | Value |
|--------|-------|
| `ph-auth-token` | *(value from the automation user block above)* |

See Sublime's docs for the UI walkthrough:
<https://docs.sublime.security/docs/webhooks>

### Expected source IPs (Sublime Security webhook egress)

Add these to the automation user's **Allowed IPs** and to any upstream firewall or
reverse proxy. Also listed in the app's `webhook.ip_allowlist`:

```
66.22.9.207
66.22.9.208
66.22.9.209
```

### `webhook_signing_secret` and `webhook_signature_tolerance_seconds`

These two optional asset settings turn on **HMAC payload verification** on top of
the SOAR `ph-auth-token` check. `ph-auth-token` proves the *caller* is allowed
to hit the SOAR REST handler — it does **not** prove the body came from Sublime.
A compromised webhook URL, leaked log line, or misconfigured proxy can replay or
forge events. The signing secret closes that gap.

**What is the signing secret?** When you create a webhook Action in Sublime,
Sublime generates a per-Action signing secret and signs every payload with it:

1. Sublime picks a Unix timestamp `t`.
2. It computes `HMAC_SHA256(signing_secret, f"{t}.{raw_request_body}")`.
3. It sends the result in the `X-Sublime-Signature` header, formatted as
   `t=<unix-ts>,v0=<hex-digest>`. `v0` is the only valid scheme today; other
   schemes are ignored to prevent downgrade attacks.

To grab the secret, open your Action in the Sublime **Actions** page and click
**Click to reveal**. Paste it into the asset's **webhook_signing_secret** field.
With a secret configured, the handler reproduces the HMAC over the raw request
body and rejects mismatches with `HTTP 401` — using `hmac.compare_digest` for
constant-time comparison.

**`webhook_signature_tolerance_seconds`** controls replay protection. Sublime
signs the timestamp into the payload, so an attacker cannot edit `t=` without
invalidating the signature. If the timestamp is older than this many seconds
(default 300), the request is rejected. Lower it for stricter replay protection
or raise it if your SOAR/Sublime clocks drift apart.

**Both settings are optional.** Leave the signing secret blank and the
handler skips HMAC verification entirely; the tolerance field then has no effect.
For production deployments we recommend setting both.

### Container, artifacts, and the optional EML

Each accepted webhook produces one container named **`Message Flagged: {Email
Subject}`** and **one primary artifact** with label `flagged message`.
The artifact's CEF block carries:

- Identifiers: `messageId`, `canonicalId`, `messageSourceId`, `externalMessageId`,
  `rfc822MessageId`, `mailboxId` / `mailboxExternalId` / `mailboxEmail`.
- People: `senderEmail` / `senderDisplayName` / `senderDomain`, `replyToEmails`,
  `toRecipients` / `ccRecipients` / `bccRecipients`, `recipientCount`.
- Content: `subject`, `subjectBase`, `subjectIsReply` / `subjectIsForward`,
  `attachmentCount` / `attachmentFileNames` / `attachmentMd5Hashes`, `linkCount`
  / `linkUrls`.
- Routing: `isInbound` / `isOutbound` / `isInternal`, `routeType`, `landedInSpam`,
  `headerDate`, `inReplyTo`, `references`, `spfPass` / `dkimPass` / `dmarcPass`.
- Verdicts: `attackScoreVerdict`, `attackScore`, `graymailScore`,
  `attackScoreTopSignals` / `attackScoreTopSignalNames`.
- Rules / actions: `flaggedRules` / `flaggedRuleIds` / `flaggedRuleSeverities` /
  `flaggedRuleTags`, `triggeredActionTypes` / `triggeredActionNames`.
- Event metadata: `eventType`, `eventId`, `eventCreatedAt`.

The artifact's `data` field carries the per-message MDM block; the artifact's
`raw_data` field carries the **original full webhook JSON event** for replay or
deep debugging.

**Optional EML companion artifact.** Set the asset option
**webhook_fetch_eml** to `true` and the handler will additionally:

1. Call `/v0/messages/{id}/eml` on Sublime to download the original `.eml`.
2. Attach it to the container's vault.
3. Create a **separate companion artifact** (this is *not* embedded in the
   primary artifact) with label `email`, name `EML: {message_id}`, and CEF
   `vaultId` / `fileName` / `messageId`.

The EML is therefore always a distinct artifact from the message-metadata
artifact — you can disable automation on it independently and it can be
correlated by `messageId` across the two.

### Error containers on webhook failures

If the handler can't process a webhook past the auth check — invalid JSON,
non-object payload, or a SOAR REST failure while creating a per-message
container/artifact — it creates an **error container** so the failure is
visible in SOAR instead of being lost to logs:

- Name: `Sublime Security webhook error: <reason>`.
- Severity `high`, tags `error` and `sublime-webhook`.
- Status: best-effort set to `error` via `phantom.set_status(container=...,
  status="error", trace=False)`. This is wrapped in a `try/except` because
  many SOAR installations don't define a custom **`error`** status; in that
  case the container keeps the default `open` status and a warning is logged.
  Add an `Error` (or `error`) status under **Administration → Event Settings
  → Statuses** if you want this to take effect.
- A JSON file named `sublime-webhook-error-<unix-ts>.json` is attached to the
  container's vault, containing the reason, the parsed payload (if any), the
  raw request body, and any extra context (e.g. the failed container/artifact
  body that SOAR rejected).

Auth failures (missing `ph-auth-token`, signature mismatch) do **not** create
containers — those are treated as untrusted callers and rejected with `HTTP 401`
to keep the error-container surface from being spammed.

## Actions

### Connectivity
- **test connectivity** — validates the asset configuration by calling the audit log event types endpoint

### BinExplode
- **upload binary** — upload a binary (via Vault ID or base64) to be binexploded
- **get binexplode results** — retrieve results of a binexplode scan by task ID

### Enrichment
- **analyze link** — analyze a URL with `ml.link_analysis`; screenshot is saved to Vault automatically

### Audit Log
- **list audit events** — list events with optional time, type, and user filters
- **list audit event types** — enumerate all available audit event types
- **get audit event** — retrieve a single audit event by ID

### Hunt Jobs
- **start hunt job** — start a new hunt job with MQL source and time range
- **get hunt job** — check status of a hunt job
- **get hunt job results** — retrieve the message groups produced by a completed hunt

### Lists
- **list lists** — retrieve all organization lists
- **create list** — create a new named string list
- **delete list** — delete a list by ID
- **get list** — get a single list's metadata
- **patch list** — patch a list's description
- **get list entries** — retrieve list entries; optionally save them to the Vault as CSV
- **set list entries** — replace entries from either a comma-separated string or a CSV vault file
- **delete list entry** — delete a single entry from a list
- **get list entry** — check a single entry or a comma-separated list of entries for presence
- **add list entry** — add a single entry to a list

### Raw Message Processing
- **process raw message** — submit a raw EML to Sublime's Live Flow for full analysis

### Mailboxes
- **list mailboxes** — list connected mailboxes with filters

### Message Groups (bulk)
- **list message groups** — list message groups with extensive filters
- **dismiss message groups** — dismiss multiple message groups
- **quarantine message groups** — quarantine multiple groups
- **graymail message groups** — move groups to graymail
- **restore message groups** — restore multiple groups
- **review message groups** — review groups with classification and action
- **search message groups** — search groups across multiple fields
- **trash message groups** — trash multiple groups

### Message Groups (single)
- **get message group** — get a single canonical message group
- **dismiss message group** — dismiss a single group
- **quarantine message group** — quarantine a single group
- **restore message group** — restore a single group
- **share with sublime** — share a message group with Sublime for community detection
- **trash message group** — trash a single group

### Messages
- **analyze raw message** — analyze raw EML against rules and queries
- **render attachment image** — render an attachment image from raw bytes
- **get attack score raw** — evaluate attack score for a raw EML
- **create message** — create a message from a raw EML
- **get action state** — retrieve manual action state for a canonical group
- **get message** — retrieve a message by ID
- **action message** — perform an action (quarantine, trash, restore, etc.) on a message
- **analyze message by id** — analyze an existing message against rules and queries
- **get asa report** — retrieve the ASA (Attack Surface Assessment) report
- **get asa verdict** — retrieve the ASA verdict (malicious, spam, graymail, likely_benign, benign, unknown)
- **get attachment image** — retrieve PDF attachment image by MD5 hash
- **get attack score** — evaluate attack score against an existing message
- **get message image** — retrieve a rendered image of a message (saved to Vault)
- **get message eml** — retrieve raw EML (saved to Vault)
- **get message image link** — retrieve a temporary link to the message image
- **set access justification** — set access justification for a message
- **get message data model** — retrieve the full Message Data Model (MDM)
- **restore message** — restore a trashed message
- **trash message** — trash a single message

### Rules
- **list rules** — list all rules in the organization
- **create rule** — create a new detection, DLP, or triage rule
- **list rule history** — list history for all rules
- **validate rule** — validate MQL rule syntax without creating
- **delete rule** — delete a rule by ID
- **get rule** — retrieve a single rule
- **update rule** — update an existing rule
- **activate rule** — activate a rule
- **deactivate rule** — deactivate a rule
- **get rule history** — retrieve history of a specific rule

### Tasks
- **get task** — retrieve task status by ID

### User Reports
- **list user reports** — list user-submitted phishing reports

### Users / Roles
- **assign role** — assign a role to a user

### SCIM
- **list scim resource types** / **get scim resource type**
- **list scim users** / **create scim user** / **get scim user** / **delete scim user**
- **update scim user** / **patch scim user**
- **validate scim auth**
- **list scim schemas** / **get scim schema**
- **get scim service provider config**

## Contributors

- **Evan R. Kinney** — <evanrkinney@gmail.com> — Splunk SOAR Community

## License

Copyright (c) 2026 Splunk SOAR Community.

Licensed under the Apache License, Version 2.0. See
[LICENSE](https://www.apache.org/licenses/LICENSE-2.0) for the full text.
