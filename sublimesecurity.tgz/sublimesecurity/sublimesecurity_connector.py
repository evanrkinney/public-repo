# File: sublimesecurity_connector.py
#
# Copyright (c) 2025 Splunk Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software distributed under
# the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
# either express or implied. See the License for the specific language governing permissions
# and limitations under the License.

import base64
import json

import phantom.app as phantom
import requests
from phantom.action_result import ActionResult
from phantom.base_connector import BaseConnector
from phantom.vault import Vault

from sublimesecurity_consts import (
    ASSIGN_ROLE_ENDPOINT,
    AUDIT_EVENT_ENDPOINT,
    AUDIT_EVENT_TYPES_ENDPOINT,
    AUDIT_EVENTS_ENDPOINT,
    BASE_URLS,
    BINEXPLODE_SCAN_ENDPOINT,
    BINEXPLODE_SCAN_RESULT_ENDPOINT,
    DEFAULT_LIMIT,
    ERR_CONNECTIVITY_TEST,
    HUNT_JOB_ENDPOINT,
    HUNT_JOB_RESULTS_ENDPOINT,
    HUNT_JOBS_ENDPOINT,
    LINK_ANALYSIS_ENDPOINT,
    LIST_ENDPOINT,
    LIST_ENTRIES_ENDPOINT,
    LIST_ENTRY_ENDPOINT,
    LISTS_ENDPOINT,
    MAILBOXES_ENDPOINT,
    MAX_LIMIT,
    MESSAGE_ACTIONS_ENDPOINT,
    MESSAGE_ANALYZE_BY_ID_ENDPOINT,
    MESSAGE_ASA_REPORT_ENDPOINT,
    MESSAGE_ATTACHMENT_IMAGE_ENDPOINT,
    MESSAGE_ATTACK_SCORE_ENDPOINT,
    MESSAGE_EML_ENDPOINT,
    MESSAGE_ENDPOINT,
    MESSAGE_GROUP_ACTION_STATE_ENDPOINT,
    MESSAGE_GROUP_DISMISS_ENDPOINT,
    MESSAGE_GROUP_ENDPOINT,
    MESSAGE_GROUP_QUARANTINE_ENDPOINT,
    MESSAGE_GROUP_RESTORE_ENDPOINT,
    MESSAGE_GROUP_SHARE_ENDPOINT,
    MESSAGE_GROUP_TRASH_ENDPOINT,
    MESSAGE_GROUPS_DISMISS_ENDPOINT,
    MESSAGE_GROUPS_ENDPOINT,
    MESSAGE_GROUPS_GRAYMAIL_ENDPOINT,
    MESSAGE_GROUPS_HUNT_ENDPOINT,
    MESSAGE_GROUPS_HUNT_RESULTS_ENDPOINT,
    MESSAGE_GROUPS_QUARANTINE_ENDPOINT,
    MESSAGE_GROUPS_RESTORE_ENDPOINT,
    MESSAGE_GROUPS_REVIEW_ENDPOINT,
    MESSAGE_GROUPS_SEARCH_ENDPOINT,
    MESSAGE_GROUPS_TRASH_ENDPOINT,
    MESSAGE_IMAGE_ENDPOINT,
    MESSAGE_IMAGE_LINK_ENDPOINT,
    MESSAGE_JUSTIFICATION_ENDPOINT,
    MESSAGE_MDM_ENDPOINT,
    MESSAGE_RESTORE_ENDPOINT,
    MESSAGE_TRASH_ENDPOINT,
    MESSAGES_ANALYZE_ENDPOINT,
    MESSAGES_ATTACHMENT_IMAGE_RAW_ENDPOINT,
    MESSAGES_ATTACK_SCORE_ENDPOINT,
    MESSAGES_CREATE_ENDPOINT,
    RAW_MESSAGE_ANALYZE_ENDPOINT,
    RULE_ACTIVATE_ENDPOINT,
    RULE_DEACTIVATE_ENDPOINT,
    RULE_ENDPOINT,
    RULE_HISTORY_ENDPOINT,
    RULES_ENDPOINT,
    RULES_HISTORY_ENDPOINT,
    RULES_VALIDATE_ENDPOINT,
    SCIM_MAX_COUNT,
    SCIM_RESOURCE_TYPE_ENDPOINT,
    SCIM_RESOURCE_TYPES_ENDPOINT,
    SCIM_SCHEMA_ENDPOINT,
    SCIM_SCHEMAS_ENDPOINT,
    SCIM_SERVICE_PROVIDER_CONFIG_ENDPOINT,
    SCIM_USER_ENDPOINT,
    SCIM_USERS_ENDPOINT,
    SCIM_VALIDATE_AUTH_ENDPOINT,
    SUCC_CONNECTIVITY_TEST,
    TASK_ENDPOINT,
    USER_REPORTS_ENDPOINT,
)


class SublimeSecurityConnector(BaseConnector):
    """Connector for the Sublime Security Platform API."""

    def __init__(self):
        super().__init__()
        self._base_url = None
        self._api_key = None
        self._verify = False
        self._headers = None

    # =========================================================================
    # Utility methods
    # =========================================================================

    def _get_file_data(self, action_result, vault_id=None, base64_data=None):
        """Retrieve file data from either a Vault ID or base64 encoded string.

        Returns (status, file_bytes) tuple.
        """
        if vault_id:
            try:
                success, message, vault_info = Vault.vault_info(vault_id=vault_id)
                if not success or not vault_info:
                    return action_result.set_status(phantom.APP_ERROR, f"Could not find vault file: {message}"), None

                vault_info = list(vault_info)
                if not vault_info:
                    return action_result.set_status(phantom.APP_ERROR, "No vault file found for the provided Vault ID"), None

                file_path = vault_info[0].get("path")
                if not file_path:
                    return action_result.set_status(phantom.APP_ERROR, "Could not determine file path from vault"), None

                with open(file_path, "rb") as f:
                    file_bytes = f.read()

                return phantom.APP_SUCCESS, file_bytes
            except Exception as e:
                return action_result.set_status(phantom.APP_ERROR, f"Error reading vault file: {e!s}"), None

        elif base64_data:
            try:
                file_bytes = base64.b64decode(base64_data)
                return phantom.APP_SUCCESS, file_bytes
            except Exception as e:
                return action_result.set_status(phantom.APP_ERROR, f"Error decoding base64 data: {e!s}"), None

        return action_result.set_status(phantom.APP_ERROR, "Either vault_id or base64_data must be provided"), None

    def _get_file_as_base64(self, action_result, param):
        """Get file as base64 string from vault_id or base64_data param.

        Returns (status, base64_string) tuple.
        """
        vault_id = param.get("vault_id")
        base64_data = param.get("base64_data")

        if vault_id:
            ret_val, file_bytes = self._get_file_data(action_result, vault_id=vault_id)
            if phantom.is_fail(ret_val):
                return ret_val, None
            return phantom.APP_SUCCESS, base64.b64encode(file_bytes).decode("utf-8")
        elif base64_data:
            return phantom.APP_SUCCESS, base64_data
        else:
            return action_result.set_status(phantom.APP_ERROR, "Either vault_id or base64_data must be provided"), None

    def _make_rest_call(self, endpoint, action_result, headers=None, params=None, data=None, json_data=None, method="get"):
        """Make a REST API call to the Sublime Security platform."""
        try:
            url = f"{self._base_url}{endpoint}"
            self.debug_print(f"Making REST call to: {url}")

            request_headers = dict(self._headers)
            if headers:
                request_headers.update(headers)

            request_func = getattr(requests, method.lower())

            response = request_func(
                url,
                json=json_data,
                data=data,
                headers=request_headers,
                params=params,
                verify=self._verify,
            )

            if hasattr(action_result, "add_debug_data"):
                action_result.add_debug_data({"r_status_code": response.status_code})
                action_result.add_debug_data({"r_text": response.text})
                action_result.add_debug_data({"r_headers": dict(response.headers)})

            # Success range (200-299)
            if 200 <= response.status_code < 300:
                # 204 No Content
                if response.status_code == 204 or not response.text:
                    return phantom.APP_SUCCESS, {}
                try:
                    return phantom.APP_SUCCESS, response.json()
                except ValueError:
                    return phantom.APP_SUCCESS, response.text

            error_message = f"Error from server. Status Code: {response.status_code}"
            if response.text:
                try:
                    resp_json = response.json()
                    server_error = resp_json.get("error", resp_json.get("message", "Unknown error"))
                    error_message = f"Error from server. Status Code: {response.status_code}. Error: {server_error}"
                except ValueError:
                    error_message = f"Error from server. Status Code: {response.status_code}. Error: {response.text}"

            return action_result.set_status(phantom.APP_ERROR, error_message), None

        except requests.exceptions.ConnectionError as e:
            return action_result.set_status(phantom.APP_ERROR, f"Connection error: {e!s}"), None
        except Exception as e:
            return action_result.set_status(phantom.APP_ERROR, f"Error making REST call: {e!s}"), None

    def _make_rest_call_raw(self, endpoint, action_result, headers=None, params=None, method="get"):
        """Make a REST call that returns raw bytes (for EML, images)."""
        try:
            url = f"{self._base_url}{endpoint}"
            request_headers = dict(self._headers)
            if headers:
                request_headers.update(headers)

            request_func = getattr(requests, method.lower())
            response = request_func(url, headers=request_headers, params=params, verify=self._verify)

            if 200 <= response.status_code < 300:
                return phantom.APP_SUCCESS, response.content, response.headers.get("Content-Type", "")

            error_message = f"Error from server. Status Code: {response.status_code}"
            return action_result.set_status(phantom.APP_ERROR, error_message), None, None

        except Exception as e:
            return action_result.set_status(phantom.APP_ERROR, f"Error making REST call: {e!s}"), None, None

    def _save_to_vault(self, action_result, data_bytes, file_name, container_id=None):
        """Save bytes to the SOAR vault. Returns vault_id or None."""
        try:
            if container_id is None:
                container_id = self.get_container_id()
            tmp_dir = Vault.get_vault_tmp_dir()
            file_path = f"{tmp_dir}/{file_name}"
            with open(file_path, "wb") as f:
                f.write(data_bytes)
            vault_ret = Vault.add_attachment(file_path, container_id, file_name=file_name)
            if vault_ret.get("succeeded"):
                return vault_ret.get("vault_id", "")
        except Exception as e:
            self.debug_print(f"Could not save to vault: {e!s}")
        return None

    def _clamp_limit(self, limit, maximum=None):
        """Clamp limit to max value."""
        if maximum is None:
            maximum = MAX_LIMIT
        if limit is None:
            return DEFAULT_LIMIT
        return min(int(limit), maximum)

    def _parse_comma_list(self, value):
        """Parse a comma-separated string into a list of stripped strings."""
        if not value:
            return []
        return [v.strip() for v in value.split(",") if v.strip()]

    # =========================================================================
    # Bulk message group review body builder
    # =========================================================================

    def _build_review_body(self, param):
        """Build the standard review request body for message group actions."""
        body = {"message_group_ids": self._parse_comma_list(param["message_group_ids"])}
        if param.get("classification"):
            body["classification"] = param["classification"]
        if param.get("report_label"):
            body["report_label"] = param["report_label"]
        if param.get("review_comment"):
            body["review_comment"] = param["review_comment"]
        return body

    def _build_single_review_body(self, param):
        """Build review body for single message group actions (no IDs)."""
        body = {}
        if param.get("classification"):
            body["classification"] = param["classification"]
        if param.get("report_label"):
            body["report_label"] = param["report_label"]
        if param.get("review_comment"):
            body["review_comment"] = param["review_comment"]
        return body

    # =========================================================================
    # Action handlers
    # =========================================================================

    def _handle_test_connectivity(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))
        self.save_progress("Connecting to Sublime Security...")
        ret_val, _ = self._make_rest_call(AUDIT_EVENT_TYPES_ENDPOINT, action_result)
        if phantom.is_fail(ret_val):
            self.save_progress(ERR_CONNECTIVITY_TEST)
            return action_result.get_status()
        self.save_progress(SUCC_CONNECTIVITY_TEST)
        return action_result.set_status(phantom.APP_SUCCESS)

    # --- BinExplode ---

    def _handle_upload_binary(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))
        ret_val, b64_data = self._get_file_as_base64(action_result, param)
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        body = {"file_contents": b64_data, "file_name": param["file_name"]}
        ret_val, response = self._make_rest_call(BINEXPLODE_SCAN_ENDPOINT, action_result, json_data=body, method="post")
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        action_result.add_data(response)
        action_result.update_summary({"task_id": response.get("task_id", "")})
        return action_result.set_status(phantom.APP_SUCCESS)

    def _handle_get_binexplode_results(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))
        endpoint = BINEXPLODE_SCAN_RESULT_ENDPOINT.format(id=param["task_id"])
        ret_val, response = self._make_rest_call(endpoint, action_result)
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        results = response.get("results", [])
        for r in results:
            action_result.add_data(r)

        task_response = response.get("task_response", {})
        action_result.update_summary({
            "total_results": len(results),
            "task_state": task_response.get("state", "unknown"),
        })
        return action_result.set_status(phantom.APP_SUCCESS)

    # --- Link Analysis ---

    def _handle_analyze_link(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))
        body = {"url": param["url"]}
        if param.get("no_logo_detect"):
            body["no_logo_detect"] = True

        ret_val, response = self._make_rest_call(LINK_ANALYSIS_ENDPOINT, action_result, json_data=body, method="post")
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        action_result.add_data(response)

        summary = {"analyzed": response.get("analyzed", False)}
        credphish = response.get("credphish")
        if credphish:
            summary["disposition"] = credphish.get("disposition", "unknown")
            summary["confidence"] = credphish.get("confidence", "")
            brand = credphish.get("brand")
            if brand:
                summary["brand_name"] = brand.get("name", "")

        effective_url = response.get("effective_url")
        if effective_url:
            summary["effective_url"] = effective_url.get("url", "")
        action_result.update_summary(summary)

        # Save screenshot to vault
        screenshot = response.get("screenshot")
        if screenshot and screenshot.get("raw"):
            screenshot_bytes = base64.b64decode(screenshot["raw"])
            file_name = screenshot.get("file_name", "link_analysis_screenshot.png")
            vault_id = self._save_to_vault(action_result, screenshot_bytes, file_name)
            if vault_id:
                action_result.update_summary({"screenshot_vault_id": vault_id})

        return action_result.set_status(phantom.APP_SUCCESS)

    # --- Audit Log ---

    def _handle_list_audit_events(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))
        query_params = {}
        if param.get("start_time"):
            query_params["created_at[gte]"] = param["start_time"]
        if param.get("end_time"):
            query_params["created_at[lt]"] = param["end_time"]
        if param.get("event_type"):
            query_params["type"] = param["event_type"]
        query_params["limit"] = self._clamp_limit(param.get("limit"))
        query_params["offset"] = int(param.get("offset", 0))

        ret_val, response = self._make_rest_call(AUDIT_EVENTS_ENDPOINT, action_result, params=query_params)
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        events = response.get("events", [])
        for event in events:
            action_result.add_data(event)
        action_result.update_summary({"total_events": response.get("total", 0), "events_returned": len(events)})
        return action_result.set_status(phantom.APP_SUCCESS)

    def _handle_list_audit_event_types(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))
        ret_val, response = self._make_rest_call(AUDIT_EVENT_TYPES_ENDPOINT, action_result)
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        event_types = response.get("event_types", [])
        for et in event_types:
            action_result.add_data(et)
        action_result.update_summary({"total_event_types": len(event_types)})
        return action_result.set_status(phantom.APP_SUCCESS)

    def _handle_get_audit_event(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))
        endpoint = AUDIT_EVENT_ENDPOINT.format(id=param["event_id"])
        ret_val, response = self._make_rest_call(endpoint, action_result)
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        action_result.add_data(response)
        return action_result.set_status(phantom.APP_SUCCESS)

    # --- Hunt Jobs ---

    def _handle_start_hunt_job(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))
        body = {
            "source": param["source"],
            "range_start_time": param["range_start_time"],
            "range_end_time": param["range_end_time"],
        }
        if param.get("name"):
            body["name"] = param["name"]
        if param.get("private"):
            body["private"] = True

        ret_val, response = self._make_rest_call(HUNT_JOBS_ENDPOINT, action_result, json_data=body, method="post")
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        action_result.add_data(response)
        action_result.update_summary({"hunt_job_id": response.get("hunt_job_id", "")})
        return action_result.set_status(phantom.APP_SUCCESS)

    def _handle_get_hunt_job(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))
        endpoint = HUNT_JOB_ENDPOINT.format(id=param["hunt_job_id"])
        ret_val, response = self._make_rest_call(endpoint, action_result)
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        action_result.add_data(response)
        action_result.update_summary({"hunt_status": response.get("status", "unknown")})
        return action_result.set_status(phantom.APP_SUCCESS)

    def _handle_get_hunt_job_results(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))
        endpoint = HUNT_JOB_RESULTS_ENDPOINT.format(id=param["hunt_job_id"])
        query_params = {
            "limit": self._clamp_limit(param.get("limit")),
            "offset": int(param.get("offset", 0)),
        }
        ret_val, response = self._make_rest_call(endpoint, action_result, params=query_params)
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        groups = response.get("message_groups", [])
        for g in groups:
            action_result.add_data(g)
        action_result.update_summary({"total_group_count": response.get("total_group_count", 0), "groups_returned": len(groups)})
        return action_result.set_status(phantom.APP_SUCCESS)

    # --- Lists ---

    def _handle_list_lists(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))
        query_params = {"entry_type": "string"}
        if param.get("name"):
            query_params["name"] = param["name"]

        ret_val, response = self._make_rest_call(LISTS_ENDPOINT, action_result, params=query_params)
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        lists = response.get("lists", [])
        for l in lists:
            action_result.add_data(l)
        action_result.update_summary({"total_lists": len(lists)})
        return action_result.set_status(phantom.APP_SUCCESS)

    def _handle_create_list(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))
        body = {"name": param["name"], "description": param["description"]}
        ret_val, response = self._make_rest_call(LISTS_ENDPOINT, action_result, json_data=body, method="post")
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        action_result.add_data(response)
        action_result.update_summary({"list_id": response.get("id", "")})
        return action_result.set_status(phantom.APP_SUCCESS)

    def _handle_delete_list(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))
        endpoint = LIST_ENDPOINT.format(id=param["list_id"])
        ret_val, _ = self._make_rest_call(endpoint, action_result, method="delete")
        if phantom.is_fail(ret_val):
            return action_result.get_status()
        return action_result.set_status(phantom.APP_SUCCESS, "List deleted successfully")

    def _handle_get_list(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))
        endpoint = LIST_ENDPOINT.format(id=param["list_id"])
        ret_val, response = self._make_rest_call(endpoint, action_result)
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        action_result.add_data(response)
        return action_result.set_status(phantom.APP_SUCCESS)

    def _handle_patch_list(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))
        endpoint = LIST_ENDPOINT.format(id=param["list_id"])
        body = {"description": param["description"]}
        ret_val, response = self._make_rest_call(endpoint, action_result, json_data=body, method="patch")
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        action_result.add_data(response)
        return action_result.set_status(phantom.APP_SUCCESS)

    def _handle_get_list_entries(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))
        endpoint = LIST_ENTRIES_ENDPOINT.format(id=param["list_id"])
        ret_val, response = self._make_rest_call(endpoint, action_result)
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        entries = response.get("entries", [])
        for entry in entries:
            action_result.add_data({"entry": entry})
        action_result.update_summary({"total_entries": len(entries)})

        # Optionally save entries to vault as CSV
        if param.get("save_to_vault"):
            try:
                import csv as csv_mod
                import io
                buf = io.StringIO()
                writer = csv_mod.writer(buf)
                writer.writerow(["entry"])
                for e in entries:
                    writer.writerow([e])
                csv_bytes = buf.getvalue().encode("utf-8")
                file_name = param.get("csv_file_name") or f"list_{param['list_id']}_entries.csv"
                vault_id = self._save_to_vault(action_result, csv_bytes, file_name)
                if vault_id:
                    action_result.update_summary({"vault_id": vault_id})
            except Exception as e:
                self.debug_print(f"Could not save list entries CSV to vault: {e!s}")

        return action_result.set_status(phantom.APP_SUCCESS)

    def _handle_set_list_entries(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))
        endpoint = LIST_ENTRIES_ENDPOINT.format(id=param["list_id"])

        entries = []
        vault_id = param.get("vault_id")
        entries_str = param.get("entries")

        if vault_id:
            ret_val, file_bytes = self._get_file_data(action_result, vault_id=vault_id)
            if phantom.is_fail(ret_val):
                return action_result.get_status()
            try:
                import csv as csv_mod
                import io
                text = file_bytes.decode("utf-8", errors="replace")
                reader = csv_mod.reader(io.StringIO(text))
                for row in reader:
                    for cell in row:
                        cell = cell.strip()
                        if cell and cell.lower() != "entry":
                            entries.append(cell)
            except Exception as e:
                return action_result.set_status(phantom.APP_ERROR, f"Error parsing CSV from vault: {e!s}")
        elif entries_str:
            entries = self._parse_comma_list(entries_str)
        else:
            return action_result.set_status(phantom.APP_ERROR, "Either entries or vault_id must be provided")

        body = {"entries": entries}
        ret_val, _ = self._make_rest_call(endpoint, action_result, json_data=body, method="put")
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        action_result.update_summary({"entries_set": len(entries)})
        return action_result.set_status(phantom.APP_SUCCESS, f"Set {len(entries)} entries successfully")

    def _handle_delete_list_entry(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))
        endpoint = LIST_ENTRY_ENDPOINT.format(id=param["list_id"])
        query_params = {"string": param["entry"]}
        ret_val, _ = self._make_rest_call(endpoint, action_result, params=query_params, method="delete")
        if phantom.is_fail(ret_val):
            return action_result.get_status()
        return action_result.set_status(phantom.APP_SUCCESS, "Entry deleted successfully")

    def _handle_get_list_entry(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))
        endpoint = LIST_ENTRY_ENDPOINT.format(id=param["list_id"])

        # Support single value or comma-separated list
        raw = param["entry"]
        entries_to_check = self._parse_comma_list(raw) if "," in raw else [raw.strip()]

        found_count = 0
        for entry in entries_to_check:
            # Use a fresh ActionResult-less call so a 404 on one entry doesn't fail the whole action
            try:
                url = f"{self._base_url}{endpoint}"
                response = requests.get(url, headers=self._headers, params={"string": entry}, verify=self._verify)
                found = 200 <= response.status_code < 300
            except Exception as e:
                self.debug_print(f"Error checking entry {entry}: {e!s}")
                found = False

            action_result.add_data({"entry": entry, "found": found})
            if found:
                found_count += 1

        action_result.update_summary({
            "total_checked": len(entries_to_check),
            "total_found": found_count,
        })
        return action_result.set_status(phantom.APP_SUCCESS)

    def _handle_add_list_entry(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))
        endpoint = LIST_ENTRY_ENDPOINT.format(id=param["list_id"])
        body = {"string": param["entry"]}
        ret_val, _ = self._make_rest_call(endpoint, action_result, json_data=body, method="post")
        if phantom.is_fail(ret_val):
            return action_result.get_status()
        return action_result.set_status(phantom.APP_SUCCESS, "Entry added successfully")

    # --- Raw Message Processing ---

    def _handle_process_raw_message(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))
        ret_val, b64_data = self._get_file_as_base64(action_result, param)
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        body = {
            "raw_message": b64_data,
            "mailbox_email_address": param["mailbox_email_address"],
            "message_source_id": param["message_source_id"],
        }
        if param.get("create_mailbox"):
            body["create_mailbox"] = True

        ret_val, response = self._make_rest_call(RAW_MESSAGE_ANALYZE_ENDPOINT, action_result, json_data=body, method="post")
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        action_result.add_data(response)
        flagged_rules = response.get("flagged_rules", [])
        action_result.update_summary({
            "message_id": response.get("message_id", ""),
            "flagged_rules_count": len(flagged_rules),
        })
        return action_result.set_status(phantom.APP_SUCCESS)

    # --- Mailboxes ---

    def _handle_list_mailboxes(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))
        query_params = {
            "limit": self._clamp_limit(param.get("limit")),
            "offset": int(param.get("offset", 0)),
        }
        if param.get("active") is not None:
            query_params["active"] = param["active"]
        if param.get("search"):
            query_params["search"] = param["search"]

        ret_val, response = self._make_rest_call(MAILBOXES_ENDPOINT, action_result, params=query_params)
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        mailboxes = response.get("mailboxes", [])
        for mb in mailboxes:
            action_result.add_data(mb)
        action_result.update_summary({
            "total_mailboxes": response.get("total", 0),
            "active_mailboxes": response.get("active", 0),
        })
        return action_result.set_status(phantom.APP_SUCCESS)

    # --- Message Groups ---

    def _handle_list_message_groups(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))
        query_params = {
            "limit": self._clamp_limit(param.get("limit")),
            "offset": int(param.get("offset", 0)),
        }
        if param.get("start_time"):
            query_params["created_at__gte"] = param["start_time"]
        if param.get("end_time"):
            query_params["created_at__lt"] = param["end_time"]
        if param.get("flagged") is not None:
            query_params["flagged"] = param["flagged"]
        if param.get("reviewed") is not None:
            query_params["reviewed"] = param["reviewed"]
        if param.get("sender_email"):
            query_params["sender_email__is"] = param["sender_email"]

        ret_val, response = self._make_rest_call(MESSAGE_GROUPS_ENDPOINT, action_result, params=query_params)
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        groups = response.get("message_groups", [])
        for g in groups:
            action_result.add_data(g)
        action_result.update_summary({"total_groups": response.get("total", 0), "groups_returned": len(groups)})
        return action_result.set_status(phantom.APP_SUCCESS)

    def _handle_dismiss_message_groups(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))
        body = self._build_review_body(param)
        ret_val, _ = self._make_rest_call(MESSAGE_GROUPS_DISMISS_ENDPOINT, action_result, json_data=body, method="post")
        if phantom.is_fail(ret_val):
            return action_result.get_status()
        return action_result.set_status(phantom.APP_SUCCESS, "Message groups dismissed successfully")

    def _handle_hunt_message_groups(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))
        body = {"source": param["source"]}
        if param.get("start_time"):
            body["created_at[gte]"] = param["start_time"]
        if param.get("end_time"):
            body["created_at[lt]"] = param["end_time"]

        ret_val, response = self._make_rest_call(MESSAGE_GROUPS_HUNT_ENDPOINT, action_result, json_data=body, method="post")
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        action_result.add_data(response)
        action_result.update_summary({"task_id": response.get("task_id", "")})
        return action_result.set_status(phantom.APP_SUCCESS)

    def _handle_get_hunt_results(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))
        endpoint = MESSAGE_GROUPS_HUNT_RESULTS_ENDPOINT.format(id=param["task_id"])
        ret_val, response = self._make_rest_call(endpoint, action_result)
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        groups = response.get("message_groups", [])
        for g in groups:
            action_result.add_data(g)
        task_response = response.get("task_response", {})
        action_result.update_summary({"total_groups": len(groups), "task_state": task_response.get("state", "unknown")})
        return action_result.set_status(phantom.APP_SUCCESS)

    def _handle_quarantine_message_groups(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))
        body = self._build_review_body(param)
        ret_val, response = self._make_rest_call(MESSAGE_GROUPS_QUARANTINE_ENDPOINT, action_result, json_data=body, method="post")
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        action_result.add_data(response)
        action_result.update_summary({"task_id": response.get("task_id", "")})
        return action_result.set_status(phantom.APP_SUCCESS)

    def _handle_graymail_message_groups(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))
        body = self._build_review_body(param)
        ret_val, response = self._make_rest_call(MESSAGE_GROUPS_GRAYMAIL_ENDPOINT, action_result, json_data=body, method="post")
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        action_result.add_data(response)
        action_result.update_summary({"task_id": response.get("task_id", "")})
        return action_result.set_status(phantom.APP_SUCCESS)

    def _handle_restore_message_groups(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))
        body = self._build_review_body(param)
        ret_val, response = self._make_rest_call(MESSAGE_GROUPS_RESTORE_ENDPOINT, action_result, json_data=body, method="post")
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        action_result.add_data(response)
        action_result.update_summary({"task_id": response.get("task_id", "")})
        return action_result.set_status(phantom.APP_SUCCESS)

    def _handle_review_message_groups(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))
        body = {
            "message_group_ids": self._parse_comma_list(param["message_group_ids"]),
            "classification": param["classification"],
        }
        if param.get("action"):
            body["action"] = param["action"]
        if param.get("review_comment"):
            body["review_comment"] = param["review_comment"]
        if param.get("share_with_sublime"):
            body["share_with_sublime"] = True

        ret_val, response = self._make_rest_call(MESSAGE_GROUPS_REVIEW_ENDPOINT, action_result, json_data=body, method="post")
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        action_result.add_data(response)
        action_result.update_summary({"task_id": response.get("task_id", "")})
        return action_result.set_status(phantom.APP_SUCCESS)

    def _handle_search_message_groups(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))
        query_params = {
            "limit": self._clamp_limit(param.get("limit")),
            "offset": int(param.get("offset", 0)),
        }
        for key in ("any", "sender", "to", "subject", "file_name"):
            if param.get(key):
                query_params[key] = param[key]
        if param.get("attachment_sha256"):
            query_params["attachment_sha256"] = param["attachment_sha256"]
        if param.get("start_time"):
            query_params["created_at[gte]"] = param["start_time"]
        if param.get("end_time"):
            query_params["created_at[lt]"] = param["end_time"]

        ret_val, response = self._make_rest_call(MESSAGE_GROUPS_SEARCH_ENDPOINT, action_result, params=query_params)
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        groups = response.get("message_groups", [])
        for g in groups:
            action_result.add_data(g)
        action_result.update_summary({"total_groups": response.get("total", 0), "groups_returned": len(groups)})
        return action_result.set_status(phantom.APP_SUCCESS)

    def _handle_trash_message_groups(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))
        body = self._build_review_body(param)
        ret_val, response = self._make_rest_call(MESSAGE_GROUPS_TRASH_ENDPOINT, action_result, json_data=body, method="post")
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        action_result.add_data(response)
        action_result.update_summary({"task_id": response.get("task_id", "")})
        return action_result.set_status(phantom.APP_SUCCESS)

    def _handle_get_message_group(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))
        endpoint = MESSAGE_GROUP_ENDPOINT.format(id=param["message_group_id"])
        ret_val, response = self._make_rest_call(endpoint, action_result)
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        action_result.add_data(response)
        return action_result.set_status(phantom.APP_SUCCESS)

    def _handle_dismiss_message_group(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))
        endpoint = MESSAGE_GROUP_DISMISS_ENDPOINT.format(id=param["message_group_id"])
        body = self._build_single_review_body(param)
        ret_val, _ = self._make_rest_call(endpoint, action_result, json_data=body, method="post")
        if phantom.is_fail(ret_val):
            return action_result.get_status()
        return action_result.set_status(phantom.APP_SUCCESS, "Message group dismissed successfully")

    def _handle_quarantine_message_group(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))
        endpoint = MESSAGE_GROUP_QUARANTINE_ENDPOINT.format(id=param["message_group_id"])
        body = self._build_single_review_body(param)
        ret_val, response = self._make_rest_call(endpoint, action_result, json_data=body, method="post")
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        action_result.add_data(response)
        action_result.update_summary({"task_id": response.get("task_id", "")})
        return action_result.set_status(phantom.APP_SUCCESS)

    def _handle_restore_message_group(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))
        endpoint = MESSAGE_GROUP_RESTORE_ENDPOINT.format(id=param["message_group_id"])
        body = self._build_single_review_body(param)
        ret_val, response = self._make_rest_call(endpoint, action_result, json_data=body, method="post")
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        action_result.add_data(response)
        action_result.update_summary({"task_id": response.get("task_id", "")})
        return action_result.set_status(phantom.APP_SUCCESS)

    def _handle_share_with_sublime(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))
        endpoint = MESSAGE_GROUP_SHARE_ENDPOINT.format(id=param["message_group_id"])
        body = {}
        if param.get("report_label"):
            body["report_label"] = param["report_label"]
        if param.get("review_comment"):
            body["review_comment"] = param["review_comment"]

        ret_val, response = self._make_rest_call(endpoint, action_result, json_data=body, method="post")
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        action_result.add_data(response)
        action_result.update_summary({"task_id": response.get("task_id", "")})
        return action_result.set_status(phantom.APP_SUCCESS)

    def _handle_trash_message_group(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))
        endpoint = MESSAGE_GROUP_TRASH_ENDPOINT.format(id=param["message_group_id"])
        body = self._build_single_review_body(param)
        ret_val, response = self._make_rest_call(endpoint, action_result, json_data=body, method="post")
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        action_result.add_data(response)
        action_result.update_summary({"task_id": response.get("task_id", "")})
        return action_result.set_status(phantom.APP_SUCCESS)

    # --- Messages ---

    def _handle_analyze_raw_message(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))
        ret_val, b64_data = self._get_file_as_base64(action_result, param)
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        body = {"raw_message": b64_data}
        if param.get("run_active_detection_rules"):
            body["run_active_detection_rules"] = True
        if param.get("run_all_detection_rules"):
            body["run_all_detection_rules"] = True
        if param.get("run_all_insights"):
            body["run_all_insights"] = True

        ret_val, response = self._make_rest_call(MESSAGES_ANALYZE_ENDPOINT, action_result, json_data=body, method="post")
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        action_result.add_data(response)
        rule_results = response.get("rule_results", [])
        matched = sum(1 for r in rule_results if r.get("matched"))
        action_result.update_summary({"matched_rules": matched, "total_rules_evaluated": len(rule_results)})
        return action_result.set_status(phantom.APP_SUCCESS)

    def _handle_render_attachment_image(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))
        ret_val, b64_data = self._get_file_as_base64(action_result, param)
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        body = {"raw": b64_data}
        if param.get("file_type"):
            body["file_type"] = param["file_type"]

        ret_val, response = self._make_rest_call(
            MESSAGES_ATTACHMENT_IMAGE_RAW_ENDPOINT, action_result, json_data=body, method="post"
        )
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        action_result.add_data(response)

        # Save rendered images to vault
        image_data = response.get("data", [])
        if image_data and isinstance(image_data, list):
            for idx, img in enumerate(image_data):
                if isinstance(img, list):
                    img_bytes = bytes(img)
                    vault_id = self._save_to_vault(action_result, img_bytes, f"attachment_render_{idx}.png")
                    if vault_id:
                        action_result.update_summary({"screenshot_vault_id": vault_id})

        return action_result.set_status(phantom.APP_SUCCESS)

    def _handle_get_attack_score_raw(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))
        ret_val, b64_data = self._get_file_as_base64(action_result, param)
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        body = {"raw_message": b64_data}
        ret_val, response = self._make_rest_call(MESSAGES_ATTACK_SCORE_ENDPOINT, action_result, json_data=body, method="post")
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        action_result.add_data(response)
        action_result.update_summary({"verdict": response.get("verdict", ""), "score": response.get("score")})
        return action_result.set_status(phantom.APP_SUCCESS)

    def _handle_create_message(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))
        ret_val, b64_data = self._get_file_as_base64(action_result, param)
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        body = {"raw_message": b64_data}
        if param.get("mailbox_email_address"):
            body["mailbox_email_address"] = param["mailbox_email_address"]

        ret_val, response = self._make_rest_call(MESSAGES_CREATE_ENDPOINT, action_result, json_data=body, method="post")
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        action_result.add_data(response)
        action_result.update_summary({"message_id": response.get("id", "")})
        return action_result.set_status(phantom.APP_SUCCESS)

    def _handle_get_action_state(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))
        endpoint = MESSAGE_GROUP_ACTION_STATE_ENDPOINT.format(id=param["message_group_id"])
        query_params = {
            "limit": min(int(param.get("limit", 10)), 50),
            "offset": int(param.get("offset", 0)),
        }
        ret_val, response = self._make_rest_call(endpoint, action_result, params=query_params)
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        actions = response.get("actions", [])
        for a in actions:
            action_result.add_data(a)
        return action_result.set_status(phantom.APP_SUCCESS)

    def _handle_get_message(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))
        endpoint = MESSAGE_ENDPOINT.format(id=param["message_id"])
        ret_val, response = self._make_rest_call(endpoint, action_result)
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        action_result.add_data(response)
        return action_result.set_status(phantom.APP_SUCCESS)

    def _handle_action_message(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))
        endpoint = MESSAGE_ACTIONS_ENDPOINT.format(id=param["message_id"])
        body = {}
        if param.get("action"):
            body["action"] = param["action"]
        if param.get("share_with_sublime"):
            body["share_with_sublime"] = True

        ret_val, response = self._make_rest_call(endpoint, action_result, json_data=body, method="post")
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        action_result.add_data(response)
        action_result.update_summary({"task_id": response.get("task_id", "")})
        return action_result.set_status(phantom.APP_SUCCESS)

    def _handle_analyze_message_by_id(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))
        endpoint = MESSAGE_ANALYZE_BY_ID_ENDPOINT.format(id=param["message_id"])
        body = {}
        if param.get("run_active_detection_rules"):
            body["run_active_detection_rules"] = True
        if param.get("run_all_detection_rules"):
            body["run_all_detection_rules"] = True
        if param.get("run_all_insights"):
            body["run_all_insights"] = True

        ret_val, response = self._make_rest_call(endpoint, action_result, json_data=body, method="post")
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        action_result.add_data(response)
        rule_results = response.get("rule_results", [])
        matched = sum(1 for r in rule_results if r.get("matched"))
        action_result.update_summary({"matched_rules": matched, "total_rules_evaluated": len(rule_results)})
        return action_result.set_status(phantom.APP_SUCCESS)

    def _handle_get_asa_report(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))
        endpoint = MESSAGE_ASA_REPORT_ENDPOINT.format(id=param["message_id"])
        ret_val, response = self._make_rest_call(endpoint, action_result)
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        action_result.add_data(response)
        action_result.update_summary({"verdict": response.get("verdict", "")})
        return action_result.set_status(phantom.APP_SUCCESS)

    def _handle_get_attachment_image(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))
        endpoint = MESSAGE_ATTACHMENT_IMAGE_ENDPOINT.format(id=param["message_id"], hash=param["attachment_hash"])
        ret_val, response = self._make_rest_call(endpoint, action_result)
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        action_result.add_data(response)

        image_data = response.get("data", [])
        if image_data and isinstance(image_data, list):
            for idx, img in enumerate(image_data):
                if isinstance(img, list):
                    img_bytes = bytes(img)
                    vault_id = self._save_to_vault(action_result, img_bytes, f"attachment_{param['attachment_hash']}_{idx}.png")
                    if vault_id:
                        action_result.update_summary({"screenshot_vault_id": vault_id})

        return action_result.set_status(phantom.APP_SUCCESS)

    def _handle_get_attack_score(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))
        endpoint = MESSAGE_ATTACK_SCORE_ENDPOINT.format(id=param["message_id"])
        ret_val, response = self._make_rest_call(endpoint, action_result)
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        action_result.add_data(response)
        action_result.update_summary({"verdict": response.get("verdict", ""), "score": response.get("score")})
        return action_result.set_status(phantom.APP_SUCCESS)

    def _handle_get_message_image(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))
        endpoint = MESSAGE_IMAGE_ENDPOINT.format(id=param["message_id"])
        ret_val, response = self._make_rest_call(endpoint, action_result)
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        action_result.add_data(response)

        data = response.get("data")
        if data:
            img_bytes = base64.b64decode(data) if isinstance(data, str) else bytes(data) if isinstance(data, list) else data
            mime_type = response.get("mime_type", "image/png")
            ext = mime_type.split("/")[-1] if mime_type else "png"
            vault_id = self._save_to_vault(action_result, img_bytes, f"message_{param['message_id']}.{ext}")
            if vault_id:
                action_result.update_summary({"screenshot_vault_id": vault_id})

        return action_result.set_status(phantom.APP_SUCCESS)

    def _handle_get_message_eml(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))
        endpoint = MESSAGE_EML_ENDPOINT.format(id=param["message_id"])
        ret_val, raw_content, content_type = self._make_rest_call_raw(endpoint, action_result)
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        vault_id = self._save_to_vault(action_result, raw_content, f"message_{param['message_id']}.eml")
        if vault_id:
            action_result.update_summary({"vault_id": vault_id})

        return action_result.set_status(phantom.APP_SUCCESS)

    def _handle_get_message_image_link(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))
        endpoint = MESSAGE_IMAGE_LINK_ENDPOINT.format(id=param["message_id"])
        query_params = {}
        if param.get("link_duration_seconds"):
            query_params["link_duration_seconds"] = int(param["link_duration_seconds"])

        ret_val, response = self._make_rest_call(endpoint, action_result, params=query_params)
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        action_result.add_data(response)
        return action_result.set_status(phantom.APP_SUCCESS)

    def _handle_set_access_justification(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))
        endpoint = MESSAGE_JUSTIFICATION_ENDPOINT.format(id=param["message_id"])
        body = {"justification": param["justification"]}
        ret_val, _ = self._make_rest_call(endpoint, action_result, json_data=body, method="post")
        if phantom.is_fail(ret_val):
            return action_result.get_status()
        return action_result.set_status(phantom.APP_SUCCESS, "Access justification set successfully")

    def _handle_get_message_data_model(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))
        endpoint = MESSAGE_MDM_ENDPOINT.format(id=param["message_id"])
        ret_val, response = self._make_rest_call(endpoint, action_result)
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        action_result.add_data(response)
        return action_result.set_status(phantom.APP_SUCCESS)

    def _handle_restore_message(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))
        endpoint = MESSAGE_RESTORE_ENDPOINT.format(id=param["message_id"])
        ret_val, response = self._make_rest_call(endpoint, action_result, method="post")
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        action_result.add_data(response)
        action_result.update_summary({"task_id": response.get("task_id", "")})
        return action_result.set_status(phantom.APP_SUCCESS)

    def _handle_trash_message(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))
        endpoint = MESSAGE_TRASH_ENDPOINT.format(id=param["message_id"])
        ret_val, response = self._make_rest_call(endpoint, action_result, method="post")
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        action_result.add_data(response)
        action_result.update_summary({"task_id": response.get("task_id", "")})
        return action_result.set_status(phantom.APP_SUCCESS)

    # --- Rules ---

    def _handle_list_rules(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))
        query_params = {
            "limit": self._clamp_limit(param.get("limit")),
            "offset": int(param.get("offset", 0)),
        }
        if param.get("search"):
            query_params["search"] = param["search"]

        ret_val, response = self._make_rest_call(RULES_ENDPOINT, action_result, params=query_params)
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        rules = response.get("rules", [])
        for r in rules:
            action_result.add_data(r)
        action_result.update_summary({"total_rules": response.get("total", 0), "rules_returned": len(rules)})
        return action_result.set_status(phantom.APP_SUCCESS)

    def _handle_create_rule(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))
        body = {"name": param["name"], "source": param["source"]}
        for key in ("type", "severity", "description"):
            if param.get(key):
                body[key] = param[key]
        if param.get("active"):
            body["active"] = True

        ret_val, response = self._make_rest_call(RULES_ENDPOINT, action_result, json_data=body, method="post")
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        action_result.add_data(response)
        action_result.update_summary({"rule_id": response.get("id", "")})
        return action_result.set_status(phantom.APP_SUCCESS)

    def _handle_list_rule_history(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))
        query_params = {
            "classification_created_at[gte]": param["start_time"],
            "classification_created_at[lte]": param["end_time"],
        }
        ret_val, response = self._make_rest_call(RULES_HISTORY_ENDPOINT, action_result, params=query_params)
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        action_result.add_data(response)
        return action_result.set_status(phantom.APP_SUCCESS)

    def _handle_validate_rule(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))
        body = {"name": param["name"], "source": param["source"]}
        ret_val, response = self._make_rest_call(RULES_VALIDATE_ENDPOINT, action_result, json_data=body, method="post")
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        action_result.add_data(response)
        return action_result.set_status(phantom.APP_SUCCESS)

    def _handle_delete_rule(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))
        endpoint = RULE_ENDPOINT.format(id=param["rule_id"])
        ret_val, _ = self._make_rest_call(endpoint, action_result, method="delete")
        if phantom.is_fail(ret_val):
            return action_result.get_status()
        return action_result.set_status(phantom.APP_SUCCESS, "Rule deleted successfully")

    def _handle_get_rule(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))
        endpoint = RULE_ENDPOINT.format(id=param["rule_id"])
        ret_val, response = self._make_rest_call(endpoint, action_result)
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        action_result.add_data(response)
        return action_result.set_status(phantom.APP_SUCCESS)

    def _handle_update_rule(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))
        endpoint = RULE_ENDPOINT.format(id=param["rule_id"])
        body = {}
        for key in ("name", "source", "severity", "description"):
            if param.get(key):
                body[key] = param[key]

        ret_val, response = self._make_rest_call(endpoint, action_result, json_data=body, method="put")
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        action_result.add_data(response)
        return action_result.set_status(phantom.APP_SUCCESS)

    def _handle_activate_rule(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))
        endpoint = RULE_ACTIVATE_ENDPOINT.format(id=param["rule_id"])
        ret_val, response = self._make_rest_call(endpoint, action_result, method="post")
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        action_result.add_data(response)
        return action_result.set_status(phantom.APP_SUCCESS)

    def _handle_deactivate_rule(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))
        endpoint = RULE_DEACTIVATE_ENDPOINT.format(id=param["rule_id"])
        ret_val, response = self._make_rest_call(endpoint, action_result, method="post")
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        action_result.add_data(response)
        return action_result.set_status(phantom.APP_SUCCESS)

    def _handle_get_rule_history(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))
        endpoint = RULE_HISTORY_ENDPOINT.format(id=param["rule_id"])
        query_params = {}
        if param.get("start_time"):
            query_params["classification_created_at[gte]"] = param["start_time"]
        if param.get("end_time"):
            query_params["classification_created_at[lte]"] = param["end_time"]

        ret_val, response = self._make_rest_call(endpoint, action_result, params=query_params)
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        action_result.add_data(response)
        return action_result.set_status(phantom.APP_SUCCESS)

    # --- Tasks ---

    def _handle_get_task(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))
        endpoint = TASK_ENDPOINT.format(id=param["task_id"])
        ret_val, response = self._make_rest_call(endpoint, action_result)
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        action_result.add_data(response)
        action_result.update_summary({"task_state": response.get("state", "unknown")})
        return action_result.set_status(phantom.APP_SUCCESS)

    # --- User Reports ---

    def _handle_list_user_reports(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))
        query_params = {}
        if param.get("start_time"):
            query_params["reported_at[gte]"] = param["start_time"]
        if param.get("end_time"):
            query_params["reported_at[lt]"] = param["end_time"]
        if param.get("limit"):
            query_params["limit"] = self._clamp_limit(param.get("limit"))

        ret_val, response = self._make_rest_call(USER_REPORTS_ENDPOINT, action_result, params=query_params)
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        reports = response.get("user_reports", [])
        for r in reports:
            action_result.add_data(r)
        action_result.update_summary({"total_reports": response.get("count", len(reports))})
        return action_result.set_status(phantom.APP_SUCCESS)

    # --- Users/Roles ---

    def _handle_assign_role(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))
        body = {"email_address": param["email_address"], "role_title": param["role_title"]}
        ret_val, _ = self._make_rest_call(ASSIGN_ROLE_ENDPOINT, action_result, json_data=body, method="put")
        if phantom.is_fail(ret_val):
            return action_result.get_status()
        return action_result.set_status(phantom.APP_SUCCESS, "Role assigned successfully")

    # --- SCIM ---

    def _handle_list_scim_resource_types(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))
        ret_val, response = self._make_rest_call(SCIM_RESOURCE_TYPES_ENDPOINT, action_result)
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        resources = response.get("Resources", [])
        for r in resources:
            action_result.add_data(r)
        action_result.update_summary({"total_resource_types": len(resources)})
        return action_result.set_status(phantom.APP_SUCCESS)

    def _handle_get_scim_resource_type(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))
        endpoint = SCIM_RESOURCE_TYPE_ENDPOINT.format(id=param["resource_type_id"])
        ret_val, response = self._make_rest_call(endpoint, action_result)
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        action_result.add_data(response)
        return action_result.set_status(phantom.APP_SUCCESS)

    def _handle_list_scim_users(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))
        query_params = {
            "count": min(int(param.get("count", 100)), SCIM_MAX_COUNT),
            "startIndex": max(int(param.get("start_index", 1)), 1),
        }
        if param.get("filter"):
            query_params["filter"] = param["filter"]

        ret_val, response = self._make_rest_call(SCIM_USERS_ENDPOINT, action_result, params=query_params)
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        users = response.get("Resources", [])
        for u in users:
            action_result.add_data(u)
        action_result.update_summary({"total_results": response.get("totalResults", len(users))})
        return action_result.set_status(phantom.APP_SUCCESS)

    def _handle_create_scim_user(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))
        body = {
            "userName": param["user_name"],
            "name": {"givenName": param["given_name"], "familyName": param["family_name"]},
            "emails": [{"value": param["email"], "type": "work", "primary": True}],
            "active": param.get("active", True),
            "schemas": ["urn:ietf:params:scim:schemas:core:2.0:User"],
        }
        ret_val, response = self._make_rest_call(SCIM_USERS_ENDPOINT, action_result, json_data=body, method="post")
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        action_result.add_data(response)
        action_result.update_summary({"user_id": response.get("id", "")})
        return action_result.set_status(phantom.APP_SUCCESS)

    def _handle_get_scim_user(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))
        endpoint = SCIM_USER_ENDPOINT.format(id=param["user_id"])
        ret_val, response = self._make_rest_call(endpoint, action_result)
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        action_result.add_data(response)
        return action_result.set_status(phantom.APP_SUCCESS)

    def _handle_delete_scim_user(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))
        endpoint = SCIM_USER_ENDPOINT.format(id=param["user_id"])
        ret_val, _ = self._make_rest_call(endpoint, action_result, method="delete")
        if phantom.is_fail(ret_val):
            return action_result.get_status()
        return action_result.set_status(phantom.APP_SUCCESS, "SCIM user deleted successfully")

    def _handle_update_scim_user(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))
        endpoint = SCIM_USER_ENDPOINT.format(id=param["user_id"])
        body = {
            "userName": param["user_name"],
            "name": {"givenName": param["given_name"], "familyName": param["family_name"]},
            "emails": [{"value": param["email"], "type": "work", "primary": True}],
            "active": param.get("active", True),
            "schemas": ["urn:ietf:params:scim:schemas:core:2.0:User"],
        }
        ret_val, response = self._make_rest_call(endpoint, action_result, json_data=body, method="put")
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        action_result.add_data(response)
        return action_result.set_status(phantom.APP_SUCCESS)

    def _handle_patch_scim_user(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))
        endpoint = SCIM_USER_ENDPOINT.format(id=param["user_id"])
        try:
            operations = json.loads(param["operations_json"])
        except (json.JSONDecodeError, TypeError) as e:
            return action_result.set_status(phantom.APP_ERROR, f"Invalid operations_json: {e!s}")

        body = {
            "schemas": ["urn:ietf:params:scim:api:messages:2.0:PatchOp"],
            "Operations": operations,
        }
        ret_val, response = self._make_rest_call(endpoint, action_result, json_data=body, method="patch")
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        action_result.add_data(response)
        return action_result.set_status(phantom.APP_SUCCESS)

    def _handle_validate_scim_auth(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))
        ret_val, response = self._make_rest_call(SCIM_VALIDATE_AUTH_ENDPOINT, action_result)
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        action_result.add_data(response)
        return action_result.set_status(phantom.APP_SUCCESS)

    def _handle_list_scim_schemas(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))
        ret_val, response = self._make_rest_call(SCIM_SCHEMAS_ENDPOINT, action_result)
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        schemas = response.get("Resources", [])
        for s in schemas:
            action_result.add_data(s)
        action_result.update_summary({"total_schemas": len(schemas)})
        return action_result.set_status(phantom.APP_SUCCESS)

    def _handle_get_scim_schema(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))
        endpoint = SCIM_SCHEMA_ENDPOINT.format(id=param["schema_id"])
        ret_val, response = self._make_rest_call(endpoint, action_result)
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        action_result.add_data(response)
        return action_result.set_status(phantom.APP_SUCCESS)

    def _handle_get_scim_service_provider_config(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))
        ret_val, response = self._make_rest_call(SCIM_SERVICE_PROVIDER_CONFIG_ENDPOINT, action_result)
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        action_result.add_data(response)
        return action_result.set_status(phantom.APP_SUCCESS)

    # =========================================================================
    # Connector lifecycle
    # =========================================================================

    def initialize(self):
        self.debug_print("Initializing Sublime Security connector")
        config = self.get_config()

        region = config.get("region", "NA-East")
        if region == "Custom":
            self._base_url = config.get("base_url", "").rstrip("/")
            if not self._base_url:
                return self.set_status(phantom.APP_ERROR, "Custom region selected but no base URL provided")
        else:
            self._base_url = BASE_URLS.get(region, BASE_URLS["NA-East"])

        self._api_key = config["api_key"]
        self._verify = config.get("verify_server_cert", True)

        self._headers = {
            "Authorization": f"Bearer {self._api_key}",
            "Content-Type": "application/json",
            "Accept": "application/json",
        }

        return phantom.APP_SUCCESS

    def handle_action(self, param):
        self.debug_print("action_id", self.get_action_identifier())

        action_mapping = {
            "test_connectivity": self._handle_test_connectivity,
            # BinExplode
            "upload_binary": self._handle_upload_binary,
            "get_binexplode_results": self._handle_get_binexplode_results,
            # Enrichment
            "analyze_link": self._handle_analyze_link,
            # Audit Log
            "list_audit_events": self._handle_list_audit_events,
            "list_audit_event_types": self._handle_list_audit_event_types,
            "get_audit_event": self._handle_get_audit_event,
            # Hunt Jobs
            "start_hunt_job": self._handle_start_hunt_job,
            "get_hunt_job": self._handle_get_hunt_job,
            "get_hunt_job_results": self._handle_get_hunt_job_results,
            # Lists
            "list_lists": self._handle_list_lists,
            "create_list": self._handle_create_list,
            "delete_list": self._handle_delete_list,
            "get_list": self._handle_get_list,
            "patch_list": self._handle_patch_list,
            "get_list_entries": self._handle_get_list_entries,
            "set_list_entries": self._handle_set_list_entries,
            "delete_list_entry": self._handle_delete_list_entry,
            "get_list_entry": self._handle_get_list_entry,
            "add_list_entry": self._handle_add_list_entry,
            # Raw Message Processing
            "process_raw_message": self._handle_process_raw_message,
            # Mailboxes
            "list_mailboxes": self._handle_list_mailboxes,
            # Message Groups (bulk)
            "list_message_groups": self._handle_list_message_groups,
            "dismiss_message_groups": self._handle_dismiss_message_groups,
            "hunt_message_groups": self._handle_hunt_message_groups,
            "get_hunt_results": self._handle_get_hunt_results,
            "quarantine_message_groups": self._handle_quarantine_message_groups,
            "graymail_message_groups": self._handle_graymail_message_groups,
            "restore_message_groups": self._handle_restore_message_groups,
            "review_message_groups": self._handle_review_message_groups,
            "search_message_groups": self._handle_search_message_groups,
            "trash_message_groups": self._handle_trash_message_groups,
            # Message Groups (single)
            "get_message_group": self._handle_get_message_group,
            "dismiss_message_group": self._handle_dismiss_message_group,
            "quarantine_message_group": self._handle_quarantine_message_group,
            "restore_message_group": self._handle_restore_message_group,
            "share_with_sublime": self._handle_share_with_sublime,
            "trash_message_group": self._handle_trash_message_group,
            # Messages
            "analyze_raw_message": self._handle_analyze_raw_message,
            "render_attachment_image": self._handle_render_attachment_image,
            "get_attack_score_raw": self._handle_get_attack_score_raw,
            "create_message": self._handle_create_message,
            "get_action_state": self._handle_get_action_state,
            "get_message": self._handle_get_message,
            "action_message": self._handle_action_message,
            "analyze_message_by_id": self._handle_analyze_message_by_id,
            "get_asa_report": self._handle_get_asa_report,
            "get_attachment_image": self._handle_get_attachment_image,
            "get_attack_score": self._handle_get_attack_score,
            "get_message_image": self._handle_get_message_image,
            "get_message_eml": self._handle_get_message_eml,
            "get_message_image_link": self._handle_get_message_image_link,
            "set_access_justification": self._handle_set_access_justification,
            "get_message_data_model": self._handle_get_message_data_model,
            "restore_message": self._handle_restore_message,
            "trash_message": self._handle_trash_message,
            # Rules
            "list_rules": self._handle_list_rules,
            "create_rule": self._handle_create_rule,
            "list_rule_history": self._handle_list_rule_history,
            "validate_rule": self._handle_validate_rule,
            "delete_rule": self._handle_delete_rule,
            "get_rule": self._handle_get_rule,
            "update_rule": self._handle_update_rule,
            "activate_rule": self._handle_activate_rule,
            "deactivate_rule": self._handle_deactivate_rule,
            "get_rule_history": self._handle_get_rule_history,
            # Tasks
            "get_task": self._handle_get_task,
            # User Reports
            "list_user_reports": self._handle_list_user_reports,
            # Users/Roles
            "assign_role": self._handle_assign_role,
            # SCIM
            "list_scim_resource_types": self._handle_list_scim_resource_types,
            "get_scim_resource_type": self._handle_get_scim_resource_type,
            "list_scim_users": self._handle_list_scim_users,
            "create_scim_user": self._handle_create_scim_user,
            "get_scim_user": self._handle_get_scim_user,
            "delete_scim_user": self._handle_delete_scim_user,
            "update_scim_user": self._handle_update_scim_user,
            "patch_scim_user": self._handle_patch_scim_user,
            "validate_scim_auth": self._handle_validate_scim_auth,
            "list_scim_schemas": self._handle_list_scim_schemas,
            "get_scim_schema": self._handle_get_scim_schema,
            "get_scim_service_provider_config": self._handle_get_scim_service_provider_config,
        }

        action = self.get_action_identifier()
        action_execution_status = phantom.APP_SUCCESS

        if action in action_mapping:
            action_execution_status = action_mapping[action](param)

        return action_execution_status

    def finalize(self):
        return phantom.APP_SUCCESS


# =========================================================================
# REST Handler - Inbound Webhook from Sublime Security
# =========================================================================
#
# Configure the Sublime Security webhook to POST to:
#   https://<soar-host>/rest/handler/<app_name>_<appid>/<asset_name>/webhook
#
# Expected payload (flexible - supports single or multiple message groups):
#   {
#     "message_groups": [
#       {
#         "id": "<canonical_id>",
#         "review_status": "...",
#         "classification": "...",
#         "state": "...",
#         "flagged_rules": [...],
#         "messages": [
#           {"id": "...", "subject": "...", "sender": {...}, "recipients": [...], ...}
#         ]
#       }
#     ]
#   }
#
# For each message_group, a container is created and each message in
# messages[] becomes an artifact on that container.


def _build_artifact_from_message(message, container_id):
    """Build a SOAR artifact dict from a Sublime message object."""
    sender = message.get("sender") or {}
    mailbox = message.get("mailbox") or {}
    recipients = message.get("recipients") or []
    recipient_emails = [r.get("email", "") for r in recipients if isinstance(r, dict)]

    cef = {
        "messageId": message.get("id", ""),
        "subject": message.get("subject", ""),
        "senderEmail": sender.get("email", ""),
        "senderDisplayName": sender.get("display_name", ""),
        "mailboxEmail": mailbox.get("email", ""),
        "mailboxId": mailbox.get("id", ""),
        "recipients": ", ".join(recipient_emails),
        "createdAt": message.get("created_at", ""),
        "delivered": message.get("delivered"),
        "readAt": message.get("read_at"),
        "repliedAt": message.get("replied_at"),
        "forwardedAt": message.get("forwarded_at"),
    }
    # Remove keys with None values
    cef = {k: v for k, v in cef.items() if v not in (None, "")}

    return {
        "name": message.get("subject", "Sublime Message"),
        "label": "email",
        "container_id": container_id,
        "source_data_identifier": message.get("id", ""),
        "cef": cef,
        "cef_types": {
            "messageId": ["message id"],
            "senderEmail": ["email"],
            "mailboxEmail": ["email"],
            "recipients": ["email"],
        },
        "data": message,
        "run_automation": False,
    }


def handle_request(request, path_parts):
    """REST handler for inbound Sublime Security webhooks.

    Creates a container for each message_group in the payload and an artifact
    for each message in that group.
    """
    import json as _json

    try:
        from django.http import JsonResponse
    except ImportError:  # pragma: no cover
        JsonResponse = None

    import phantom.rules as ph_rules

    def _respond(status_code, body):
        if JsonResponse is not None:
            return JsonResponse(body, status=status_code)
        return _json.dumps(body)

    if request.method != "POST":
        return _respond(405, {"error": "Method Not Allowed. Use POST."})

    # Parse JSON body
    try:
        raw_body = request.body.decode("utf-8") if isinstance(request.body, (bytes, bytearray)) else request.body
        payload = _json.loads(raw_body) if raw_body else {}
    except Exception as e:
        return _respond(400, {"error": f"Invalid JSON: {e!s}"})

    # Accept either {"message_groups": [...]} or a single group object
    if isinstance(payload, dict) and "message_groups" in payload:
        groups = payload.get("message_groups") or []
    elif isinstance(payload, dict) and payload.get("id"):
        groups = [payload]
    elif isinstance(payload, list):
        groups = payload
    else:
        return _respond(400, {"error": "Payload must contain 'message_groups' or a message group object"})

    containers_created = []
    artifacts_created = 0
    errors = []

    for group in groups:
        if not isinstance(group, dict):
            continue

        group_id = group.get("id", "unknown")
        messages = group.get("messages") or []

        # Build container name from first message subject if available
        name = "Sublime Security: "
        if messages and isinstance(messages[0], dict) and messages[0].get("subject"):
            name += messages[0]["subject"]
        else:
            name += f"Message Group {group_id}"

        # Severity mapping from flagged rules
        severity = "medium"
        flagged_rules = group.get("flagged_rules") or []

        container = {
            "name": name,
            "description": f"Sublime Security webhook for message group {group_id}",
            "source_data_identifier": group_id,
            "label": "events",
            "severity": severity,
            "tags": [t for r in flagged_rules if isinstance(r, dict) for t in (r.get("tags") or [])],
            "data": group,
        }

        try:
            success, message, container_id = ph_rules.save_container(container)
            if not success or not container_id:
                errors.append({"group_id": group_id, "error": f"save_container failed: {message}"})
                continue
        except Exception as e:
            errors.append({"group_id": group_id, "error": f"save_container exception: {e!s}"})
            continue

        containers_created.append({"group_id": group_id, "container_id": container_id})

        # Build an artifact per message
        artifacts = []
        for idx, msg in enumerate(messages):
            if not isinstance(msg, dict):
                continue
            artifact = _build_artifact_from_message(msg, container_id)
            # Run automation only on the last artifact
            if idx == len(messages) - 1:
                artifact["run_automation"] = True
            artifacts.append(artifact)

        if artifacts:
            try:
                success, message, artifact_ids = ph_rules.save_artifacts(artifacts)
                if success:
                    artifacts_created += len(artifacts)
                else:
                    errors.append({"group_id": group_id, "error": f"save_artifacts failed: {message}"})
            except Exception as e:
                errors.append({"group_id": group_id, "error": f"save_artifacts exception: {e!s}"})

    response_body = {
        "status": "success" if not errors else "partial_success",
        "containers_created": len(containers_created),
        "artifacts_created": artifacts_created,
        "containers": containers_created,
    }
    if errors:
        response_body["errors"] = errors

    return _respond(200, response_body)


if __name__ == "__main__":
    import sys

    import pudb

    pudb.set_trace()

    connector = SublimeSecurityConnector()
    connector.print_progress_message = True

    sys.exit(0)
