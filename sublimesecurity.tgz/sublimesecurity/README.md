<img src="logo_dark.svg" width="300">

# Sublime Security — Splunk SOAR App

Publisher: Splunk SOAR Community
Connector Version: 1.0.0
Product Vendor: Sublime Security
Product Name: Sublime Platform
Minimum Product Version: 6.3.0

A community-maintained Splunk SOAR connector for the [Sublime Security
Platform](https://sublime.security) API. Integrates with the Sublime Security Platform
API to perform email security operations including binexplode analysis, link analysis,
audit log management, hunt jobs, list management, message group actions, message
analysis, rule management, and SCIM user provisioning — plus an inbound REST handler
for Sublime webhooks.

## Features

- **Full Sublime Platform API coverage** — audit log, hunt jobs, lists, message groups,
  messages, rules, SCIM, tasks, user reports, and enrichment actions
- **Binexplode analysis** — submit files via Vault ID or base64 and retrieve scan trees
- **Link analysis (`ml.link_analysis`)** — returns disposition, brand, confidence, and
  automatically saves page screenshots to the SOAR Vault
- **Vault integration everywhere** — any action that accepts or returns a file works with
  Splunk SOAR Vault IDs. EML downloads, rendered message images, attachment renders, and
  link analysis screenshots are automatically stored in the Vault
- **List entry CSV workflow** — export list entries to Vault as CSV, and bulk-import
  entries from a CSV Vault file
- **Inbound webhook handler** — receive Sublime webhooks at
  `https://<soar-host>/rest/handler/sublimesecurity/<asset_name>/webhook` to
  automatically create containers and artifacts per message group

## Asset Configuration

| Parameter | Required | Description |
|-----------|----------|-------------|
| `region` | Yes | Sublime Security region. One of: NA-East, NA-West, Canada, UK (London), Europe (Dublin), Australia, Custom. |
| `base_url` | No | Custom base URL (only used when region is set to Custom). |
| `api_key` | Yes | API key for Sublime Security. Found in the Sublime dashboard under Automate > API. |
| `verify_server_cert` | No | Verify the server certificate. Default: true. |

### Regional Base URLs

| Region | Base URL |
|--------|----------|
| NA-East | https://platform.sublime.security |
| NA-West | https://na-west.platform.sublime.security |
| Canada | https://ca.platform.sublime.security |
| UK (London) | https://uk.platform.sublime.security |
| Europe (Dublin) | https://eu.platform.sublime.security |
| Australia | https://au.platform.sublime.security |

## File Inputs

Actions that accept file data (upload binary, process raw message, analyze raw message,
render attachment image, get attack score raw, create message) support two input modes:

- **`vault_id`** — a Vault ID of a file already stored in Splunk SOAR
- **`base64_data`** — the raw base64-encoded file contents

Provide exactly one. When a Vault ID is supplied, the connector retrieves the file
contents from the SOAR Vault before sending to Sublime Security.

## Inbound Webhook (REST Handler)

The app exposes a REST handler for receiving webhooks from Sublime Security. Configure
Sublime to POST events to:

```
https://<soar-host>/rest/handler/sublimesecurity/<asset_name>/webhook
```

For each event received, the handler will:

1. Create a SOAR container (deduplicated on the canonical message ID)
2. Create one artifact per message, populated with CEF fields for message ID, subject,
   sender email, mailbox, recipients, flagged rules, and triggered actions
3. Run playbook automation on each created artifact

### Authenticating inbound webhooks with `ph-auth-token`

The webhook REST handler is declared with `"requires_auth": true`, which means Splunk
SOAR expects every inbound POST to carry a `ph-auth-token` header bound to an
**Automation** user. You must provision this automation account before enabling the
webhook.

**Provision the automation user** (see the Splunk Phantom
[PlatformAPI docs](https://docs.splunk.com/Documentation/Phantom/4.10.7/PlatformAPI/Using)):

1. Log in to Splunk SOAR / Phantom as an administrative user.
2. From the Main Menu, select **Administration**.
3. Select **User Management > Users**.
4. Click **+ User** to add a new user.
5. Select **Automation** as the user type.
6. Provide a user name and fill in **Allowed IPs**. Use `any` for unrestricted access,
   or enter the Sublime Security webhook egress IPs (see below) as a comma-separated
   list of single IPs or netmasks.
7. Choose one or more roles. The default **Automation** role has a broad set of
   permissions suitable for a service account. If you want a narrower permission set,
   create a custom role and assign it here.
8. Click **Create**.

After the user is created, SOAR will surface a configuration block that looks like:

```json
{
  "ph-auth-token": "cs76HmsNcWjkd6kWmGzUa18LcbtQx95vMW1bsdeP7gU=",
  "server": "https://172.16.210.137"
}
```

| Parameter | Type | Description |
|-----------|------|-------------|
| `ph-auth-token` | String | Generated authorization token. Only valid from the IPs listed in the user's **Allowed IPs** panel. |
| `server` | String/URL | Base URL to POST to this SOAR instance. |

Copy the `ph-auth-token` and add it to the Sublime webhook Action. In the Sublime
dashboard, open your webhook Action, scroll to **Headers**, and add:

| Header | Value |
|--------|-------|
| `ph-auth-token` | *(value from the automation user block above)* |

See Sublime's docs for the UI walkthrough:
<https://docs.sublime.security/docs/webhooks>

### Expected source IPs (Sublime Security webhook egress)

Add these to the automation user's **Allowed IPs** and to any upstream firewall or
reverse proxy. Also listed in the app's `webhook.ip_allowlist`:

```
66.22.9.207
66.22.9.208
66.22.9.209
```

### Verifying the `X-Sublime-Signature` header

In addition to `ph-auth-token`, the webhook handler verifies the `X-Sublime-Signature`
header when a signing secret is configured on the asset (`webhook_signing_secret`).
This gives you defense in depth: SOAR authenticates the caller (`ph-auth-token`) and
the app authenticates the payload (Sublime's HMAC).

Sublime includes the signature in the `X-Sublime-Signature` HTTP header. To retrieve
your webhook Action's signing secret, select the Action from the Sublime **Actions**
page and click **Click to reveal** (or **Copy**).

The header has the form:

```
t=1626139320,v0=3d35d777510a7ccf73ded723f141b0ada2986aebe63c4e45a9c7e4bb1abaca06
```

- `t=` is the Unix timestamp at which Sublime signed the payload.
- `v0=` is an HMAC-SHA256 signature. `v0` is currently the only valid scheme —
  ignore all other schemes to prevent downgrade attacks.

**Replay protection.** Sublime includes the signing timestamp in the signed payload,
so an attacker cannot alter `t=` without invalidating the signature. If the timestamp
is older than `webhook_signature_tolerance_seconds` (default 300), the app rejects
the request.

**Signature computation.** The connector reproduces Sublime's signing algorithm:

1. Split `X-Sublime-Signature` on `,` and then on `=`; keep `t` and every `v0`.
2. Build `signed_payload = f"{timestamp}.{raw_request_body}"`.
3. Compute `HMAC_SHA256(signing_secret, signed_payload)`.
4. Compare the computed hex digest to each received `v0` signature using
   `hmac.compare_digest` (constant-time) to prevent timing attacks.

If verification fails, the handler returns HTTP 401 and does not create a container.
The implementation lives in `_verify_sublime_signature` in
`sublimesecurity_connector.py`.

## Actions

### Connectivity
- **test connectivity** — validates the asset configuration by calling the audit log event types endpoint

### BinExplode
- **upload binary** — upload a binary (via Vault ID or base64) to be binexploded
- **get binexplode results** — retrieve results of a binexplode scan by task ID

### Enrichment
- **analyze link** — analyze a URL with `ml.link_analysis`; screenshot is saved to Vault automatically

### Audit Log
- **list audit events** — list events with optional time, type, and user filters
- **list audit event types** — enumerate all available audit event types
- **get audit event** — retrieve a single audit event by ID

### Hunt Jobs
- **start hunt job** — start a new hunt job with MQL source and time range
- **get hunt job** — check status of a hunt job
- **get hunt job results** — retrieve the message groups produced by a completed hunt

### Lists
- **list lists** — retrieve all organization lists
- **create list** — create a new named string list
- **delete list** — delete a list by ID
- **get list** — get a single list's metadata
- **patch list** — patch a list's description
- **get list entries** — retrieve list entries; optionally save them to the Vault as CSV
- **set list entries** — replace entries from either a comma-separated string or a CSV vault file
- **delete list entry** — delete a single entry from a list
- **get list entry** — check a single entry or a comma-separated list of entries for presence
- **add list entry** — add a single entry to a list

### Raw Message Processing
- **process raw message** — submit a raw EML to Sublime's Live Flow for full analysis

### Mailboxes
- **list mailboxes** — list connected mailboxes with filters

### Message Groups (bulk)
- **list message groups** — list message groups with extensive filters
- **dismiss message groups** — dismiss multiple message groups
- **hunt message groups** — hunt message groups (deprecated; prefer start hunt job)
- **get hunt results** — get results of a message group hunt (deprecated)
- **quarantine message groups** — quarantine multiple groups
- **graymail message groups** — move groups to graymail
- **restore message groups** — restore multiple groups
- **review message groups** — review groups with classification and action
- **search message groups** — search groups across multiple fields
- **trash message groups** — trash multiple groups

### Message Groups (single)
- **get message group** — get a single canonical message group
- **dismiss message group** — dismiss a single group
- **quarantine message group** — quarantine a single group
- **restore message group** — restore a single group
- **share with sublime** — share a message group with Sublime for community detection
- **trash message group** — trash a single group

### Messages
- **analyze raw message** — analyze raw EML against rules and queries
- **render attachment image** — render an attachment image from raw bytes
- **get attack score raw** — evaluate attack score for a raw EML
- **create message** — create a message from a raw EML
- **get action state** — retrieve manual action state for a canonical group
- **get message** — retrieve a message by ID
- **action message** — perform an action (quarantine, trash, restore, etc.) on a message
- **analyze message by id** — analyze an existing message against rules and queries
- **get asa report** — retrieve the ASA (Attack Surface Assessment) report
- **get attachment image** — retrieve PDF attachment image by MD5 hash
- **get attack score** — evaluate attack score against an existing message
- **get message image** — retrieve a rendered image of a message (saved to Vault)
- **get message eml** — retrieve raw EML (saved to Vault)
- **get message image link** — retrieve a temporary link to the message image
- **set access justification** — set access justification for a message
- **get message data model** — retrieve the full Message Data Model (MDM)
- **restore message** — restore a trashed message
- **trash message** — trash a single message

### Rules
- **list rules** — list all rules in the organization
- **create rule** — create a new detection, DLP, or triage rule
- **list rule history** — list history for all rules
- **validate rule** — validate MQL rule syntax without creating
- **delete rule** — delete a rule by ID
- **get rule** — retrieve a single rule
- **update rule** — update an existing rule
- **activate rule** — activate a rule
- **deactivate rule** — deactivate a rule
- **get rule history** — retrieve history of a specific rule

### Tasks
- **get task** — retrieve task status by ID

### User Reports
- **list user reports** — list user-submitted phishing reports

### Users / Roles
- **assign role** — assign a role to a user

### SCIM
- **list scim resource types** / **get scim resource type**
- **list scim users** / **create scim user** / **get scim user** / **delete scim user**
- **update scim user** / **patch scim user**
- **validate scim auth**
- **list scim schemas** / **get scim schema**
- **get scim service provider config**

## Contributors

- **Evan R. Kinney** — <evanrkinney@gmail.com> — Splunk SOAR Community

## License

Copyright (c) 2026 Splunk SOAR Community.

Licensed under the Apache License, Version 2.0. See
[LICENSE](https://www.apache.org/licenses/LICENSE-2.0) for the full text.
