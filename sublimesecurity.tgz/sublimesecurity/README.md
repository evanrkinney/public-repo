<img src="logo_dark.svg" width="300">

# Sublime Security — Splunk SOAR App

A community-maintained Splunk SOAR connector for the [Sublime Security
Platform](https://sublime.security) API. This app exposes 80+ actions spanning email
analysis, message group review, rule management, hunt jobs, list management, SCIM user
provisioning, and more — plus an inbound REST handler for Sublime webhooks.

## Features

- **Full Sublime Platform API coverage** — audit log, hunt jobs, lists, message groups,
  messages, rules, SCIM, tasks, user reports, and enrichment actions
- **Binexplode analysis** — submit files via Vault ID or base64 and retrieve scan trees
- **Link analysis (`ml.link_analysis`)** — returns disposition, brand, confidence, and
  automatically saves page screenshots to the SOAR Vault
- **Vault integration everywhere** — any action that accepts or returns a file works with
  Splunk SOAR Vault IDs. EML downloads, rendered message images, attachment renders, and
  link analysis screenshots are automatically stored in the Vault
- **List entry CSV workflow** — export list entries to Vault as CSV, and bulk-import
  entries from a CSV Vault file
- **Inbound webhook handler** — receive Sublime webhooks at
  `https://<soar-host>/rest/handler/sublimesecurity/<asset_name>/webhook` to
  automatically create containers and artifacts per message group

## Asset Configuration

| Field | Description |
|-------|-------------|
| **Region** | One of: NA-East, NA-West, Canada, UK (London), Europe (Dublin), Australia, or Custom |
| **Base URL** | Used only when Region is set to Custom |
| **API Key** | Sublime Security API key (from Dashboard > Automate > API) |
| **Verify Server Cert** | Default true |

## Documentation

See [CONNECTOR_README.md](CONNECTOR_README.md) for the full action reference.

## Contributors

- **Evan R. Kinney** — <evanrkinney@gmail.com> — Splunk SOAR Community

## License

Copyright (c) 2026 Splunk SOAR Community

Licensed under the Apache License, Version 2.0. See
[LICENSE](https://www.apache.org/licenses/LICENSE-2.0) for the full text.
