# Sublime Security

Publisher: Splunk SOAR Community
Connector Version: 1.0.0
Product Vendor: Sublime Security
Product Name: Sublime Platform
Minimum Product Version: 6.3.0

Integrates with the Sublime Security Platform API to perform email security operations
including binexplode analysis, link analysis, audit log management, hunt jobs, list
management, message group actions, message analysis, rule management, and SCIM user
provisioning.

## Asset Configuration

| Parameter | Required | Description |
|-----------|----------|-------------|
| `region` | Yes | Sublime Security region. One of: NA-East, NA-West, Canada, UK (London), Europe (Dublin), Australia, Custom. |
| `base_url` | No | Custom base URL (only used when region is set to Custom). |
| `api_key` | Yes | API key for Sublime Security. Found in the Sublime dashboard under Automate > API. |
| `verify_server_cert` | No | Verify the server certificate. Default: true. |

### Regional Base URLs

| Region | Base URL |
|--------|----------|
| NA-East | https://platform.sublime.security |
| NA-West | https://na-west.platform.sublime.security |
| Canada | https://ca.platform.sublime.security |
| UK (London) | https://uk.platform.sublime.security |
| Europe (Dublin) | https://eu.platform.sublime.security |
| Australia | https://au.platform.sublime.security |

## File Inputs

Actions that accept file data (upload binary, process raw message, analyze raw message,
render attachment image, get attack score raw, create message) support two input modes:

- **`vault_id`** — a Vault ID of a file already stored in Splunk SOAR
- **`base64_data`** — the raw base64-encoded file contents

Provide exactly one. When a Vault ID is supplied, the connector retrieves the file
contents from the SOAR Vault before sending to Sublime Security.

## Inbound Webhook (REST Handler)

The app exposes a REST handler for receiving webhooks from Sublime Security. Configure
Sublime to POST message group events to:

```
https://<soar-host>/rest/handler/sublimesecurity/<asset_name>/webhook
```

The handler accepts either a single message group object or a payload shaped like
`{"message_groups": [...]}`. For each message group received, the handler will:

1. Create a SOAR container (deduplicated on the canonical message group ID)
2. Create one artifact per message inside that group, populated with CEF fields for
   message ID, subject, sender email, mailbox, and recipients
3. Run playbook automation on the last artifact of each group

## Actions

### Connectivity
- **test connectivity** — validates the asset configuration by calling the audit log event types endpoint

### BinExplode
- **upload binary** — upload a binary (via Vault ID or base64) to be binexploded
- **get binexplode results** — retrieve results of a binexplode scan by task ID

### Enrichment
- **analyze link** — analyze a URL with `ml.link_analysis`; screenshot is saved to Vault automatically

### Audit Log
- **list audit events** — list events with optional time, type, and user filters
- **list audit event types** — enumerate all available audit event types
- **get audit event** — retrieve a single audit event by ID

### Hunt Jobs
- **start hunt job** — start a new hunt job with MQL source and time range
- **get hunt job** — check status of a hunt job
- **get hunt job results** — retrieve the message groups produced by a completed hunt

### Lists
- **list lists** — retrieve all organization lists
- **create list** — create a new named string list
- **delete list** — delete a list by ID
- **get list** — get a single list's metadata
- **update list** — update a list's description
- **get list entries** — retrieve list entries; optionally save them to the Vault as CSV
- **set list entries** — replace entries from either a comma-separated string or a CSV vault file
- **delete list entry** — delete a single entry from a list
- **get list entry** — check a single entry or a comma-separated list of entries for presence
- **add list entry** — add a single entry to a list

### Raw Message Processing
- **process raw message** — submit a raw EML to Sublime's Live Flow for full analysis

### Mailboxes
- **list mailboxes** — list connected mailboxes with filters

### Message Groups (bulk)
- **list message groups** — list message groups with extensive filters
- **dismiss message groups** — dismiss multiple message groups
- **hunt message groups** — hunt message groups (deprecated; prefer start hunt job)
- **get hunt results** — get results of a message group hunt (deprecated)
- **quarantine message groups** — quarantine multiple groups
- **graymail message groups** — move groups to graymail
- **restore message groups** — restore multiple groups
- **review message groups** — review groups with classification and action
- **search message groups** — search groups across multiple fields
- **trash message groups** — trash multiple groups

### Message Groups (single)
- **get message group** — get a single canonical message group
- **dismiss message group** — dismiss a single group
- **quarantine message group** — quarantine a single group
- **restore message group** — restore a single group
- **share with sublime** — share a message group with Sublime for community detection
- **trash message group** — trash a single group

### Messages
- **analyze raw message** — analyze raw EML against rules and queries
- **render attachment image** — render an attachment image from raw bytes
- **get attack score raw** — evaluate attack score for a raw EML
- **create message** — create a message from a raw EML
- **get action state** — retrieve manual action state for a canonical group
- **get message** — retrieve a message by ID
- **action message** — perform an action (quarantine, trash, restore, etc.) on a message
- **analyze message by id** — analyze an existing message against rules and queries
- **get asa report** — retrieve the ASA (Attack Surface Assessment) report
- **get attachment image** — retrieve PDF attachment image by MD5 hash
- **get attack score** — evaluate attack score against an existing message
- **get message image** — retrieve a rendered image of a message (saved to Vault)
- **get message eml** — retrieve raw EML (saved to Vault)
- **get message image link** — retrieve a temporary link to the message image
- **set access justification** — set access justification for a message
- **get message data model** — retrieve the full Message Data Model (MDM)
- **restore message** — restore a trashed message
- **trash message** — trash a single message

### Rules
- **list rules** — list all rules in the organization
- **create rule** — create a new detection, DLP, or triage rule
- **list rule history** — list history for all rules
- **validate rule** — validate MQL rule syntax without creating
- **delete rule** — delete a rule by ID
- **get rule** — retrieve a single rule
- **update rule** — update an existing rule
- **activate rule** — activate a rule
- **deactivate rule** — deactivate a rule
- **get rule history** — retrieve history of a specific rule

### Tasks
- **get task** — retrieve task status by ID

### User Reports
- **list user reports** — list user-submitted phishing reports

### Users / Roles
- **assign role** — assign a role to a user

### SCIM
- **list scim resource types** / **get scim resource type**
- **list scim users** / **create scim user** / **get scim user** / **delete scim user**
- **update scim user** / **patch scim user**
- **validate scim auth**
- **list scim schemas** / **get scim schema**
- **get scim service provider config**

## Contributors

- Evan R. Kinney — <evanrkinney@gmail.com> — Splunk SOAR Community

## License

Copyright (c) 2026 Splunk SOAR Community. Licensed under the Apache License, Version 2.0.
