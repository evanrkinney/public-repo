"""Sublime Security connector for Splunk SOAR.

Single-file SDK app. Section banners (`# ===`) mark major regions for
navigation. The SDK generates the manifest from the decorators below
at `soarapps package build` time.
"""
import base64
import csv as csv_mod
import hashlib
import hmac
import io
import json as _json
import time
from collections.abc import Iterator
from typing import Any

import httpx
from soar_sdk.abstract import SOARClient
from soar_sdk.action_results import ActionOutput, OutputField
from soar_sdk.app import App
from soar_sdk.asset import AssetField, BaseAsset
from soar_sdk.exceptions import ActionFailure
from soar_sdk.logging import getLogger
from soar_sdk.models.artifact import Artifact
from soar_sdk.models.container import Container
from soar_sdk.params import OnPollParams, Param, Params
from soar_sdk.webhooks.models import WebhookRequest, WebhookResponse


# =============================================================================
# Constants
# =============================================================================
REGION_BASE_URLS = {
    "NA-East": "https://platform.sublime.security",
    "NA-West": "https://na-west.platform.sublime.security",
    "Canada": "https://ca.platform.sublime.security",
    "UK (London)": "https://uk.platform.sublime.security",
    "Europe (Dublin)": "https://eu.platform.sublime.security",
    "Australia": "https://au.platform.sublime.security",
}

SCIM_USER_SCHEMA = ["urn:ietf:params:scim:schemas:core:2.0:User"]
SCIM_PATCH_SCHEMA = ["urn:ietf:params:scim:api:messages:2.0:PatchOp"]
SCIM_MAX_COUNT = 1000

CLASSIFICATIONS = ["", "malicious", "benign", "unwanted", "simulation",
                   "graymail", "spam", "violation", "non-violation"]
REVIEW_CLASSIFICATIONS = ["malicious", "benign", "simulation", "graymail",
                          "spam", "skip", "violation", "non-violation"]
REPORT_LABELS = ["", "spam", "phishing", "false_positive", "false_negative",
                 "phishing_simulation", "graymail", "violation", "non-violation"]
MESSAGE_ACTIONS = ["", "restore", "warning_banner", "quarantine", "trash",
                   "move_to_spam", "move_to_graymail", "delete_calendar_events"]
RULE_TYPES = ["", "detection", "dlp", "triage"]
RULE_SEVERITIES = ["", "informational", "low", "medium", "high", "critical"]

log = getLogger()


def parse_csv(value: str | None) -> list[str]:
    if not value:
        return []
    return [v.strip() for v in str(value).split(",") if v.strip()]


# =============================================================================
# Asset
# =============================================================================
class SublimeAsset(BaseAsset):
    region: str = AssetField(
        default="NA-East",
        value_list=[*REGION_BASE_URLS.keys(), "Custom"],
        description="Sublime Security region (selects the API base URL). Choose 'Custom' to use base_url.",
    )
    base_url: str = AssetField(
        default="",
        description="Custom Sublime platform base URL (e.g. https://platform.example.com). Only used when region = Custom.",
    )
    api_key: str = AssetField(sensitive=True, description="Sublime Security API key")
    verify_server_cert: bool = AssetField(default=True, description="Verify TLS certificate")

    webhook_container_label: str = AssetField(
        default="events",
        description="SOAR container label for webhook-created containers",
    )
    webhook_container_severity: str = AssetField(
        default="medium",
        value_list=["low", "medium", "high", "use alert severity"],
        description="Severity for webhook containers; 'use alert severity' inherits the highest flagged-rule severity.",
    )
    webhook_container_sensitivity: str = AssetField(
        default="amber",
        value_list=["white", "green", "amber", "red"],
        description="Sensitivity (TLP) for webhook containers",
    )
    webhook_pull_eml: bool = AssetField(
        default=False,
        description="Fetch the original .eml from Sublime, attach to the container vault, and create a vaultId artifact.",
    )
    poll_source: str = AssetField(
        default="message_groups",
        value_list=["message_groups", "audit_logs"],
        description="What scheduled polling ingests: 'message_groups' (one container per flagged message group) or 'audit_logs' (one container per poll cycle, audit events as artifacts).",
    )

    webhook_signing_secret: str = AssetField(
        default="",
        sensitive=True,
        description="Signing secret from the Sublime webhook Action; used to verify the X-Sublime-Signature header. Leave blank to skip signature verification (SOAR ph-auth-token + IP allowlist only).",
    )
    webhook_signature_tolerance_seconds: int = AssetField(
        default=300,
        description="Max allowed age (seconds) of the X-Sublime-Signature timestamp before the request is rejected. Replay-protection window.",
    )


# =============================================================================
# App
# =============================================================================
# Headers Sublime sends with webhook deliveries (plus the standard ones SOAR
# users typically want to forward to the handler). The manifest's
# `allowed_headers` is what SOAR uses to decide which request headers to pass
# through — an empty list strips everything.
WEBHOOK_ALLOWED_HEADERS = [
    "Authorization",
    "Content-Type",
    "User-Agent",
    "X-Forwarded-For",
    "X-Real-IP",
    "X-Sublime-Event",
    "X-Sublime-Delivery-Id",
    "X-Sublime-Signature",
    "X-Sublime-Timestamp",
    "ph-auth-token",
]

# Sublime Security's published webhook source IPs per region
# (https://docs.sublime.security/docs/webhooks#source-ips). IPv6 is left
# wide-open because Sublime documents IPv6 source addresses as frequently
# changing. Operators on self-hosted Sublime deployments will need to add
# their own egress IPs on the asset's Webhook Settings tab.
WEBHOOK_IP_ALLOWLIST = [
    # platform.sublime.security (NA-East primary)
    "44.194.118.42/32", "34.197.67.5/32",
    # na-east-2 / na-east-3 / na-east-4
    "3.132.96.216/32", "3.21.140.176/32",
    "52.23.100.46/32", "98.85.180.179/32",
    "3.12.26.111/32", "3.139.51.102/32",
    # na-west / na-west-2
    "44.235.83.149/32", "44.244.87.130/32",
    "35.83.24.249/32", "44.237.60.158/32",
    # eu.platform.sublime.security
    "54.247.166.54/32", "52.214.238.48/32",
    # uk.platform.sublime.security
    "13.42.109.233/32", "18.135.235.114/32",
    # au.platform.sublime.security
    "13.238.69.11/32", "54.252.178.93/32",
    # ca.platform.sublime.security
    "15.157.18.163/32", "3.97.76.222/32",
    # IPv6 — Sublime documents these as frequently changing
    "::/0",
]

app = App(
    asset_cls=SublimeAsset,
    name="Sublime Security",
    appid="a1b2c3d4-e5f6-4a7b-8c9d-0e1f2a3b4c5d",
    app_type="investigative",
    product_vendor="Sublime Security",
    product_name="Sublime Platform",
    publisher="Splunk SOAR Community",
    logo="logo.svg",
    logo_dark="logo_dark.svg",
    min_phantom_version="6.3.0",
).enable_webhooks(
    default_requires_auth=True,
    default_allowed_headers=WEBHOOK_ALLOWED_HEADERS,
    default_ip_allowlist=WEBHOOK_IP_ALLOWLIST,
)


# =============================================================================
# HTTP client — one method per Sublime endpoint
# =============================================================================
class SublimeClient:
    def __init__(self, asset: SublimeAsset):
        if asset.region == "Custom":
            custom = (asset.base_url or "").strip()
            if not custom:
                raise ActionFailure("region is set to 'Custom' but base_url is empty — provide a Sublime platform URL on the asset.")
            if not custom.startswith(("http://", "https://")):
                raise ActionFailure(f"base_url must start with http:// or https:// (got {custom!r})")
            self.base_url = custom.rstrip("/")
        else:
            self.base_url = REGION_BASE_URLS.get(asset.region, REGION_BASE_URLS["NA-East"]).rstrip("/")
        self._headers = {
            "Authorization": f"Bearer {asset.api_key}",
            "Accept": "application/json",
            "Content-Type": "application/json",
        }
        self._client = httpx.Client(verify=asset.verify_server_cert, timeout=60.0)

    def _request(self, method: str, path: str, **kw) -> httpx.Response:
        url = f"{self.base_url}{path}"
        headers = dict(self._headers)
        headers.update(kw.pop("headers", None) or {})
        try:
            r = self._client.request(method, url, headers=headers, **kw)
        except httpx.RequestError as e:
            raise ActionFailure(f"sublime API request failed: {e!s}") from e
        if r.status_code >= 400:
            try:
                j = r.json()
                detail = j.get("error") or j.get("message") or r.text
            except Exception:
                detail = r.text
            raise ActionFailure(f"sublime API HTTP {r.status_code}: {detail}")
        return r

    def get(self, path: str, params: dict | None = None) -> dict:
        r = self._request("GET", path, params=params)
        return r.json() if r.status_code != 204 and r.content else {}

    def post(self, path: str, json: dict | None = None) -> dict:
        r = self._request("POST", path, json=json)
        return r.json() if r.status_code != 204 and r.content else {}

    def put(self, path: str, json: dict | None = None) -> dict:
        r = self._request("PUT", path, json=json)
        return r.json() if r.status_code != 204 and r.content else {}

    def patch(self, path: str, json: dict | None = None) -> dict:
        r = self._request("PATCH", path, json=json)
        return r.json() if r.status_code != 204 and r.content else {}

    def delete(self, path: str, params: dict | None = None) -> None:
        self._request("DELETE", path, params=params)

    def get_bytes(self, path: str, accept: str | None = None) -> bytes:
        headers = {"Accept": accept} if accept else None
        return self._request("GET", path, headers=headers).content


def _client(asset: SublimeAsset) -> SublimeClient:
    return SublimeClient(asset)


# =============================================================================
# Vault input helpers
# =============================================================================
def _file_b64(soar: SOARClient, vault_id: str | None, base64_data: str | None) -> str:
    if vault_id:
        files = soar.vault.get_attachment(vault_id=vault_id)
        if not files:
            raise ActionFailure(f"vault id {vault_id} not found")
        path = files[0].get("path") if isinstance(files[0], dict) else None
        if not path:
            raise ActionFailure("could not resolve vault file path")
        with open(path, "rb") as f:
            return base64.b64encode(f.read()).decode("utf-8")
    if base64_data:
        return base64_data
    raise ActionFailure("either vault_id or base64_data must be provided")


def _file_bytes(soar: SOARClient, vault_id: str | None, base64_data: str | None) -> bytes:
    if vault_id:
        files = soar.vault.get_attachment(vault_id=vault_id)
        if not files:
            raise ActionFailure(f"vault id {vault_id} not found")
        path = files[0].get("path") if isinstance(files[0], dict) else None
        if not path:
            raise ActionFailure("could not resolve vault file path")
        with open(path, "rb") as f:
            return f.read()
    if base64_data:
        try:
            return base64.b64decode(base64_data)
        except Exception as e:
            raise ActionFailure(f"invalid base64: {e!s}")
    raise ActionFailure("either vault_id or base64_data must be provided")


def _iter_image_bytes(data: Any) -> Iterator[bytes]:
    # Sublime returns image data as base64 string, list of ints (single image),
    # or list-of-lists (multi-page attachment) — handle all three.
    if not data:
        return
    if isinstance(data, (bytes, bytearray)):
        yield bytes(data); return
    if isinstance(data, str):
        try: yield base64.b64decode(data)
        except Exception: pass
        return
    if isinstance(data, list):
        if not data: return
        if all(isinstance(el, (list, tuple)) for el in data):
            for el in data:
                try: yield bytes(el)
                except Exception: pass
        elif all(isinstance(el, str) for el in data):
            for el in data:
                try: yield base64.b64decode(el)
                except Exception: pass
        else:
            try: yield bytes(data)
            except Exception: pass


def _save_images(soar: SOARClient, blobs: Iterator[bytes], name_pattern: str) -> str:
    container_id = soar.get_executing_container_id()
    last = ""
    for idx, b in enumerate(blobs):
        try:
            last = soar.vault.create_attachment(
                container_id=container_id, file_content=b,
                file_name=name_pattern.format(idx=idx),
            )
        except Exception:
            continue
    return last


# =============================================================================
# Webhook helpers — signature, container builder, artifact builder
# =============================================================================
def _extract_email(value: Any) -> str:
    if not value:
        return ""
    if isinstance(value, str):
        return value
    if isinstance(value, dict):
        inner = value.get("email")
        if isinstance(inner, str):
            return inner
        if isinstance(inner, dict):
            return inner.get("email", "") or ""
    return ""


def _derive_subject(data: dict) -> tuple[str, str, bool, bool]:
    sf = data.get("subject")
    if isinstance(sf, dict):
        return (
            sf.get("subject") or sf.get("base") or "",
            sf.get("base") or "",
            bool(sf.get("is_reply")),
            bool(sf.get("is_forward")),
        )
    return (sf or "", "", False, False)


def _derive_severity(rules: list, configured: str) -> str:
    if configured.lower() != "use alert severity":
        return configured
    rank = {"informational": 0, "low": 1, "medium": 2, "high": 3, "critical": 4}
    best, best_rk = None, -1
    for r in rules or []:
        if isinstance(r, dict):
            sev = (r.get("severity") or "").lower()
            rk = rank.get(sev, -1)
            if rk > best_rk:
                best_rk = rk
                best = sev
    if best == "informational":
        return "low"
    if best == "critical":
        return "high"
    return best or "medium"


def _build_container(payload: dict, data_block: dict, *, label: str,
                     severity_cfg: str, sensitivity: str) -> dict:
    message = data_block.get("message") if isinstance(data_block.get("message"), dict) else {}
    flagged_rules = data_block.get("flagged_rules") or []
    subject, _b, _ir, _if = _derive_subject(data_block)
    first_rule = ""
    if flagged_rules and isinstance(flagged_rules[0], dict):
        first_rule = flagged_rules[0].get("name", "") or ""
    msg_id = message.get("id") or data_block.get("id") or payload.get("id") or "unknown"
    if subject:
        name = f"Message Flagged: {subject}"
    elif first_rule:
        name = f"Message Flagged: {first_rule}"
    else:
        name = f"Message Flagged: {msg_id}"
    return {
        "name": name,
        "description": f"Sublime Security {payload.get('type', 'message.flagged')} event for message {msg_id}",
        "source_data_identifier": message.get("canonical_id") or msg_id,
        "label": label,
        "severity": _derive_severity(flagged_rules, severity_cfg),
        "sensitivity": sensitivity,
        "tags": [t for r in flagged_rules if isinstance(r, dict) for t in (r.get("tags") or [])],
        "data": payload,
    }


def _build_message_artifact(payload: dict, data_block: dict) -> dict:
    message = data_block.get("message") if isinstance(data_block.get("message"), dict) else {}
    subject, subject_base, is_reply, is_forward = _derive_subject(data_block)

    sender = data_block.get("sender") or {}
    sender_email = _extract_email(sender)
    sender_display = sender.get("display_name", "") if isinstance(sender, dict) else ""
    sender_domain = sender_email.rsplit("@", 1)[-1] if "@" in sender_email else ""

    recipients = data_block.get("recipients") or {}
    to_em = [_extract_email(r) for r in (recipients.get("to") or []) if r] if isinstance(recipients, dict) else []
    cc_em = [_extract_email(r) for r in (recipients.get("cc") or []) if r] if isinstance(recipients, dict) else []
    bcc_em = [_extract_email(r) for r in (recipients.get("bcc") or []) if r] if isinstance(recipients, dict) else []

    reply_to = data_block.get("reply_to") or []
    if isinstance(reply_to, dict):
        reply_to = [reply_to]
    reply_em = [_extract_email(r) for r in reply_to if r]

    flagged_rules = data_block.get("flagged_rules") or []
    rule_names = [r.get("name", "") for r in flagged_rules if isinstance(r, dict)]
    rule_ids = [r.get("id", "") for r in flagged_rules if isinstance(r, dict)]
    rule_severities = [r.get("severity", "") for r in flagged_rules if isinstance(r, dict) and r.get("severity")]
    triggered_actions = data_block.get("triggered_actions") or []
    action_types = [a.get("type", "") for a in triggered_actions if isinstance(a, dict)]

    attachments = data_block.get("attachments") or []
    attach_names = [a.get("file_name", "") for a in attachments if isinstance(a, dict) and a.get("file_name")]
    attach_sha256 = []
    for a in attachments:
        if isinstance(a, dict):
            fh = a.get("file_hash") or {}
            if isinstance(fh, dict) and fh.get("sha256"):
                attach_sha256.append(fh["sha256"])

    links = data_block.get("links") or []
    link_urls = [l.get("href_url", "") for l in links if isinstance(l, dict) and l.get("href_url")]

    headers = data_block.get("headers") or {}
    msg_id_header = headers.get("message_id", "") if isinstance(headers, dict) else ""
    sender_ip = ""
    if isinstance(headers, dict):
        spf = (headers.get("auth_summary") or {}).get("spf") or {} if isinstance(headers.get("auth_summary"), dict) else {}
        sender_ip = spf.get("client_ip", "") if isinstance(spf, dict) else ""

    cef = {
        "messageId": message.get("id", ""),
        "canonicalId": message.get("canonical_id", ""),
        "messageIdHeader": msg_id_header,
        "subject": subject,
        "subjectBase": subject_base,
        "isReply": is_reply,
        "isForward": is_forward,
        "senderEmail": sender_email,
        "senderDisplayName": sender_display,
        "senderDomain": sender_domain,
        "senderIp": sender_ip,
        "toRecipients": ", ".join(to_em),
        "ccRecipients": ", ".join(cc_em),
        "bccRecipients": ", ".join(bcc_em),
        "replyToRecipients": ", ".join(reply_em),
        "attackScoreVerdict": data_block.get("attack_score_verdict", ""),
        "flaggedRules": ", ".join(rule_names),
        "flaggedRuleIds": ", ".join(rule_ids),
        "flaggedRuleSeverities": ", ".join(rule_severities),
        "triggeredActionTypes": ", ".join(action_types),
        "attachmentCount": len(attachments),
        "attachmentFileNames": ", ".join(attach_names),
        "attachmentSha256": ", ".join(attach_sha256),
        "linkCount": len(links),
        "linkUrls": ", ".join(link_urls[:25]),
        "eventType": payload.get("type", ""),
        "eventId": payload.get("id", ""),
    }
    cef = {k: v for k, v in cef.items() if v not in (None, "", False) or v is True}

    return {
        "name": subject or (rule_names[0] if rule_names else f"Sublime message {message.get('id', 'unknown')}"),
        "label": "flagged message",
        "source_data_identifier": message.get("id", "") or payload.get("id", ""),
        "cef": cef,
        "cef_types": {
            "messageId": ["message id"],
            "canonicalId": ["message group id"],
            "senderEmail": ["email"],
            "senderDomain": ["domain"],
            "senderIp": ["ip"],
            "toRecipients": ["email"],
            "ccRecipients": ["email"],
            "bccRecipients": ["email"],
            "replyToRecipients": ["email"],
            "attachmentSha256": ["hash", "sha256"],
            "linkUrls": ["url"],
        },
        "data": data_block,
        "raw_data": payload,
        "run_automation": True,
    }


# =============================================================================
# Common params/output classes (reused by many actions)
# =============================================================================
class NoParams(Params):
    pass


class MessageIdParams(Params):
    message_id: str = Param(description="Message UUID", required=True, primary=True)


class SingleGroupParams(Params):
    message_group_id: str = Param(description="Message group ID", required=True, primary=True)
    classification: str = Param(default="", value_list=CLASSIFICATIONS,
        description="Reviewer classification to apply")
    report_label: str = Param(default="", value_list=REPORT_LABELS,
        description="Label to apply (analyst report category)")
    review_comment: str = Param(default="", description="Free-text reviewer comment")


class MessageGroupIdsParams(Params):
    message_group_ids: str = Param(description="Comma-separated message group IDs", required=True)
    classification: str = Param(default="", value_list=CLASSIFICATIONS,
        description="Reviewer classification to apply")
    report_label: str = Param(default="", value_list=REPORT_LABELS,
        description="Label to apply (analyst report category)")
    review_comment: str = Param(default="", description="Free-text reviewer comment")


class StatusOutput(ActionOutput):
    status: str = OutputField()


class TaskIdOutput(ActionOutput):
    task_id: str = OutputField()


class ScreenshotOutput(ActionOutput):
    screenshot_vault_id: str = OutputField()


class CountOutput(ActionOutput):
    total: int = OutputField()


class GroupsOutput(ActionOutput):
    total_groups: int = OutputField()
    groups_returned: int = OutputField()


class RuleResultsOutput(ActionOutput):
    matched_rules: int = OutputField()
    total_rules_evaluated: int = OutputField()


def _bulk_review_body(p: MessageGroupIdsParams) -> dict:
    body: dict = {"message_group_ids": parse_csv(p.message_group_ids)}
    for k in ("classification", "report_label", "review_comment"):
        v = getattr(p, k)
        if v:
            body[k] = v
    return body


def _single_review_body(p: SingleGroupParams) -> dict:
    return {k: getattr(p, k) for k in ("classification", "report_label", "review_comment") if getattr(p, k)}


# =============================================================================
# test_connectivity
# =============================================================================
@app.test_connectivity()
def test_connectivity(soar: SOARClient, asset: SublimeAsset):
    try:
        _client(asset).get("/v0/me")
    except ActionFailure:
        raise
    except Exception as e:
        raise ActionFailure(f"connectivity failed: {e!s}")


# =============================================================================
# Actions — BinExplode + Link Analysis
# =============================================================================
class UploadBinaryParams(Params):
    file_name: str = Param(description="File name to record in the scan", required=True)
    vault_id: str = Param(default="", description="Vault ID of file to upload")
    base64_data: str = Param(default="", description="Base64 file contents")


@app.action(action_type="investigate", read_only=False)
def upload_binary(params: UploadBinaryParams, asset: SublimeAsset, soar: SOARClient) -> TaskIdOutput:
    b64 = _file_b64(soar, params.vault_id or None, params.base64_data or None)
    j = _client(asset).post("/v0/binexplode/scan", {"file_contents": b64, "file_name": params.file_name})
    return TaskIdOutput(task_id=j.get("task_id", ""))


class GetBinexplodeResultsParams(Params):
    task_id: str = Param(description="BinExplode task ID", required=True, primary=True)


class BinexplodeResultsOutput(ActionOutput):
    total_results: int = OutputField()
    task_state: str = OutputField()


@app.action(action_type="investigate", read_only=True)
def get_binexplode_results(
    params: GetBinexplodeResultsParams, asset: SublimeAsset, soar: SOARClient,
) -> BinexplodeResultsOutput:
    j = _client(asset).get(f"/v0/binexplode/scan/{params.task_id}")
    return BinexplodeResultsOutput(
        total_results=len(j.get("results") or []),
        task_state=(j.get("task_response") or {}).get("state", "unknown"),
    )


class AnalyzeLinkParams(Params):
    url: str = Param(description="URL to analyze (e.g. https://suspicious.example.com/login)",
        required=True, primary=True)
    no_logo_detect: bool = Param(default=False,
        description="Skip brand logo detection (faster, but no brand attribution)")


class AnalyzeLinkOutput(ActionOutput):
    analyzed: bool = OutputField()
    disposition: str = OutputField()
    confidence: str = OutputField()
    brand_name: str = OutputField()
    effective_url: str = OutputField()
    screenshot_vault_id: str = OutputField()


@app.action(action_type="investigate", read_only=True)
def analyze_link(params: AnalyzeLinkParams, asset: SublimeAsset, soar: SOARClient) -> AnalyzeLinkOutput:
    body: dict = {"url": params.url}
    if params.no_logo_detect:
        body["no_logo_detect"] = True
    j = _client(asset).post("/v0/enrichment/link_analysis/evaluate", body)
    cp = j.get("credphish") or {}
    eu = j.get("effective_url") or {}

    vault_id = ""
    screenshot = j.get("screenshot") or {}
    if screenshot.get("raw"):
        try:
            img = base64.b64decode(screenshot["raw"])
            vault_id = soar.vault.create_attachment(
                container_id=soar.get_executing_container_id(),
                file_content=img,
                file_name=screenshot.get("file_name") or "link_analysis_screenshot.png",
            )
        except Exception:
            vault_id = ""
    return AnalyzeLinkOutput(
        analyzed=bool(j.get("analyzed", False)),
        disposition=cp.get("disposition", "unknown"),
        confidence=cp.get("confidence", "") or "",
        brand_name=(cp.get("brand") or {}).get("name", ""),
        effective_url=eu.get("url", ""),
        screenshot_vault_id=vault_id,
    )


# =============================================================================
# Actions — Audit Log
# =============================================================================
class ListAuditEventsParams(Params):
    start_time: str = Param(default="", description="Lower bound created_at (ISO 8601 UTC, e.g. 2026-05-16T00:00:00Z)")
    end_time: str = Param(default="", description="Upper bound created_at, exclusive (ISO 8601 UTC, e.g. 2026-05-16T00:00:00Z)")
    event_type: str = Param(default="", description="Filter by event type (e.g. login.success, rule.created)")
    user_ids: str = Param(default="", description="Comma-separated user UUIDs")
    limit: int = Param(default=100, description="Max events to return (1-500)")
    offset: int = Param(default=0, description="Pagination offset")


class AuditEventsOutput(ActionOutput):
    total_events: int = OutputField()
    events_returned: int = OutputField()


@app.action(action_type="investigate", read_only=True)
def list_audit_events(
    params: ListAuditEventsParams, asset: SublimeAsset, soar: SOARClient,
) -> AuditEventsOutput:
    q: dict = {"limit": min(params.limit, 500), "offset": params.offset}
    if params.start_time: q["created_at[gte]"] = params.start_time
    if params.end_time: q["created_at[lt]"] = params.end_time
    if params.event_type: q["type"] = params.event_type
    if params.user_ids: q["user_ids"] = parse_csv(params.user_ids)
    j = _client(asset).get("/v0/audit-log/events", q)
    events = j.get("events") or []
    return AuditEventsOutput(
        total_events=int(j.get("total", len(events))), events_returned=len(events),
    )


class AuditEventTypesOutput(ActionOutput):
    total_event_types: int = OutputField()


@app.action(action_type="investigate", read_only=True)
def list_audit_event_types(
    params: NoParams, asset: SublimeAsset, soar: SOARClient,
) -> AuditEventTypesOutput:
    j = _client(asset).get("/v0/audit-log/events/types")
    return AuditEventTypesOutput(total_event_types=len(j.get("event_types") or []))


class GetAuditEventParams(Params):
    event_id: str = Param(description="Audit event ID", required=True, primary=True)


class AuditEventOutput(ActionOutput):
    type: str = OutputField()
    created_at: str = OutputField()


@app.action(action_type="investigate", read_only=True)
def get_audit_event(params: GetAuditEventParams, asset: SublimeAsset, soar: SOARClient) -> AuditEventOutput:
    j = _client(asset).get(f"/v0/audit-log/events/{params.event_id}")
    return AuditEventOutput(type=j.get("type", ""), created_at=j.get("created_at", ""))


# =============================================================================
# Actions — Hunt Jobs
# =============================================================================
class StartHuntJobParams(Params):
    source: str = Param(description="MQL source (Message Query Language)", required=True)
    range_start_time: str = Param(description="Hunt window start (ISO 8601 UTC, e.g. 2026-05-09T00:00:00Z)", required=True)
    range_end_time: str = Param(description="Hunt window end (ISO 8601 UTC, e.g. 2026-05-16T00:00:00Z)", required=True)
    name: str = Param(default="", description="Optional human-readable hunt name")
    private: bool = Param(default=False, description="Restrict visibility to the creating user")
    triage_flagged: bool = Param(default=False, description="Include the triage_flagged scope")
    triage_reported: bool = Param(default=False, description="Include the triage_reported scope")
    triage_email_bomb: bool = Param(default=False, description="Include the triage_email_bomb scope")
    triage_dlp_rule_matched: bool = Param(default=False, description="Include the triage_dlp_rule_matched scope")


class HuntJobIdOutput(ActionOutput):
    hunt_job_id: str = OutputField()


@app.action(action_type="investigate", read_only=False)
def start_hunt_job(params: StartHuntJobParams, asset: SublimeAsset, soar: SOARClient) -> HuntJobIdOutput:
    body: dict = {
        "source": params.source,
        "range_start_time": params.range_start_time,
        "range_end_time": params.range_end_time,
    }
    if params.name: body["name"] = params.name
    if params.private: body["private"] = True
    for k in ("triage_flagged", "triage_reported", "triage_email_bomb", "triage_dlp_rule_matched"):
        if getattr(params, k):
            body[k] = True
    j = _client(asset).post("/v0/hunt-jobs", body)
    return HuntJobIdOutput(hunt_job_id=j.get("hunt_job_id", ""))


class HuntJobIdParams(Params):
    hunt_job_id: str = Param(description="Hunt job ID", required=True, primary=True)


class HuntJobStatusOutput(ActionOutput):
    hunt_status: str = OutputField()


@app.action(action_type="investigate", read_only=True)
def get_hunt_job(params: HuntJobIdParams, asset: SublimeAsset, soar: SOARClient) -> HuntJobStatusOutput:
    j = _client(asset).get(f"/v0/hunt-jobs/{params.hunt_job_id}")
    return HuntJobStatusOutput(hunt_status=j.get("status", "unknown"))


class GetHuntJobResultsParams(Params):
    hunt_job_id: str = Param(description="Hunt job ID", required=True, primary=True)
    limit: int = Param(default=100, description="Max message groups to return (1-500)")
    offset: int = Param(default=0, description="Pagination offset")


class HuntJobResultsOutput(ActionOutput):
    total_group_count: int = OutputField()
    groups_returned: int = OutputField()


@app.action(action_type="investigate", read_only=True)
def get_hunt_job_results(
    params: GetHuntJobResultsParams, asset: SublimeAsset, soar: SOARClient,
) -> HuntJobResultsOutput:
    j = _client(asset).get(
        f"/v0/hunt-jobs/{params.hunt_job_id}/results",
        {"limit": min(params.limit, 500), "offset": params.offset},
    )
    groups = j.get("message_groups") or []
    return HuntJobResultsOutput(
        total_group_count=int(j.get("total_group_count", len(groups))),
        groups_returned=len(groups),
    )


# =============================================================================
# Actions — Lists
# =============================================================================
class ListListsParams(Params):
    name: str = Param(default="", description="Filter by exact list name")


class ListsOutput(ActionOutput):
    total_lists: int = OutputField()


@app.action(action_type="investigate", read_only=True)
def list_lists(params: ListListsParams, asset: SublimeAsset, soar: SOARClient) -> ListsOutput:
    q: dict = {"entry_type": "string"}
    if params.name: q["name"] = params.name
    return ListsOutput(total_lists=len(_client(asset).get("/v0/lists", q).get("lists") or []))


class CreateListParams(Params):
    name: str = Param(required=True)
    description: str = Param(required=True)


class ListIdOutput(ActionOutput):
    list_id: str = OutputField()


@app.action(action_type="generic", read_only=False)
def create_list(params: CreateListParams, asset: SublimeAsset, soar: SOARClient) -> ListIdOutput:
    j = _client(asset).post("/v0/lists", {"name": params.name, "description": params.description})
    return ListIdOutput(list_id=j.get("id", ""))


class ListIdParams(Params):
    list_id: str = Param(description="List ID", required=True, primary=True)


@app.action(action_type="generic", read_only=False)
def delete_list(params: ListIdParams, asset: SublimeAsset, soar: SOARClient) -> StatusOutput:
    _client(asset).delete(f"/v0/lists/{params.list_id}")
    return StatusOutput(status="deleted")


class ListMetadataOutput(ActionOutput):
    name: str = OutputField()
    description: str = OutputField()


@app.action(action_type="investigate", read_only=True)
def get_list(params: ListIdParams, asset: SublimeAsset, soar: SOARClient) -> ListMetadataOutput:
    j = _client(asset).get(f"/v0/lists/{params.list_id}")
    return ListMetadataOutput(name=j.get("name", ""), description=j.get("description", ""))


class PatchListParams(Params):
    list_id: str = Param(description="List ID", required=True, primary=True)
    description: str = Param(required=True)


@app.action(action_type="generic", read_only=False)
def patch_list(params: PatchListParams, asset: SublimeAsset, soar: SOARClient) -> ListMetadataOutput:
    j = _client(asset).patch(f"/v0/lists/{params.list_id}", {"description": params.description})
    return ListMetadataOutput(name=j.get("name", ""), description=j.get("description", ""))


class GetListEntriesParams(Params):
    list_id: str = Param(description="List ID", required=True, primary=True)
    save_to_vault: bool = Param(default=False, description="Also save the entries as a CSV to the container vault")
    csv_file_name: str = Param(default="", description="CSV filename when save_to_vault=true (default: list_<id>_entries.csv)")


class ListEntriesOutput(ActionOutput):
    total_entries: int = OutputField()
    vault_id: str = OutputField()


@app.action(action_type="investigate", read_only=True)
def get_list_entries(
    params: GetListEntriesParams, asset: SublimeAsset, soar: SOARClient,
) -> ListEntriesOutput:
    j = _client(asset).get(f"/v0/lists/{params.list_id}/entries")
    entries = j.get("entries") or []
    vault_id = ""
    if params.save_to_vault:
        buf = io.StringIO()
        w = csv_mod.writer(buf); w.writerow(["entry"])
        for e in entries:
            w.writerow([e])
        try:
            vault_id = soar.vault.create_attachment(
                container_id=soar.get_executing_container_id(),
                file_content=buf.getvalue().encode("utf-8"),
                file_name=params.csv_file_name or f"list_{params.list_id}_entries.csv",
            )
        except Exception:
            vault_id = ""
    return ListEntriesOutput(total_entries=len(entries), vault_id=vault_id)


class SetListEntriesParams(Params):
    list_id: str = Param(description="List ID", required=True, primary=True)
    entries: str = Param(default="", description="Comma-separated")
    vault_id: str = Param(default="", description="Vault ID of CSV")


class EntriesSetOutput(ActionOutput):
    entries_set: int = OutputField()


@app.action(action_type="generic", read_only=False)
def set_list_entries(
    params: SetListEntriesParams, asset: SublimeAsset, soar: SOARClient,
) -> EntriesSetOutput:
    entries: list[str] = []
    if params.vault_id:
        text = _file_bytes(soar, params.vault_id, None).decode("utf-8", errors="replace")
        for row in csv_mod.reader(io.StringIO(text)):
            for cell in row:
                cell = cell.strip()
                if cell and cell.lower() != "entry":
                    entries.append(cell)
    elif params.entries:
        entries = parse_csv(params.entries)
    else:
        raise ActionFailure("either entries or vault_id must be provided")
    _client(asset).put(f"/v0/lists/{params.list_id}/entries", {"entries": entries})
    return EntriesSetOutput(entries_set=len(entries))


class EntryParams(Params):
    list_id: str = Param(description="List ID", required=True, primary=True)
    entry: str = Param(description="Entry value (single, or comma-separated for get)", required=True)


@app.action(action_type="generic", read_only=False)
def add_list_entry(params: EntryParams, asset: SublimeAsset, soar: SOARClient) -> StatusOutput:
    _client(asset).post(f"/v0/lists/{params.list_id}/entries/entry", {"string": params.entry})
    return StatusOutput(status="added")


@app.action(action_type="generic", read_only=False)
def delete_list_entry(params: EntryParams, asset: SublimeAsset, soar: SOARClient) -> StatusOutput:
    _client(asset).delete(f"/v0/lists/{params.list_id}/entries/entry", params={"string": params.entry})
    return StatusOutput(status="deleted")


class GetListEntryOutput(ActionOutput):
    total_checked: int = OutputField()
    total_found: int = OutputField()


@app.action(action_type="investigate", read_only=True)
def get_list_entry(params: EntryParams, asset: SublimeAsset, soar: SOARClient) -> GetListEntryOutput:
    raw = params.entry
    to_check = parse_csv(raw) if "," in raw else [raw.strip()]
    found = 0
    c = _client(asset)
    for e in to_check:
        try:
            c.get(f"/v0/lists/{params.list_id}/entries/entry", {"string": e})
            found += 1
        except ActionFailure:
            continue
    return GetListEntryOutput(total_checked=len(to_check), total_found=found)


# =============================================================================
# Actions — Mailboxes / Raw / Tasks / User Reports / Roles
# =============================================================================
class ListMailboxesParams(Params):
    limit: int = Param(default=100, description="Max mailboxes to return (1-500)")
    offset: int = Param(default=0, description="Pagination offset")
    active: str = Param(default="", description="'true' or 'false' to filter by detected-active state")
    marked_active: bool = Param(default=False, description="Only return mailboxes admins have marked active")
    search: str = Param(default="", description="Substring match across mailbox emails/display names")
    email_addresses: str = Param(default="", description="Comma-separated exact email filter")
    mailbox_types: str = Param(default="", description="Comma-separated types (e.g. user, shared)")
    sub_error_types: str = Param(default="", description="Comma-separated sub_error types to filter on")
    message_source_id: str = Param(default="", description="Filter by message source UUID")


class MailboxesOutput(ActionOutput):
    total_mailboxes: int = OutputField()
    active_mailboxes: int = OutputField()


@app.action(action_type="investigate", read_only=True)
def list_mailboxes(params: ListMailboxesParams, asset: SublimeAsset, soar: SOARClient) -> MailboxesOutput:
    q: dict = {"limit": min(params.limit, 500), "offset": params.offset}
    if params.active: q["active"] = params.active
    if params.marked_active: q["marked_active"] = True
    if params.search: q["search"] = params.search
    for k in ("email_addresses", "mailbox_types", "sub_error_types", "message_source_id"):
        v = getattr(params, k)
        if v: q[k] = v
    j = _client(asset).get("/v0/mailboxes", q)
    return MailboxesOutput(
        total_mailboxes=int(j.get("total", 0)), active_mailboxes=int(j.get("active", 0)),
    )


class ProcessRawMessageParams(Params):
    mailbox_email_address: str = Param(required=True, description="Mailbox owner email (e.g. user@example.com)")
    message_source_id: str = Param(required=True, description="UUID of the message source the message came from")
    vault_id: str = Param(default="", description="Vault ID of the .eml file")
    base64_data: str = Param(default="", description="Base64-encoded raw message (alternative to vault_id)")
    canonical_id: str = Param(default="", description="Canonical ID to dedupe against")
    external_message_id: str = Param(default="", description="Upstream provider's message ID (e.g. Microsoft Graph Internet Message ID)")
    external_thread_id: str = Param(default="", description="Upstream thread/conversation ID")
    external_created_at: str = Param(default="", description="When the message was received upstream (ISO 8601 UTC, e.g. 2026-05-16T00:00:00Z)")
    folder: str = Param(default="", description="Mailbox folder (e.g. INBOX, Junk Email)")
    labels: str = Param(default="", description="Comma-separated label strings to attach")
    route_type: str = Param(default="", description="Upstream route type (e.g. mx, journal)")
    message_type: str = Param(default="", value_list=["", "inbound", "internal", "outbound"],
        description="Direction of the message")
    delivery_status: str = Param(default="", value_list=["", "undelivered"],
        description="Use 'undelivered' to simulate inline processing (e.g. for testing interdict actions)")
    create_mailbox: bool = Param(default=False, description="Auto-create the mailbox if it doesn't exist")
    analyze_async: bool = Param(default=False, description="Run analysis asynchronously and return immediately")


class ProcessRawMessageOutput(ActionOutput):
    message_id: str = OutputField()
    flagged_rules_count: int = OutputField()


@app.action(action_type="investigate", read_only=False)
def process_raw_message(
    params: ProcessRawMessageParams, asset: SublimeAsset, soar: SOARClient,
) -> ProcessRawMessageOutput:
    body: dict = {
        "raw_message": _file_b64(soar, params.vault_id or None, params.base64_data or None),
        "mailbox_email_address": params.mailbox_email_address,
        "message_source_id": params.message_source_id,
    }
    if params.create_mailbox: body["create_mailbox"] = True
    if params.analyze_async: body["analyze_async"] = True
    for k in ("canonical_id", "external_message_id", "external_thread_id",
              "external_created_at", "folder", "route_type", "delivery_status"):
        v = getattr(params, k)
        if v: body[k] = v
    if params.labels: body["labels"] = parse_csv(params.labels)
    if params.message_type in ("inbound", "internal", "outbound"):
        body["message_type"] = {params.message_type: True}
    j = _client(asset).post("/v0/live-flow/raw-messages/analyze", body)
    return ProcessRawMessageOutput(
        message_id=j.get("message_id", ""),
        flagged_rules_count=len(j.get("flagged_rules") or []),
    )


class GetTaskParams(Params):
    task_id: str = Param(description="Task ID", required=True, primary=True)


class TaskStateOutput(ActionOutput):
    task_state: str = OutputField()


@app.action(action_type="investigate", read_only=True)
def get_task(params: GetTaskParams, asset: SublimeAsset, soar: SOARClient) -> TaskStateOutput:
    return TaskStateOutput(task_state=_client(asset).get(f"/v0/tasks/{params.task_id}").get("state", "unknown"))


class ListUserReportsParams(Params):
    start_time: str = Param(default="", description="Lower bound reported_at (ISO 8601 UTC, e.g. 2026-05-16T00:00:00Z)")
    end_time: str = Param(default="", description="Upper bound reported_at, exclusive (ISO 8601 UTC, e.g. 2026-05-16T00:00:00Z)")
    limit: int = Param(default=100, description="Max reports to return (1-500)")


class UserReportsOutput(ActionOutput):
    total_reports: int = OutputField()


@app.action(action_type="investigate", read_only=True)
def list_user_reports(
    params: ListUserReportsParams, asset: SublimeAsset, soar: SOARClient,
) -> UserReportsOutput:
    q: dict = {}
    if params.start_time: q["reported_at[gte]"] = params.start_time
    if params.end_time: q["reported_at[lt]"] = params.end_time
    if params.limit: q["limit"] = min(params.limit, 500)
    j = _client(asset).get("/v0/user-reports", q)
    return UserReportsOutput(total_reports=int(j.get("count", len(j.get("user_reports") or []))))


class AssignRoleParams(Params):
    email_address: str = Param(required=True, primary=True)
    role_title: str = Param(required=True)


@app.action(action_type="generic", read_only=False)
def assign_role(params: AssignRoleParams, asset: SublimeAsset, soar: SOARClient) -> StatusOutput:
    _client(asset).put("/v0/roles/assign", {
        "email_address": params.email_address, "role_title": params.role_title,
    })
    return StatusOutput(status="assigned")


# =============================================================================
# Actions — Message Groups (bulk + single)
# =============================================================================
class ListMessageGroupsParams(Params):
    limit: int = Param(default=100, description="Max groups to return (1-500)")
    offset: int = Param(default=0, description="Pagination offset")
    start_time: str = Param(default="", description="Lower bound created_at (ISO 8601 UTC, e.g. 2026-05-16T00:00:00Z)")
    end_time: str = Param(default="", description="Upper bound created_at, exclusive (ISO 8601 UTC, e.g. 2026-05-16T00:00:00Z)")
    first_message_reported_at_gte: str = Param(default="", description="Lower bound first_message_reported_at (ISO 8601 UTC)")
    flagged: str = Param(default="", description="'true' or 'false' to filter by flagged state")
    reviewed: str = Param(default="", description="'true' or 'false' to filter by review state")
    user_reported: str = Param(default="", description="'true' or 'false' to filter by user-reported state")
    attack_surface_reduction: str = Param(default="", description="ASR filter, e.g. 'true' to only show messages contributing to ASR")
    sender_email: str = Param(default="", description="Comma-separated sender emails")
    sender_domain: str = Param(default="", description="Comma-separated sender domains")
    sender_display_name: str = Param(default="", description="Comma-separated sender display names")
    mailbox_email: str = Param(default="", description="Comma-separated mailbox emails")
    recipient_email: str = Param(default="", description="Comma-separated recipient emails")
    subject: str = Param(default="", description="Comma-separated exact subjects")
    canonical_id: str = Param(default="", description="Comma-separated canonical IDs")
    attachment_name: str = Param(default="", description="Comma-separated attachment file names")
    attachment_sha256: str = Param(default="", description="Comma-separated attachment SHA256 hashes")
    attack_score_verdict: str = Param(default="", description="Comma-separated ASA verdicts (e.g. malicious,spam,benign)")
    flagged_rule_id: str = Param(default="", description="Comma-separated rule UUIDs currently flagging the message")
    flagged_rule_severity: str = Param(default="", description="Comma-separated severities (informational,low,medium,high,critical)")
    historically_flagged_rule_id: str = Param(default="", description="Comma-separated rule UUIDs that ever flagged the message")
    historically_flagged_rule_severity: str = Param(default="", description="Comma-separated severities")
    reported_as_phish_by: str = Param(default="", description="Comma-separated reporter emails")
    spam_status: str = Param(default="", description="Comma-separated spam statuses")
    vendor_id: str = Param(default="", description="Comma-separated upstream vendor IDs")


_ARRAY_FILTERS = {
    "sender_email": "sender_email__is", "sender_domain": "sender_domain__is",
    "sender_display_name": "sender_display_name__is", "mailbox_email": "mailbox_email__is",
    "recipient_email": "recipient_email__is", "subject": "subject__is",
    "canonical_id": "canonical_id__is", "attachment_name": "attachment_name__is",
    "attachment_sha256": "attachment_sha256__is", "attack_score_verdict": "attack_score_verdict__is",
    "flagged_rule_id": "flagged_rule_id__is", "flagged_rule_severity": "flagged_rule_severity__is",
    "historically_flagged_rule_id": "historically_flagged_rule_id__is",
    "historically_flagged_rule_severity": "historically_flagged_rule_severity__is",
    "reported_as_phish_by": "reported_as_phish_by__is", "spam_status": "spam__is",
    "vendor_id": "vendor_id__is",
}


@app.action(action_type="investigate", read_only=True)
def list_message_groups(
    params: ListMessageGroupsParams, asset: SublimeAsset, soar: SOARClient,
) -> GroupsOutput:
    q: dict = {"limit": min(params.limit, 500), "offset": params.offset}
    if params.start_time: q["created_at__gte"] = params.start_time
    if params.end_time: q["created_at__lt"] = params.end_time
    if params.first_message_reported_at_gte:
        q["first_message_reported_at__gte"] = params.first_message_reported_at_gte
    for k in ("flagged", "reviewed", "user_reported"):
        v = getattr(params, k)
        if v: q[k] = v
    if params.attack_surface_reduction:
        q["attack_surface_reduction__filter"] = params.attack_surface_reduction
    for pkey, qkey in _ARRAY_FILTERS.items():
        v = getattr(params, pkey)
        if v: q[qkey] = parse_csv(v)
    j = _client(asset).get("/v0/message-groups", q)
    groups = j.get("message_groups") or []
    return GroupsOutput(total_groups=int(j.get("total", 0)), groups_returned=len(groups))


class SearchMessageGroupsParams(Params):
    limit: int = Param(default=100, description="Max groups to return (1-500)")
    offset: int = Param(default=0, description="Pagination offset")
    any: str = Param(default="", description="Free-text search across all indexed fields")
    sender: str = Param(default="", description="Sender email or partial match")
    to: str = Param(default="", description="Recipient email or partial match")
    mailbox: str = Param(default="", description="Mailbox email or partial match")
    subject: str = Param(default="", description="Subject substring")
    message_id: str = Param(default="", description="Message ID or canonical ID")
    type: str = Param(default="", description="Message type (e.g. inbound)")
    file_name: str = Param(default="", description="Attachment file name")
    attachment_md5: str = Param(default="", description="Attachment MD5 hash")
    attachment_sha1: str = Param(default="", description="Attachment SHA1 hash")
    attachment_sha256: str = Param(default="", description="Attachment SHA256 hash")
    states: str = Param(default="", description="Comma-separated review states")
    start_time: str = Param(default="", description="Lower bound created_at (ISO 8601 UTC, e.g. 2026-05-16T00:00:00Z)")
    end_time: str = Param(default="", description="Upper bound created_at, exclusive (ISO 8601 UTC)")
    first_reported_as_phish_at_gte: str = Param(default="", description="Lower bound (ISO 8601 UTC)")
    first_reported_as_phish_at_lt: str = Param(default="", description="Upper bound, exclusive (ISO 8601 UTC)")


@app.action(action_type="investigate", read_only=True)
def search_message_groups(
    params: SearchMessageGroupsParams, asset: SublimeAsset, soar: SOARClient,
) -> GroupsOutput:
    q: dict = {"limit": min(params.limit, 500), "offset": params.offset}
    for k in ("any", "sender", "to", "mailbox", "subject", "message_id", "type", "file_name",
              "attachment_md5", "attachment_sha1", "attachment_sha256"):
        v = getattr(params, k)
        if v: q[k] = v
    if params.states: q["states"] = parse_csv(params.states)
    if params.start_time: q["created_at[gte]"] = params.start_time
    if params.end_time: q["created_at[lt]"] = params.end_time
    if params.first_reported_as_phish_at_gte:
        q["first_reported_as_phish_at[gte]"] = params.first_reported_as_phish_at_gte
    if params.first_reported_as_phish_at_lt:
        q["first_reported_as_phish_at[lt]"] = params.first_reported_as_phish_at_lt
    j = _client(asset).get("/v0/message-groups/search", q)
    groups = j.get("message_groups") or []
    return GroupsOutput(total_groups=int(j.get("total", 0)), groups_returned=len(groups))


@app.action(action_type="correct", read_only=False)
def dismiss_message_groups(
    params: MessageGroupIdsParams, asset: SublimeAsset, soar: SOARClient,
) -> StatusOutput:
    _client(asset).post("/v0/message-groups/dismiss", _bulk_review_body(params))
    return StatusOutput(status="dismissed")


@app.action(action_type="correct", read_only=False)
def quarantine_message_groups(
    params: MessageGroupIdsParams, asset: SublimeAsset, soar: SOARClient,
) -> TaskIdOutput:
    return TaskIdOutput(task_id=_client(asset).post(
        "/v0/message-groups/quarantine", _bulk_review_body(params),
    ).get("task_id", ""))


@app.action(action_type="correct", read_only=False)
def graymail_message_groups(
    params: MessageGroupIdsParams, asset: SublimeAsset, soar: SOARClient,
) -> TaskIdOutput:
    return TaskIdOutput(task_id=_client(asset).post(
        "/v0/message-groups/move-to-graymail", _bulk_review_body(params),
    ).get("task_id", ""))


@app.action(action_type="correct", read_only=False)
def restore_message_groups(
    params: MessageGroupIdsParams, asset: SublimeAsset, soar: SOARClient,
) -> TaskIdOutput:
    return TaskIdOutput(task_id=_client(asset).post(
        "/v0/message-groups/restore", _bulk_review_body(params),
    ).get("task_id", ""))


@app.action(action_type="correct", read_only=False)
def trash_message_groups(
    params: MessageGroupIdsParams, asset: SublimeAsset, soar: SOARClient,
) -> TaskIdOutput:
    return TaskIdOutput(task_id=_client(asset).post(
        "/v0/message-groups/trash", _bulk_review_body(params),
    ).get("task_id", ""))


class ReviewMessageGroupsParams(Params):
    message_group_ids: str = Param(description="Comma-separated message group IDs", required=True)
    classification: str = Param(required=True, value_list=REVIEW_CLASSIFICATIONS,
        description="Reviewer classification")
    action: str = Param(default="", value_list=MESSAGE_ACTIONS,
        description="Built-in action to perform on the message")
    custom_action_ids: str = Param(default="",
        description="Comma-separated UUIDs of custom actions to perform in addition to 'action'")
    review_comment: str = Param(default="", description="Free-text reviewer comment")
    share_with_sublime: bool = Param(default=False,
        description="Also share the message with Sublime for community detection")


@app.action(action_type="correct", read_only=False)
def review_message_groups(
    params: ReviewMessageGroupsParams, asset: SublimeAsset, soar: SOARClient,
) -> TaskIdOutput:
    body: dict = {
        "message_group_ids": parse_csv(params.message_group_ids),
        "classification": params.classification,
    }
    if params.action: body["action"] = params.action
    if params.custom_action_ids: body["custom_action_ids"] = parse_csv(params.custom_action_ids)
    if params.review_comment: body["review_comment"] = params.review_comment
    if params.share_with_sublime: body["share_with_sublime"] = True
    return TaskIdOutput(task_id=_client(asset).post("/v0/message-groups/review", body).get("task_id", ""))


class GetGroupParams(Params):
    message_group_id: str = Param(description="Message group ID", required=True, primary=True)


class GroupOutput(ActionOutput):
    canonical_id: str = OutputField()
    review_status: str = OutputField()


@app.action(action_type="investigate", read_only=True)
def get_message_group(params: GetGroupParams, asset: SublimeAsset, soar: SOARClient) -> GroupOutput:
    j = _client(asset).get(f"/v0/message-groups/{params.message_group_id}")
    return GroupOutput(canonical_id=j.get("canonical_id", ""), review_status=j.get("review_status", ""))


@app.action(action_type="correct", read_only=False)
def dismiss_message_group(
    params: SingleGroupParams, asset: SublimeAsset, soar: SOARClient,
) -> StatusOutput:
    _client(asset).post(f"/v0/message-groups/{params.message_group_id}/dismiss", _single_review_body(params))
    return StatusOutput(status="dismissed")


@app.action(action_type="correct", read_only=False)
def quarantine_message_group(
    params: SingleGroupParams, asset: SublimeAsset, soar: SOARClient,
) -> TaskIdOutput:
    return TaskIdOutput(task_id=_client(asset).post(
        f"/v0/message-groups/{params.message_group_id}/quarantine", _single_review_body(params),
    ).get("task_id", ""))


@app.action(action_type="correct", read_only=False)
def restore_message_group(
    params: SingleGroupParams, asset: SublimeAsset, soar: SOARClient,
) -> TaskIdOutput:
    return TaskIdOutput(task_id=_client(asset).post(
        f"/v0/message-groups/{params.message_group_id}/restore", _single_review_body(params),
    ).get("task_id", ""))


@app.action(action_type="correct", read_only=False)
def trash_message_group(
    params: SingleGroupParams, asset: SublimeAsset, soar: SOARClient,
) -> TaskIdOutput:
    return TaskIdOutput(task_id=_client(asset).post(
        f"/v0/message-groups/{params.message_group_id}/trash", _single_review_body(params),
    ).get("task_id", ""))


class ShareWithSublimeParams(Params):
    message_group_id: str = Param(description="Message group ID", required=True, primary=True)
    report_label: str = Param(default="", value_list=REPORT_LABELS,
        description="Label to share alongside the message")
    review_comment: str = Param(default="", description="Free-text comment shared with Sublime")


@app.action(action_type="generic", read_only=False)
def share_with_sublime(
    params: ShareWithSublimeParams, asset: SublimeAsset, soar: SOARClient,
) -> TaskIdOutput:
    body: dict = {}
    if params.report_label: body["report_label"] = params.report_label
    if params.review_comment: body["review_comment"] = params.review_comment
    return TaskIdOutput(task_id=_client(asset).post(
        f"/v0/message-groups/{params.message_group_id}/share-with-sublime", body,
    ).get("task_id", ""))


# =============================================================================
# Actions — Messages
# =============================================================================
class AnalyzeRawParams(Params):
    vault_id: str = Param(default="", description="Vault ID of the .eml file")
    base64_data: str = Param(default="", description="Base64-encoded raw message (alternative to vault_id)")
    run_active_detection_rules: bool = Param(default=False, description="Evaluate currently-active detection rules")
    run_all_detection_rules: bool = Param(default=False, description="Evaluate all detection rules (active + inactive)")
    run_all_insights: bool = Param(default=False, description="Run all insight queries")


@app.action(action_type="investigate", read_only=True)
def analyze_raw_message(params: AnalyzeRawParams, asset: SublimeAsset, soar: SOARClient) -> RuleResultsOutput:
    b64 = _file_b64(soar, params.vault_id or None, params.base64_data or None)
    body: dict = {"raw_message": b64}
    for k in ("run_active_detection_rules", "run_all_detection_rules", "run_all_insights"):
        if getattr(params, k): body[k] = True
    j = _client(asset).post("/v0/messages/analyze", body)
    rr = j.get("rule_results") or []
    return RuleResultsOutput(
        matched_rules=sum(1 for r in rr if r.get("matched")),
        total_rules_evaluated=len(rr),
    )


class AttackScoreOutput(ActionOutput):
    verdict: str = OutputField()
    score: int = OutputField()


class AttackScoreRawParams(Params):
    vault_id: str = Param(default="", description="Vault ID of the .eml file")
    base64_data: str = Param(default="", description="Base64-encoded raw message (alternative to vault_id)")


@app.action(action_type="investigate", read_only=True)
def get_attack_score_raw(
    params: AttackScoreRawParams, asset: SublimeAsset, soar: SOARClient,
) -> AttackScoreOutput:
    b64 = _file_b64(soar, params.vault_id or None, params.base64_data or None)
    j = _client(asset).post("/v0/messages/attack_score", {"raw_message": b64})
    return AttackScoreOutput(verdict=j.get("verdict", ""), score=int(j.get("score") or 0))


@app.action(action_type="investigate", read_only=True)
def get_attack_score(params: MessageIdParams, asset: SublimeAsset, soar: SOARClient) -> AttackScoreOutput:
    j = _client(asset).get(f"/v0/messages/{params.message_id}/attack_score")
    return AttackScoreOutput(verdict=j.get("verdict", ""), score=int(j.get("score") or 0))


class RenderAttachmentImageParams(Params):
    vault_id: str = Param(default="", description="Vault ID of the attachment to render")
    base64_data: str = Param(default="", description="Base64-encoded attachment bytes (alternative to vault_id)")
    file_type: str = Param(default="", description="MIME type override (e.g. application/pdf)")


@app.action(action_type="investigate", read_only=True)
def render_attachment_image(
    params: RenderAttachmentImageParams, asset: SublimeAsset, soar: SOARClient,
) -> ScreenshotOutput:
    b64 = _file_b64(soar, params.vault_id or None, params.base64_data or None)
    body: dict = {"raw": b64}
    if params.file_type: body["file_type"] = params.file_type
    j = _client(asset).post("/v0/messages/attachment/image", body)
    return ScreenshotOutput(screenshot_vault_id=_save_images(
        soar, _iter_image_bytes(j.get("data")), "attachment_render_{idx}.png",
    ))


class CreateMessageParams(Params):
    vault_id: str = Param(default="", description="Vault ID of the .eml file")
    base64_data: str = Param(default="", description="Base64-encoded raw message (alternative to vault_id)")
    mailbox_email_address: str = Param(default="", description="Mailbox owner email")
    canonical_id: str = Param(default="", description="Canonical ID to dedupe against")
    external_message_id: str = Param(default="", description="Upstream provider's message ID")
    external_thread_id: str = Param(default="", description="Upstream thread/conversation ID")
    external_created_at: str = Param(default="", description="Upstream receipt time (ISO 8601 UTC, e.g. 2026-05-16T00:00:00Z)")
    folder: str = Param(default="", description="Mailbox folder")
    labels: str = Param(default="", description="Comma-separated label strings")
    route_type: str = Param(default="", description="Upstream route type")
    message_type: str = Param(default="", value_list=["", "inbound", "internal", "outbound"],
        description="Direction of the message")


class MessageIdOutput(ActionOutput):
    message_id: str = OutputField()


@app.action(action_type="generic", read_only=False)
def create_message(params: CreateMessageParams, asset: SublimeAsset, soar: SOARClient) -> MessageIdOutput:
    body: dict = {"raw_message": _file_b64(soar, params.vault_id or None, params.base64_data or None)}
    for k in ("mailbox_email_address", "canonical_id", "external_message_id", "external_thread_id",
              "external_created_at", "folder", "route_type"):
        v = getattr(params, k)
        if v: body[k] = v
    if params.labels: body["labels"] = parse_csv(params.labels)
    if params.message_type in ("inbound", "internal", "outbound"):
        body["message_type"] = {params.message_type: True}
    j = _client(asset).post("/v0/messages/create", body)
    return MessageIdOutput(message_id=j.get("id", ""))


class GetActionStateParams(Params):
    message_group_id: str = Param(description="Message group ID", required=True, primary=True)
    limit: int = Param(default=10, description="Max action records to return (1-50)")
    offset: int = Param(default=0, description="Pagination offset")


class ActionsCountOutput(ActionOutput):
    actions_returned: int = OutputField()


@app.action(action_type="investigate", read_only=True)
def get_action_state(
    params: GetActionStateParams, asset: SublimeAsset, soar: SOARClient,
) -> ActionsCountOutput:
    j = _client(asset).get(
        f"/v0/messages/groups/{params.message_group_id}/action-state",
        {"limit": min(params.limit, 50), "offset": params.offset},
    )
    return ActionsCountOutput(actions_returned=len(j.get("actions") or []))


class MessageOutput(ActionOutput):
    id: str = OutputField()
    canonical_id: str = OutputField()


@app.action(action_type="investigate", read_only=True)
def get_message(params: MessageIdParams, asset: SublimeAsset, soar: SOARClient) -> MessageOutput:
    j = _client(asset).get(f"/v0/messages/{params.message_id}")
    return MessageOutput(id=j.get("id", ""), canonical_id=j.get("canonical_id", ""))


class ActionMessageParams(Params):
    message_id: str = Param(description="Message UUID", required=True, primary=True)
    action: str = Param(default="", value_list=MESSAGE_ACTIONS,
        description="Built-in action to perform on the message")
    share_with_sublime: bool = Param(default=False,
        description="Also share the message with Sublime for community detection")


@app.action(action_type="correct", read_only=False)
def action_message(params: ActionMessageParams, asset: SublimeAsset, soar: SOARClient) -> TaskIdOutput:
    body: dict = {}
    if params.action: body["action"] = params.action
    if params.share_with_sublime: body["share_with_sublime"] = True
    return TaskIdOutput(task_id=_client(asset).post(
        f"/v0/messages/{params.message_id}/actions", body,
    ).get("task_id", ""))


class AnalyzeByIdParams(Params):
    message_id: str = Param(description="Message UUID", required=True, primary=True)
    run_active_detection_rules: bool = Param(default=False, description="Evaluate currently-active detection rules")
    run_all_detection_rules: bool = Param(default=False, description="Evaluate all detection rules (active + inactive)")
    run_all_insights: bool = Param(default=False, description="Run all insight queries")


@app.action(action_type="investigate", read_only=True)
def analyze_message_by_id(
    params: AnalyzeByIdParams, asset: SublimeAsset, soar: SOARClient,
) -> RuleResultsOutput:
    body: dict = {}
    for k in ("run_active_detection_rules", "run_all_detection_rules", "run_all_insights"):
        if getattr(params, k): body[k] = True
    j = _client(asset).post(f"/v0/messages/{params.message_id}/analyze", body)
    rr = j.get("rule_results") or []
    return RuleResultsOutput(
        matched_rules=sum(1 for r in rr if r.get("matched")),
        total_rules_evaluated=len(rr),
    )


class AsaReportOutput(ActionOutput):
    verdict: str = OutputField()
    summary: str = OutputField()
    full_explanation: str = OutputField()
    attack_type: str = OutputField()


@app.action(action_type="investigate", read_only=True)
def get_asa_report(params: MessageIdParams, asset: SublimeAsset, soar: SOARClient) -> AsaReportOutput:
    j = _client(asset).get(f"/v0/messages/{params.message_id}/asa_report")
    return AsaReportOutput(
        verdict=j.get("verdict", ""), summary=j.get("summary", ""),
        full_explanation=j.get("full_explanation", ""), attack_type=j.get("attack_type", ""),
    )


class VerdictOutput(ActionOutput):
    verdict: str = OutputField(example_values=[
        "malicious", "spam", "graymail", "likely_benign", "benign", "unknown",
    ])


@app.action(action_type="investigate", read_only=True)
def get_asa_verdict(params: MessageIdParams, asset: SublimeAsset, soar: SOARClient) -> VerdictOutput:
    j = _client(asset).get(f"/v0/messages/{params.message_id}/asa_verdict")
    return VerdictOutput(verdict=j.get("verdict", "unknown"))


class GetAttachmentImageParams(Params):
    message_id: str = Param(description="Message UUID", required=True, primary=True)
    attachment_hash: str = Param(description="MD5 of attachment", required=True)


@app.action(action_type="investigate", read_only=True)
def get_attachment_image(
    params: GetAttachmentImageParams, asset: SublimeAsset, soar: SOARClient,
) -> ScreenshotOutput:
    j = _client(asset).get(f"/v0/messages/{params.message_id}/attachment/{params.attachment_hash}/image")
    return ScreenshotOutput(screenshot_vault_id=_save_images(
        soar, _iter_image_bytes(j.get("data")),
        f"attachment_{params.attachment_hash}_{{idx}}.png",
    ))


@app.action(action_type="investigate", read_only=True)
def get_message_image(params: MessageIdParams, asset: SublimeAsset, soar: SOARClient) -> ScreenshotOutput:
    j = _client(asset).get(f"/v0/messages/{params.message_id}/image")
    mime_type = j.get("mime_type", "image/png")
    ext = mime_type.split("/")[-1] if mime_type else "png"
    return ScreenshotOutput(screenshot_vault_id=_save_images(
        soar, _iter_image_bytes(j.get("data")),
        f"message_{params.message_id}_{{idx}}.{ext}",
    ))


class GetEmlOutput(ActionOutput):
    vault_id: str = OutputField()
    file_name: str = OutputField()


@app.action(action_type="investigate", read_only=True)
def get_message_eml(params: MessageIdParams, asset: SublimeAsset, soar: SOARClient) -> GetEmlOutput:
    eml = _client(asset).get_bytes(f"/v0/messages/{params.message_id}/eml", accept="message/rfc822")
    file_name = f"message_{params.message_id}.eml"
    vault_id = soar.vault.create_attachment(
        container_id=soar.get_executing_container_id(),
        file_content=eml, file_name=file_name,
        metadata={"contains": ["vault id"]},
    )
    return GetEmlOutput(vault_id=vault_id, file_name=file_name)


class GetMessageImageLinkParams(Params):
    message_id: str = Param(description="Message UUID", required=True, primary=True)
    link_duration_seconds: int = Param(default=0,
        description="Link lifetime in seconds (e.g. 3600 = 1 hour; 0 = server default)")
    platform_link: bool = Param(default=False,
        description="Return a Sublime platform link instead of a direct image URL")


class ImageLinkOutput(ActionOutput):
    url: str = OutputField()


@app.action(action_type="investigate", read_only=True)
def get_message_image_link(
    params: GetMessageImageLinkParams, asset: SublimeAsset, soar: SOARClient,
) -> ImageLinkOutput:
    q: dict = {}
    if params.link_duration_seconds: q["link_duration_seconds"] = params.link_duration_seconds
    if params.platform_link: q["platform_link"] = True
    j = _client(asset).get(f"/v0/messages/{params.message_id}/image_link", q)
    return ImageLinkOutput(url=j.get("url", ""))


class SetJustificationParams(Params):
    message_id: str = Param(description="Message UUID", required=True, primary=True)
    justification: str = Param(description="Access justification text", required=True)


@app.action(action_type="generic", read_only=False)
def set_access_justification(
    params: SetJustificationParams, asset: SublimeAsset, soar: SOARClient,
) -> StatusOutput:
    _client(asset).post(
        f"/v0/messages/{params.message_id}/justification",
        {"justification": params.justification},
    )
    return StatusOutput(status="set")


class MDMOutput(ActionOutput):
    id: str = OutputField()


@app.action(action_type="investigate", read_only=True)
def get_message_data_model(params: MessageIdParams, asset: SublimeAsset, soar: SOARClient) -> MDMOutput:
    j = _client(asset).get(f"/v0/messages/{params.message_id}/message_data_model")
    return MDMOutput(id=j.get("id", "") or (j.get("message") or {}).get("id", ""))


@app.action(action_type="correct", read_only=False)
def restore_message(params: MessageIdParams, asset: SublimeAsset, soar: SOARClient) -> TaskIdOutput:
    return TaskIdOutput(task_id=_client(asset).post(
        f"/v0/messages/{params.message_id}/restore", {},
    ).get("task_id", ""))


@app.action(action_type="correct", read_only=False)
def trash_message(params: MessageIdParams, asset: SublimeAsset, soar: SOARClient) -> TaskIdOutput:
    return TaskIdOutput(task_id=_client(asset).post(
        f"/v0/messages/{params.message_id}/trash", {},
    ).get("task_id", ""))


# =============================================================================
# Actions — Rules
# =============================================================================
class ListRulesParams(Params):
    limit: int = Param(default=100, description="Max rules to return (1-500)")
    offset: int = Param(default=0, description="Pagination offset")
    search: str = Param(default="", description="Substring match against rule name/description")
    in_feed: bool = Param(default=False, description="Only return rules from the Sublime core feed")


class RulesListOutput(ActionOutput):
    total_rules: int = OutputField()
    rules_returned: int = OutputField()


@app.action(action_type="investigate", read_only=True)
def list_rules(params: ListRulesParams, asset: SublimeAsset, soar: SOARClient) -> RulesListOutput:
    q: dict = {"limit": min(params.limit, 500), "offset": params.offset}
    if params.search: q["search"] = params.search
    if params.in_feed: q["in_feed"] = True
    j = _client(asset).get("/v0/rules", q)
    rules = j.get("rules") or []
    return RulesListOutput(total_rules=int(j.get("total", 0)), rules_returned=len(rules))


class _RuleFieldsBase(Params):
    # Shared between create_rule (name/source required) and update_rule (rule_id required).
    type: str = Param(default="", value_list=RULE_TYPES, description="Rule type")
    severity: str = Param(default="", value_list=RULE_SEVERITIES, description="Severity assigned when rule fires")
    description: str = Param(default="", description="Free-text rule description")
    label: str = Param(default="", description="Optional label string")
    maturity: str = Param(default="", description="Rule maturity (e.g. production, beta, draft)")
    auto_review_classification: str = Param(default="",
        description="Classification to auto-apply on review (e.g. malicious)")
    internal_type: str = Param(default="", description="For core feed only; leave blank for tenant rules")
    active: bool = Param(default=False, description="Activate the rule immediately")
    auto_review_auto_share: bool = Param(default=False,
        description="Auto-share with Sublime when auto-review fires")
    triage_abuse_reports: bool = Param(default=False, description="Run on abuse reports")
    triage_flagged_messages: bool = Param(default=False, description="Run on flagged messages")
    triage_classification_changes: bool = Param(default=False, description="Run on classification changes")
    triage_dlp_rule_matched: bool = Param(default=False, description="Run on DLP matches")
    run_triage_on_excluded_messages: bool = Param(default=False,
        description="Include excluded messages in triage scope")
    tags: str = Param(default="", description="Comma-separated tag strings")
    user_provided_tags: str = Param(default="", description="Comma-separated user-defined tags")
    attack_types: str = Param(default="", description="Comma-separated MITRE attack types")
    detection_methods: str = Param(default="", description="Comma-separated detection methods")
    tactics_and_techniques: str = Param(default="", description="Comma-separated MITRE tactics/techniques")
    false_positives: str = Param(default="", description="Comma-separated false-positive notes")
    references: str = Param(default="", description="Comma-separated reference URLs")
    action_ids: str = Param(default="", description="Comma-separated action UUIDs to trigger")
    authors: str = Param(default="", description='JSON array of {"name":"...","twitter":"..."} objects')


def _build_rule_body(p: Any, *, include_name_source: bool) -> dict:
    body: dict = {}
    if include_name_source:
        body["name"] = p.name
        body["source"] = p.source
    else:
        for k in ("name", "source"):
            v = getattr(p, k, "")
            if v: body[k] = v
    for k in ("type", "severity", "description", "label", "maturity",
              "auto_review_classification", "internal_type"):
        v = getattr(p, k)
        if v: body[k] = v
    if p.active: body["active"] = True
    if p.auto_review_auto_share: body["auto_review_auto_share"] = True
    for k in ("triage_abuse_reports", "triage_flagged_messages", "triage_classification_changes",
              "triage_dlp_rule_matched", "run_triage_on_excluded_messages"):
        if getattr(p, k): body[k] = True
    for k in ("tags", "user_provided_tags", "attack_types", "detection_methods",
              "tactics_and_techniques", "false_positives", "references", "action_ids"):
        v = getattr(p, k)
        if v: body[k] = parse_csv(v)
    if p.authors:
        try:
            parsed = _json.loads(p.authors)
        except Exception as e:
            raise ActionFailure(f"authors must be JSON: {e!s}")
        if not isinstance(parsed, list):
            raise ActionFailure("authors must be a JSON array")
        body["authors"] = parsed
    return body


class CreateRuleParams(_RuleFieldsBase):
    name: str = Param(description="Rule name", required=True)
    source: str = Param(description="MQL source", required=True)


class RuleIdOutput(ActionOutput):
    rule_id: str = OutputField()


@app.action(action_type="generic", read_only=False)
def create_rule(params: CreateRuleParams, asset: SublimeAsset, soar: SOARClient) -> RuleIdOutput:
    j = _client(asset).post("/v0/rules", _build_rule_body(params, include_name_source=True))
    return RuleIdOutput(rule_id=j.get("id", ""))


class UpdateRuleParams(_RuleFieldsBase):
    rule_id: str = Param(description="Rule ID", required=True, primary=True)
    name: str = Param(default="")
    source: str = Param(default="")


class RuleSummaryOutput(ActionOutput):
    name: str = OutputField()
    active: bool = OutputField()


@app.action(action_type="generic", read_only=False)
def update_rule(params: UpdateRuleParams, asset: SublimeAsset, soar: SOARClient) -> RuleSummaryOutput:
    j = _client(asset).put(f"/v0/rules/{params.rule_id}", _build_rule_body(params, include_name_source=False))
    return RuleSummaryOutput(name=j.get("name", ""), active=bool(j.get("active", False)))


class ValidateRuleParams(Params):
    name: str = Param(required=True)
    source: str = Param(required=True)


class ValidateOutput(ActionOutput):
    valid: bool = OutputField()


@app.action(action_type="investigate", read_only=True)
def validate_rule(params: ValidateRuleParams, asset: SublimeAsset, soar: SOARClient) -> ValidateOutput:
    j = _client(asset).post("/v0/rules/validate", {"name": params.name, "source": params.source})
    return ValidateOutput(valid=bool(j.get("valid", False)))


class RuleIdParams(Params):
    rule_id: str = Param(description="Rule ID", required=True, primary=True)


@app.action(action_type="generic", read_only=False)
def delete_rule(params: RuleIdParams, asset: SublimeAsset, soar: SOARClient) -> StatusOutput:
    _client(asset).delete(f"/v0/rules/{params.rule_id}")
    return StatusOutput(status="deleted")


@app.action(action_type="investigate", read_only=True)
def get_rule(params: RuleIdParams, asset: SublimeAsset, soar: SOARClient) -> RuleSummaryOutput:
    j = _client(asset).get(f"/v0/rules/{params.rule_id}")
    return RuleSummaryOutput(name=j.get("name", ""), active=bool(j.get("active", False)))


@app.action(action_type="generic", read_only=False)
def activate_rule(params: RuleIdParams, asset: SublimeAsset, soar: SOARClient) -> RuleSummaryOutput:
    j = _client(asset).post(f"/v0/rules/{params.rule_id}/activate", {})
    return RuleSummaryOutput(name=j.get("name", ""), active=bool(j.get("active", True)))


@app.action(action_type="generic", read_only=False)
def deactivate_rule(params: RuleIdParams, asset: SublimeAsset, soar: SOARClient) -> RuleSummaryOutput:
    j = _client(asset).post(f"/v0/rules/{params.rule_id}/deactivate", {})
    return RuleSummaryOutput(name=j.get("name", ""), active=bool(j.get("active", False)))


class ListRuleHistoryParams(Params):
    start_time: str = Param(required=True,
        description="Lower bound classification_created_at (ISO 8601 UTC, e.g. 2026-05-09T00:00:00Z)")
    end_time: str = Param(required=True,
        description="Upper bound classification_created_at, inclusive (ISO 8601 UTC, e.g. 2026-05-16T00:00:00Z)")
    active: bool = Param(default=False, description="Only include currently-active rules")
    in_feed: bool = Param(default=False, description="Only include feed rules")
    type: str = Param(default="", description="Comma-separated rule types (detection,dlp,triage)")
    count: int = Param(default=0, description="Max records (0 = server default)")
    offset: int = Param(default=0, description="Pagination offset")


class HistoryOutput(ActionOutput):
    total: int = OutputField()


@app.action(action_type="investigate", read_only=True)
def list_rule_history(
    params: ListRuleHistoryParams, asset: SublimeAsset, soar: SOARClient,
) -> HistoryOutput:
    q: dict = {
        "classification_created_at[gte]": params.start_time,
        "classification_created_at[lte]": params.end_time,
    }
    if params.active: q["active"] = True
    if params.in_feed: q["in_feed"] = True
    if params.type: q["type"] = parse_csv(params.type)
    if params.count: q["count"] = params.count
    if params.offset: q["offset"] = params.offset
    j = _client(asset).get("/v0/rules/rule-history", q)
    return HistoryOutput(total=int(j.get("total", len(j.get("rule_history") or []))))


class GetRuleHistoryParams(Params):
    rule_id: str = Param(description="Rule ID", required=True, primary=True)
    start_time: str = Param(default="",
        description="Lower bound classification_created_at (ISO 8601 UTC, e.g. 2026-05-09T00:00:00Z)")
    end_time: str = Param(default="",
        description="Upper bound classification_created_at, inclusive (ISO 8601 UTC, e.g. 2026-05-16T00:00:00Z)")
    use_rule_last_updated_as_created_at: bool = Param(default=False,
        description="Use the rule's last_updated as classification_created_at")


@app.action(action_type="investigate", read_only=True)
def get_rule_history(
    params: GetRuleHistoryParams, asset: SublimeAsset, soar: SOARClient,
) -> HistoryOutput:
    q: dict = {}
    if params.start_time: q["classification_created_at[gte]"] = params.start_time
    if params.end_time: q["classification_created_at[lte]"] = params.end_time
    if params.use_rule_last_updated_as_created_at:
        q["use_rule_last_updated_as_created_at"] = True
    j = _client(asset).get(f"/v0/rules/{params.rule_id}/rule-history", q)
    return HistoryOutput(total=int(j.get("total", len(j.get("rule_history") or []))))


# =============================================================================
# Actions — SCIM
# =============================================================================
@app.action(action_type="investigate", read_only=True)
def list_scim_resource_types(params: NoParams, asset: SublimeAsset, soar: SOARClient) -> CountOutput:
    j = _client(asset).get("/v0/scim/ResourceTypes")
    return CountOutput(total=len(j.get("Resources") or []))


class ResourceTypeIdParams(Params):
    resource_type_id: str = Param(description="Resource type ID", required=True, primary=True)


class ResourceTypeOutput(ActionOutput):
    name: str = OutputField()


@app.action(action_type="investigate", read_only=True)
def get_scim_resource_type(
    params: ResourceTypeIdParams, asset: SublimeAsset, soar: SOARClient,
) -> ResourceTypeOutput:
    j = _client(asset).get(f"/v0/scim/ResourceTypes/{params.resource_type_id}")
    return ResourceTypeOutput(name=j.get("name", ""))


class ListScimUsersParams(Params):
    count: int = Param(default=100, description="Page size (1-1000)")
    start_index: int = Param(default=1, description="1-based start index (SCIM convention)")
    filter: str = Param(default="",
        description='SCIM filter expression (e.g. userName eq "alice@example.com")')


class ScimUsersOutput(ActionOutput):
    total_results: int = OutputField()


@app.action(action_type="investigate", read_only=True)
def list_scim_users(params: ListScimUsersParams, asset: SublimeAsset, soar: SOARClient) -> ScimUsersOutput:
    q: dict = {"count": min(params.count, SCIM_MAX_COUNT), "startIndex": max(params.start_index, 1)}
    if params.filter: q["filter"] = params.filter
    j = _client(asset).get("/v0/scim/Users", q)
    return ScimUsersOutput(total_results=int(j.get("totalResults", len(j.get("Resources") or []))))


class ScimUserBase(Params):
    user_name: str = Param(description="userName", required=True)
    given_name: str = Param(description="name.givenName", required=True)
    family_name: str = Param(description="name.familyName", required=True)
    email: str = Param(description="primary work email", required=True)
    active: bool = Param(default=True)


class ScimUserIdOutput(ActionOutput):
    user_id: str = OutputField()


def _scim_user_body(p: ScimUserBase) -> dict:
    return {
        "userName": p.user_name,
        "name": {"givenName": p.given_name, "familyName": p.family_name},
        "emails": [{"value": p.email, "type": "work", "primary": True}],
        "active": p.active,
        "schemas": SCIM_USER_SCHEMA,
    }


@app.action(action_type="generic", read_only=False)
def create_scim_user(params: ScimUserBase, asset: SublimeAsset, soar: SOARClient) -> ScimUserIdOutput:
    j = _client(asset).post("/v0/scim/Users", _scim_user_body(params))
    return ScimUserIdOutput(user_id=j.get("id", ""))


class ScimUserIdParams(Params):
    user_id: str = Param(description="SCIM user ID", required=True, primary=True)


class ScimUserOutput(ActionOutput):
    user_name: str = OutputField()
    active: bool = OutputField()


@app.action(action_type="investigate", read_only=True)
def get_scim_user(params: ScimUserIdParams, asset: SublimeAsset, soar: SOARClient) -> ScimUserOutput:
    j = _client(asset).get(f"/v0/scim/Users/{params.user_id}")
    return ScimUserOutput(user_name=j.get("userName", ""), active=bool(j.get("active", False)))


@app.action(action_type="generic", read_only=False)
def delete_scim_user(params: ScimUserIdParams, asset: SublimeAsset, soar: SOARClient) -> StatusOutput:
    _client(asset).delete(f"/v0/scim/Users/{params.user_id}")
    return StatusOutput(status="deleted")


class UpdateScimUserParams(ScimUserBase):
    user_id: str = Param(description="SCIM user ID", required=True, primary=True)


@app.action(action_type="generic", read_only=False)
def update_scim_user(params: UpdateScimUserParams, asset: SublimeAsset, soar: SOARClient) -> ScimUserOutput:
    j = _client(asset).put(f"/v0/scim/Users/{params.user_id}", _scim_user_body(params))
    return ScimUserOutput(user_name=j.get("userName", ""), active=bool(j.get("active", False)))


class PatchScimUserParams(Params):
    user_id: str = Param(description="SCIM user ID", required=True, primary=True)
    operations_json: str = Param(description="JSON array of SCIM PATCH operations", required=True)


@app.action(action_type="generic", read_only=False)
def patch_scim_user(params: PatchScimUserParams, asset: SublimeAsset, soar: SOARClient) -> ScimUserOutput:
    try:
        operations = _json.loads(params.operations_json)
    except (TypeError, _json.JSONDecodeError) as e:
        raise ActionFailure(f"invalid operations_json: {e!s}")
    j = _client(asset).patch(
        f"/v0/scim/Users/{params.user_id}",
        {"schemas": SCIM_PATCH_SCHEMA, "Operations": operations},
    )
    return ScimUserOutput(user_name=j.get("userName", ""), active=bool(j.get("active", False)))


class ScimAuthOutput(ActionOutput):
    valid: bool = OutputField()


@app.action(action_type="investigate", read_only=True)
def validate_scim_auth(params: NoParams, asset: SublimeAsset, soar: SOARClient) -> ScimAuthOutput:
    j = _client(asset).get("/v0/scim/validate_auth")
    return ScimAuthOutput(valid=bool(j.get("valid", True)))


@app.action(action_type="investigate", read_only=True)
def list_scim_schemas(params: NoParams, asset: SublimeAsset, soar: SOARClient) -> CountOutput:
    j = _client(asset).get("/v0/scim/Schemas")
    return CountOutput(total=len(j.get("Resources") or []))


class ScimSchemaIdParams(Params):
    schema_id: str = Param(description="Schema ID/URN", required=True, primary=True)


class ScimSchemaOutput(ActionOutput):
    id: str = OutputField()


@app.action(action_type="investigate", read_only=True)
def get_scim_schema(params: ScimSchemaIdParams, asset: SublimeAsset, soar: SOARClient) -> ScimSchemaOutput:
    j = _client(asset).get(f"/v0/scim/Schemas/{params.schema_id}")
    return ScimSchemaOutput(id=j.get("id", ""))


class ScimServiceProviderConfigOutput(ActionOutput):
    documentation_uri: str = OutputField()


@app.action(action_type="investigate", read_only=True)
def get_scim_service_provider_config(
    params: NoParams, asset: SublimeAsset, soar: SOARClient,
) -> ScimServiceProviderConfigOutput:
    j = _client(asset).get("/v0/scim/ServiceProviderConfig")
    return ScimServiceProviderConfigOutput(
        documentation_uri=j.get("documentationUri", "") or j.get("documentationURI", ""),
    )


# =============================================================================
# on_poll — branch on asset.poll_source ("message_groups" or "audit_logs")
# =============================================================================
@app.on_poll()
def on_poll(params: OnPollParams, soar: SOARClient, asset: SublimeAsset
            ) -> Iterator[Container | Artifact]:
    if asset.poll_source == "audit_logs":
        yield from _poll_audit_logs(params, soar, asset)
    else:
        yield from _poll_message_groups(params, soar, asset)


def _poll_message_groups(params: OnPollParams, soar: SOARClient, asset: SublimeAsset
                         ) -> Iterator[Container | Artifact]:
    state = asset.ingest_state
    last_seen = state.get("last_mg_created_at") if hasattr(state, "get") else None

    q: dict = {"limit": min(getattr(params, "container_count", 100) or 100, 200)}
    if last_seen and not getattr(params, "is_manual_poll", lambda: False)():
        q["created_at__gte"] = last_seen
    elif getattr(params, "start_time", None):
        q["created_at__gte"] = params.start_time
    if getattr(params, "end_time", None):
        q["created_at__lt"] = params.end_time

    try:
        j = _client(asset).get("/v0/message-groups", q)
    except ActionFailure as e:
        log.warning("on_poll list_message_groups failed: %s", e)
        return

    newest_seen = last_seen
    for g in (j.get("message_groups") or []):
        if not isinstance(g, dict):
            continue
        synthetic = {"type": "message_group.polled", "id": g.get("id", ""), "data": g}
        container = _build_container(
            synthetic, g,
            label=asset.webhook_container_label,
            severity_cfg=asset.webhook_container_severity,
            sensitivity=asset.webhook_container_sensitivity,
        )
        yield Container(**{k: v for k, v in container.items() if k in {
            "name", "description", "label", "severity", "sensitivity", "tags",
            "source_data_identifier", "data",
        }})
        artifact = _build_message_artifact(synthetic, g)
        yield Artifact(
            name=artifact["name"], label=artifact["label"],
            source_data_identifier=artifact["source_data_identifier"],
            cef=artifact["cef"], cef_types=artifact["cef_types"],
            data=artifact["data"], run_automation=True, type="flagged message",
        )
        ts = g.get("created_at") or g.get("first_message_reported_at")
        if ts and (newest_seen is None or ts > newest_seen):
            newest_seen = ts

    if newest_seen and hasattr(state, "__setitem__"):
        state["last_mg_created_at"] = newest_seen


def _poll_audit_logs(params: OnPollParams, soar: SOARClient, asset: SublimeAsset
                     ) -> Iterator[Container | Artifact]:
    """One container per poll cycle holding new audit events as artifacts.
    Containers are only emitted when there's at least one new event to avoid
    creating empty containers on quiet intervals."""
    state = asset.ingest_state
    last_seen = state.get("last_audit_created_at") if hasattr(state, "get") else None

    q: dict = {"limit": min(getattr(params, "container_count", 100) or 100, 200)}
    if last_seen and not getattr(params, "is_manual_poll", lambda: False)():
        q["created_at[gte]"] = last_seen
    elif getattr(params, "start_time", None):
        q["created_at[gte]"] = params.start_time
    if getattr(params, "end_time", None):
        q["created_at[lt]"] = params.end_time

    try:
        j = _client(asset).get("/v0/audit-log/events", q)
    except ActionFailure as e:
        log.warning("on_poll list_audit_events failed: %s", e)
        return

    events = j.get("events") or []
    if not events:
        return

    import datetime
    poll_ts = datetime.datetime.utcnow().isoformat() + "Z"
    yield Container(
        name=f"Sublime Audit Events: {poll_ts}",
        description=f"{len(events)} audit event(s) collected by scheduled poll",
        label=asset.webhook_container_label,
        severity="low",
        sensitivity=asset.webhook_container_sensitivity,
        source_data_identifier=f"sublime-audit-poll:{poll_ts}",
        tags=["sublime-audit"],
    )

    newest_seen = last_seen
    for ev in events:
        if not isinstance(ev, dict):
            continue
        cef = {
            "eventId": ev.get("id", ""),
            "eventType": ev.get("type", ""),
            "eventCreatedAt": ev.get("created_at", ""),
            "userId": ev.get("user_id", "") or (ev.get("user") or {}).get("id", ""),
            "userEmail": ev.get("user_email", "") or (ev.get("user") or {}).get("email", ""),
            "targetId": ev.get("target_id", "") or (ev.get("target") or {}).get("id", ""),
            "targetType": ev.get("target_type", "") or (ev.get("target") or {}).get("type", ""),
            "ipAddress": ev.get("ip_address", "") or ev.get("source_ip", ""),
        }
        cef = {k: v for k, v in cef.items() if v}
        yield Artifact(
            name=f"{ev.get('type', 'audit')} — {ev.get('created_at', '')}",
            label="audit event",
            source_data_identifier=f"audit:{ev.get('id', '')}",
            cef=cef,
            cef_types={
                "eventId": ["audit event id"],
                "userEmail": ["email"],
                "ipAddress": ["ip"],
            },
            data=ev,
            run_automation=True,
            type="audit",
        )
        ts = ev.get("created_at")
        if ts and (newest_seen is None or ts > newest_seen):
            newest_seen = ts

    if newest_seen and hasattr(state, "__setitem__"):
        state["last_audit_created_at"] = newest_seen


# =============================================================================
# Inbound webhook
# =============================================================================
def _create_error_container(
    soar: SOARClient, asset: SublimeAsset, *,
    reason: str, errors: list[Any], raw_body: bytes, request_headers: dict | None,
    payload: dict | None = None,
) -> str | None:
    """Create a flagged container for unprocessable webhook events so the
    failure surfaces in SOAR rather than only in the HTTP response. Vault
    holds a JSON dump of raw body + headers + error details for triage."""
    import datetime
    import hashlib

    ts = datetime.datetime.utcnow().isoformat() + "Z"
    sdi_seed = (raw_body or b"") + ts.encode()
    sdi = hashlib.sha256(sdi_seed).hexdigest()[:32]

    container = {
        "name": f"Webhook Error: {reason}",
        "description": "Sublime Security webhook could not process this event. See vault for raw body and error context.",
        "source_data_identifier": f"sublime-webhook-error:{sdi}",
        "label": asset.webhook_container_label,
        "severity": "high",
        "sensitivity": asset.webhook_container_sensitivity,
        "tags": ["sublime-webhook-error", "error"],
        "status": "open",
        "data": payload or {},
    }
    try:
        container_id = soar.container.create(container)
    except Exception as e:
        log.warning("error container create failed: %s", e)
        return None

    debug = {
        "timestamp": ts,
        "reason": reason,
        "errors": errors if isinstance(errors, list) else [str(errors)],
        "request_headers": {k: v for k, v in (request_headers or {}).items()
                            if k.lower() != "ph-auth-token"},
        "raw_body": raw_body.decode("utf-8", errors="replace") if isinstance(raw_body, (bytes, bytearray)) else str(raw_body or ""),
    }
    file_name = f"webhook_error_{int(time.time())}.json"
    try:
        vault_id = soar.vault.create_attachment(
            container_id=container_id,
            file_content=_json.dumps(debug, indent=2, default=str).encode("utf-8"),
            file_name=file_name,
        )
        soar.artifact.create({
            "container_id": container_id,
            "name": f"Webhook Error: {reason}",
            "label": "event",
            "source_data_identifier": f"sublime-webhook-error-artifact:{sdi}",
            "cef": {
                "errorReason": reason,
                "errorDetail": str(errors)[:1024],
                "vaultId": vault_id,
                "fileName": file_name,
            },
            "cef_types": {"vaultId": ["vault id"], "fileName": ["file name"]},
            "run_automation": False,
        })
    except Exception as e:
        log.warning("error container vault/artifact create failed: %s", e)
    return container_id


def _verify_sublime_signature(asset: SublimeAsset, raw_body: bytes, sig_header: str | None) -> str | None:
    """Verify Sublime's X-Sublime-Signature HMAC. Returns None on success, or an
    error reason string. If no signing secret is configured on the asset,
    verification is skipped (returns None). v0 is the only valid scheme —
    other versions are ignored to prevent downgrade attacks."""
    secret = (asset.webhook_signing_secret or "").strip()
    if not secret:
        return None
    if not sig_header:
        return "missing X-Sublime-Signature header"

    timestamp: str | None = None
    v0_sigs: list[str] = []
    for part in sig_header.split(","):
        k, _, v = part.strip().partition("=")
        if k == "t":
            timestamp = v.strip()
        elif k == "v0":
            v0_sigs.append(v.strip())

    if not timestamp or not v0_sigs:
        return "X-Sublime-Signature missing t= or v0= component"

    try:
        ts_int = int(timestamp)
    except ValueError:
        return f"X-Sublime-Signature has non-numeric timestamp: {timestamp!r}"

    tolerance = int(asset.webhook_signature_tolerance_seconds or 300)
    age = int(time.time()) - ts_int
    if age > tolerance:
        return f"X-Sublime-Signature timestamp too old ({age}s > tolerance {tolerance}s)"
    if age < -tolerance:
        return f"X-Sublime-Signature timestamp is in the future ({-age}s ahead of server clock)"

    signed_payload = f"{timestamp}.".encode("utf-8") + raw_body
    expected = hmac.new(secret.encode("utf-8"), signed_payload, hashlib.sha256).hexdigest()
    if any(hmac.compare_digest(expected, s) for s in v0_sigs):
        return None
    return "X-Sublime-Signature HMAC did not match"


def _parse_blocks(payload: dict) -> list[dict]:
    """Sublime webhooks arrive in three shapes: single `data` object,
    `data.messages` list (shared envelope + per-message overrides), or a
    top-level `events` array. Normalize to a list of per-message blocks."""
    data = payload.get("data") if isinstance(payload.get("data"), dict) else {}
    if isinstance(data.get("messages"), list) and data["messages"]:
        shared = {k: v for k, v in data.items() if k != "messages"}
        blocks: list[dict] = []
        for m in data["messages"]:
            if not isinstance(m, dict):
                continue
            merged = dict(shared)
            merged.update(m)
            if "message" not in merged and ("id" in m or "canonical_id" in m):
                merged["message"] = m
            blocks.append(merged)
        return blocks
    if isinstance(payload.get("events"), list) and payload["events"]:
        return [ev["data"] for ev in payload["events"]
                if isinstance(ev, dict) and isinstance(ev.get("data"), dict)]
    return [data]


@app.webhook("webhook", allowed_methods=["POST"])
def webhook(request: WebhookRequest[SublimeAsset], soar: SOARClient) -> WebhookResponse:
    asset = request.asset
    body = request.body or ""
    raw = body.encode("utf-8") if isinstance(body, str) else (body or b"")
    headers = dict(request.headers or {})

    # Two layers of authentication:
    #   1. SOAR's native Webhook Settings handle ph-auth-token + IP allowlist.
    #   2. If webhook_signing_secret is set on the asset, verify the
    #      X-Sublime-Signature HMAC of the raw body.
    sig_header = headers.get("X-Sublime-Signature") or headers.get("x-sublime-signature")
    sig_error = _verify_sublime_signature(asset, raw, sig_header)
    if sig_error:
        return WebhookResponse.json_response(
            {"error": f"signature verification failed: {sig_error}"},
            status_code=401,
        )

    try:
        payload = _json.loads(body) if body else {}
    except Exception as e:
        _create_error_container(
            soar, asset, reason="invalid JSON",
            errors=[str(e)], raw_body=raw, request_headers=headers,
        )
        return WebhookResponse.json_response({"error": f"invalid JSON: {e!s}"}, status_code=400)

    if not isinstance(payload, dict):
        _create_error_container(
            soar, asset, reason="payload not an object",
            errors=["payload must be a JSON object"], raw_body=raw, request_headers=headers,
        )
        return WebhookResponse.json_response({"error": "payload must be a JSON object"}, status_code=400)

    blocks = _parse_blocks(payload)
    results: list[dict[str, Any]] = []
    errors: list[dict[str, Any]] = []

    for block in blocks:
        if not isinstance(block, dict):
            continue
        try:
            container_id = soar.container.create(_build_container(
                payload, block,
                label=asset.webhook_container_label,
                severity_cfg=asset.webhook_container_severity,
                sensitivity=asset.webhook_container_sensitivity,
            ))
        except Exception as e:
            errors.append({"stage": "container", "error": str(e)})
            continue

        try:
            artifact = _build_message_artifact(payload, block)
            artifact["container_id"] = container_id
            soar.artifact.create(artifact)
        except Exception as e:
            errors.append({"stage": "artifact", "container_id": container_id, "error": str(e)})
            continue

        message_id = ((block.get("message") or {}).get("id") if isinstance(block.get("message"), dict) else "") \
                     or block.get("id") or ""
        result = {"container_id": container_id, "message_id": message_id}

        if asset.webhook_pull_eml and message_id:
            try:
                eml = _client(asset).get_bytes(f"/v0/messages/{message_id}/eml", accept="message/rfc822")
                file_name = f"{message_id}.eml"
                vault_id = soar.vault.create_attachment(
                    container_id=container_id, file_content=eml, file_name=file_name,
                )
                soar.artifact.create({
                    "container_id": container_id,
                    "name": f"EML for {message_id}",
                    "label": "email",
                    "source_data_identifier": f"eml:{message_id}",
                    "cef": {"vaultId": vault_id, "fileName": file_name, "messageId": message_id},
                    "cef_types": {
                        "vaultId": ["vault id"], "fileName": ["file name"], "messageId": ["message id"],
                    },
                })
                result["eml_vault_id"] = vault_id
            except Exception as e:
                errors.append({"stage": "eml", "container_id": container_id,
                               "message_id": message_id, "error": str(e)})

        results.append(result)

    # If every block failed, surface the whole event as an error container.
    if not results and errors:
        _create_error_container(
            soar, asset, reason="no blocks processed",
            errors=errors, raw_body=raw, request_headers=headers, payload=payload,
        )

    if not results and errors:
        status = 500
    elif errors:
        status = 207
    else:
        status = 200
    body_out: dict[str, Any] = {
        "status": "success" if not errors else ("partial_success" if results else "error"),
        "containers_created": len(results),
        "results": results,
    }
    if errors:
        body_out["errors"] = errors
    return WebhookResponse.json_response(body_out, status_code=status)


if __name__ == "__main__":
    app.cli()
