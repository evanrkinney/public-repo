<img src="logo_dark.svg" width="300">

# Sublime Security — Splunk SOAR App

Publisher: Splunk SOAR Community
Connector Version: 1.0.0
Product Vendor: Sublime Security
Product Name: Sublime Platform
Minimum Product Version: 6.3.0

A community-maintained Splunk SOAR connector for the [Sublime Security
Platform](https://sublime.security) API. Investigate and respond to email
threats detected by Sublime — triage and review flagged messages and message
groups, manage detection rules, mailboxes, lists, and user reports, run binary
and link enrichment, and ingest audit events. Includes scheduled polling and
an inbound webhook for real-time delivery of newly flagged messages into SOAR
containers.

Built on the [Splunk SOAR SDK](https://phantomcyber.github.io/splunk-soar-sdk/) —
the manifest (`app.json`) is generated from the decorators in
[src/app.py](src/app.py) at `soarapps package build` time.

## Features

- **Full Sublime Platform API coverage** — audit log, hunt jobs, lists, message
  groups, messages, rules, SCIM, tasks, user reports, and enrichment actions
- **BinExplode analysis** — submit files via Vault ID or base64 and retrieve
  scan trees
- **Link analysis (`ml.link_analysis`)** — returns disposition, brand,
  confidence, and saves page screenshots to the SOAR Vault
- **Vault integration everywhere** — any action that accepts or returns a file
  works with Splunk SOAR Vault IDs. EML downloads, rendered message images,
  attachment renders, and link-analysis screenshots are automatically stored
  in the Vault
- **List entry CSV workflow** — export list entries to Vault as CSV, and bulk
  import entries from a CSV Vault file
- **Inbound webhook handler** — receive Sublime webhooks at
  `https://<soar-host>/rest/handler/sublimesecurity/<asset_name>/webhook` to
  automatically create containers and artifacts per flagged message
- **Scheduled polling** — pull new flagged message groups *or* audit-log events
  on the asset's poll interval; high-water marks are persisted in
  `asset.ingest_state`

## Asset Configuration

| Parameter | Required | Description |
|-----------|----------|-------------|
| `region` | Yes | Sublime Security region. One of: NA-East, NA-West, Canada, UK (London), Europe (Dublin), Australia, Custom. Default `NA-East`. |
| `base_url` | No | Custom Sublime platform base URL (e.g. `https://platform.example.com`). Only used when `region` = Custom. |
| `api_key` | Yes | API key for Sublime Security. Found in the Sublime dashboard under **Automate > API**. |
| `verify_server_cert` | No | Verify the server certificate. Default `true`. |
| `webhook_container_label` | No | Label applied to containers created from inbound webhook events. Default `events`. |
| `webhook_container_severity` | No | Severity for webhook containers. One of `low`, `medium`, `high`, or `use alert severity` (inherits the highest flagged-rule severity from the payload). Default `medium`. |
| `webhook_container_sensitivity` | No | Sensitivity (TLP) for webhook containers. One of `white`, `green`, `amber`, `red`. Default `amber`. |
| `webhook_pull_eml` | No | If true, fetch the original `.eml` from Sublime for each webhook event, attach it to the container Vault, and emit an `email` artifact with `vaultId`. Default `false`. |
| `poll_source` | No | What scheduled polling ingests. `message_groups` (one container per new flagged group) or `audit_logs` (one container per poll cycle). Default `message_groups`. |
| `webhook_signing_secret` | No | Signing secret from the Sublime webhook Action. When set, the app verifies the `X-Sublime-Signature` HMAC on every inbound webhook. Leave blank to rely solely on SOAR's `ph-auth-token` + IP allowlist. |
| `webhook_signature_tolerance_seconds` | No | Max allowed age (seconds) of the `X-Sublime-Signature` timestamp before the request is rejected. Default `300`. |

### Regional Base URLs

| Region | Base URL |
|--------|----------|
| NA-East | https://platform.sublime.security |
| NA-West | https://na-west.platform.sublime.security |
| Canada | https://ca.platform.sublime.security |
| UK (London) | https://uk.platform.sublime.security |
| Europe (Dublin) | https://eu.platform.sublime.security |
| Australia | https://au.platform.sublime.security |
| Custom | (from `base_url` asset field) |

## File Inputs

Actions that accept file data (upload binary, process raw message, analyze raw
message, render attachment image, get attack score raw, create message)
support two input modes:

- **`vault_id`** — a Vault ID of a file already stored in Splunk SOAR
- **`base64_data`** — the raw base64-encoded file contents

Provide exactly one. When a Vault ID is supplied, the connector retrieves the
file contents from the SOAR Vault before sending to Sublime Security.

## Inbound Webhook (REST Handler)

The app exposes a REST handler for receiving webhooks from Sublime Security.
Configure Sublime to POST events to:

```
https://<soar-host>/rest/handler/sublimesecurity/<asset_name>/webhook
```

For each event received, the handler will:

1. Create a SOAR container per flagged message (named `Message Flagged: <subject>`)
2. Create a **`flagged message`** artifact with CEF for subject, sender,
   recipients (to/cc/bcc/reply-to), verdicts, matched rules, attachments,
   links, sender IP, etc. The artifact's `raw_data` carries the unmodified
   Sublime payload
3. If `webhook_pull_eml` is enabled: fetch the original `.eml` from Sublime,
   attach it to the container Vault, and create a second **`email`** artifact
   named `EML for <message_id>` with `vaultId`/`fileName`/`messageId` in CEF

If the webhook can't process the event (invalid JSON, non-object payload, or
every message-block fails), the handler creates a separate diagnostic
container named `Webhook Error: <reason>` with the raw body and request
headers (minus `ph-auth-token`) attached via Vault.

### Authenticating inbound webhooks with `ph-auth-token`

The webhook REST handler is declared with `requires_auth: true`, which means
Splunk SOAR expects every inbound POST to carry a `ph-auth-token` header bound
to an **Automation** user. You must provision this automation account before
enabling the webhook.

**Provision the automation user** (see the Splunk Phantom
[PlatformAPI docs](https://docs.splunk.com/Documentation/Phantom/4.10.7/PlatformAPI/Using)):

1. Log in to Splunk SOAR / Phantom as an administrative user.
2. From the Main Menu, select **Administration**.
3. Select **User Management > Users**.
4. Click **+ User** to add a new user.
5. Select **Automation** as the user type.
6. Provide a user name and fill in **Allowed IPs**. Use `any` for unrestricted
   access, or enter the Sublime Security webhook egress IPs (see below) as a
   comma-separated list of single IPs or netmasks.
7. Choose one or more roles. The default **Automation** role has a broad set
   of permissions suitable for a service account. If you want a narrower
   permission set, create a custom role and assign it here.
8. Click **Create**.

After the user is created, SOAR will surface a configuration block that looks
like:

```json
{
  "ph-auth-token": "cs76HmsNcWjkd6kWmGzUa18LcbtQx95vMW1bsdeP7gU=",
  "server": "https://172.16.210.137"
}
```

| Parameter | Type | Description |
|-----------|------|-------------|
| `ph-auth-token` | String | Generated authorization token. Only valid from the IPs listed in the user's **Allowed IPs** panel. |
| `server` | String/URL | Base URL to POST to this SOAR instance. |

Copy the `ph-auth-token` and add it to the Sublime webhook Action. In the
Sublime dashboard, open your webhook Action, scroll to **Headers**, and add:

| Header | Value |
|--------|-------|
| `ph-auth-token` | *(value from the automation user block above)* |

See Sublime's docs for the UI walkthrough:
<https://docs.sublime.security/docs/webhooks>

### Expected source IPs (Sublime Security webhook egress)

Add these to the automation user's **Allowed IPs** and to any upstream
firewall or reverse proxy. They are also pre-populated in the app's
`webhook.ip_allowlist`. Source:
<https://docs.sublime.security/docs/webhooks#source-ips>.

| Deployment | IPv4 |
|------------|------|
| `platform.sublime.security` (NA-East primary) | 44.194.118.42, 34.197.67.5 |
| `na-east-2.platform.sublime.security` | 3.132.96.216, 3.21.140.176 |
| `na-east-3.platform.sublime.security` | 52.23.100.46, 98.85.180.179 |
| `na-east-4.platform.sublime.security` | 3.12.26.111, 3.139.51.102 |
| `na-west.platform.sublime.security` | 44.235.83.149, 44.244.87.130 |
| `na-west-2.platform.sublime.security` | 35.83.24.249, 44.237.60.158 |
| `eu.platform.sublime.security` | 54.247.166.54, 52.214.238.48 |
| `uk.platform.sublime.security` | 13.42.109.233, 18.135.235.114 |
| `au.platform.sublime.security` | 13.238.69.11, 54.252.178.93 |
| `ca.platform.sublime.security` | 15.157.18.163, 3.97.76.222 |

If the domain receiving your webhook supports IPv6, Sublime documents the
source IPv6 addresses as frequently changing, so the manifest leaves IPv6
wide-open (`::/0`). Self-hosted Sublime deployments will need their own
egress IPs added on the asset's Webhook Settings tab.

### Verifying the `X-Sublime-Signature` header

In addition to `ph-auth-token`, the webhook handler verifies the
`X-Sublime-Signature` header when a signing secret is configured on the asset
(`webhook_signing_secret`). This gives you defense in depth: SOAR
authenticates the caller (`ph-auth-token`) and the app authenticates the
payload (Sublime's HMAC).

Sublime includes the signature in the `X-Sublime-Signature` HTTP header. To
retrieve your webhook Action's signing secret, select the Action from the
Sublime **Actions** page and click **Click to reveal** (or **Copy**).

The header has the form:

```
t=1626139320,v0=3d35d777510a7ccf73ded723f141b0ada2986aebe63c4e45a9c7e4bb1abaca06
```

- `t=` is the Unix timestamp at which Sublime signed the payload.
- `v0=` is an HMAC-SHA256 signature. `v0` is currently the only valid scheme —
  any other versions are ignored to prevent downgrade attacks.

**Replay protection.** Sublime includes the signing timestamp in the signed
payload, so an attacker cannot alter `t=` without invalidating the signature.
If the timestamp is older than `webhook_signature_tolerance_seconds` (default
300), the app rejects the request.

**Signature computation.** The connector reproduces Sublime's signing
algorithm:

1. Split `X-Sublime-Signature` on `,` and then on `=`; keep `t` and every
   `v0`.
2. Build `signed_payload = f"{timestamp}.{raw_request_body}"`.
3. Compute `HMAC_SHA256(signing_secret, signed_payload)`.
4. Compare the computed hex digest to each received `v0` signature using
   `hmac.compare_digest` (constant-time) to prevent timing attacks.

If verification fails, the handler returns HTTP 401 and does not create a
container. The implementation lives in `_verify_sublime_signature` in
[src/app.py](src/app.py).

If `webhook_signing_secret` is left blank, the handler skips this step and
relies solely on SOAR's `ph-auth-token` + IP allowlist.

## Polling

When polling is enabled on the asset (Ingest Settings → Poll), the source is
controlled by the `poll_source` field:

| `poll_source` | Endpoint | What gets ingested |
|---------------|----------|--------------------|
| `message_groups` | `GET /v0/message-groups` | One container per new flagged message group + one `flagged message` artifact, using the same shape as the webhook. State key: `last_mg_created_at`. |
| `audit_logs` | `GET /v0/audit-log/events` | One container per poll cycle named `Sublime Audit Events: <ts>`, with one `audit event` artifact per event. State key: `last_audit_created_at`. No container is emitted on quiet intervals. |

High-water marks are stored per asset in `asset.ingest_state`, so each poll
only picks up records newer than the last run. The two keys are independent —
switching modes doesn't disturb the watermark for the other.

## Actions

### Connectivity
- **test connectivity** — validates the asset configuration by calling `/v0/me`

### BinExplode
- **upload binary** — upload a binary (via Vault ID or base64) to be binexploded
- **get binexplode results** — retrieve results of a binexplode scan by task ID

### Enrichment
- **analyze link** — analyze a URL with `ml.link_analysis`; screenshot is
  saved to Vault automatically

### Audit Log
- **list audit events** — list events with optional time, type, and user filters
- **list audit event types** — enumerate all available audit event types
- **get audit event** — retrieve a single audit event by ID

### Hunt Jobs
- **start hunt job** — start a new hunt job with MQL source and time range
- **get hunt job** — check status of a hunt job
- **get hunt job results** — retrieve the message groups produced by a
  completed hunt

### Lists
- **list lists** — retrieve all organization lists
- **create list** — create a new named string list
- **delete list** — delete a list by ID
- **get list** — get a single list's metadata
- **patch list** — patch a list's description
- **get list entries** — retrieve list entries; optionally save them to the
  Vault as CSV
- **set list entries** — replace entries from either a comma-separated string
  or a CSV vault file
- **delete list entry** — delete a single entry from a list
- **get list entry** — check a single entry or a comma-separated list of
  entries for presence
- **add list entry** — add a single entry to a list

### Raw Message Processing
- **process raw message** — submit a raw EML to Sublime's Live Flow for full
  analysis

### Mailboxes
- **list mailboxes** — list connected mailboxes with filters

### Message Groups (bulk)
- **list message groups** — list message groups with extensive filters
- **dismiss message groups** — dismiss multiple message groups
- **hunt message groups** — hunt message groups (deprecated; prefer start hunt
  job)
- **get hunt results** — get results of a message group hunt (deprecated)
- **quarantine message groups** — quarantine multiple groups
- **graymail message groups** — move groups to graymail
- **restore message groups** — restore multiple groups
- **review message groups** — review groups with classification and action
- **search message groups** — search groups across multiple fields
- **trash message groups** — trash multiple groups

### Message Groups (single)
- **get message group** — get a single canonical message group
- **dismiss message group** — dismiss a single group
- **quarantine message group** — quarantine a single group
- **restore message group** — restore a single group
- **share with sublime** — share a message group with Sublime for community
  detection
- **trash message group** — trash a single group

### Messages
- **analyze raw message** — analyze raw EML against rules and queries
- **render attachment image** — render an attachment image from raw bytes
- **get attack score raw** — evaluate attack score for a raw EML
- **create message** — create a message from a raw EML
- **get action state** — retrieve manual action state for a canonical group
- **get message** — retrieve a message by ID
- **action message** — perform an action (quarantine, trash, restore, etc.)
  on a message
- **analyze message by id** — analyze an existing message against rules and
  queries
- **get asa report** — retrieve the ASA (Attack Surface Assessment) report
- **get attachment image** — retrieve PDF attachment image by MD5 hash
- **get attack score** — evaluate attack score against an existing message
- **get message image** — retrieve a rendered image of a message (saved to
  Vault)
- **get message eml** — retrieve raw EML (saved to Vault)
- **get message image link** — retrieve a temporary link to the message image
- **set access justification** — set access justification for a message
- **get message data model** — retrieve the full Message Data Model (MDM)
- **restore message** — restore a trashed message
- **trash message** — trash a single message

### Rules
- **list rules** — list all rules in the organization
- **create rule** — create a new detection, DLP, or triage rule
- **list rule history** — list history for all rules
- **validate rule** — validate MQL rule syntax without creating
- **delete rule** — delete a rule by ID
- **get rule** — retrieve a single rule
- **update rule** — update an existing rule
- **activate rule** — activate a rule
- **deactivate rule** — deactivate a rule
- **get rule history** — retrieve history of a specific rule

### Tasks
- **get task** — retrieve task status by ID

### User Reports
- **list user reports** — list user-submitted phishing reports

### Users / Roles
- **assign role** — assign a role to a user

### SCIM
- **list scim resource types** / **get scim resource type**
- **list scim users** / **create scim user** / **get scim user** /
  **delete scim user**
- **update scim user** / **patch scim user**
- **validate scim auth**
- **list scim schemas** / **get scim schema**
- **get scim service provider config**

## Building & installing

```bash
cd sublimesecurity
soarapps package build
soarapps package install sublimesecurity-1.0.0.tgz <soar-host>
```

The SDK generates `app.json` from the decorators in
[src/app.py](src/app.py) — don't hand-write it.

## Contributors

- **Evan R. Kinney** — <evanrkinney@gmail.com> — Splunk SOAR Community

## License

Copyright (c) 2026 Splunk SOAR Community.

Licensed under the Apache License, Version 2.0. See
[LICENSE](https://www.apache.org/licenses/LICENSE-2.0) for the full text.
