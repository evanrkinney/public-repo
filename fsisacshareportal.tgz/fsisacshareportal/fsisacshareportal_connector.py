# File: fsisacshareportal_connector.py
#
# Copyright (c) 2026 Splunk SOAR Community
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software distributed under
# the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
# either express or implied. See the License for the specific language governing permissions
# and limitations under the License.

import base64
import hashlib
import hmac
import json
import os
import time

import phantom.app as phantom
import requests
from phantom.action_result import ActionResult
from phantom.base_connector import BaseConnector
from phantom.vault import Vault

from fsisacshareportal_consts import (
    ENDPOINT_ACTIVATE_ORG,
    ENDPOINT_ADD_ALLOWED_INDICATORS,
    ENDPOINT_ALERT_DETAILS_REPORT,
    ENDPOINT_ALERT_EXPORT,
    ENDPOINT_ALERT_FEEDBACK,
    ENDPOINT_ALERT_HISTORY,
    ENDPOINT_ALERT_READ_STATUS,
    ENDPOINT_ALERT_STATS,
    ENDPOINT_ALERTS_BY_CATEGORY_REPORT,
    ENDPOINT_ALERTS_BY_GROUP_REPORT,
    ENDPOINT_ALERTS_BY_INTEL_SOURCE_REPORT,
    ENDPOINT_ALERTS_BY_KEYWORD,
    ENDPOINT_ALERTS_BY_LOCATION_REPORT,
    ENDPOINT_ALERTS_BY_REPORT_SOURCE,
    ENDPOINT_ALERTS_BY_TRACKING_ID,
    ENDPOINT_CHANNEL_STATS,
    ENDPOINT_CREATE_ALERT,
    ENDPOINT_CREATE_FOLDER,
    ENDPOINT_CREATE_LOCATION,
    ENDPOINT_CREATE_MEMBER,
    ENDPOINT_CREATE_ORGANIZATION,
    ENDPOINT_CREATE_RECIPIENT_GROUP,
    ENDPOINT_CREATE_RECOMMENDED_ACTION,
    ENDPOINT_CREATE_RFI,
    ENDPOINT_CREATE_RFI_RESPONSE,
    ENDPOINT_CREATE_TAG,
    ENDPOINT_DOC_DETAILS,
    ENDPOINT_DOCUMENT_DOWNLOADERS,
    ENDPOINT_DOCUMENT_STATS,
    ENDPOINT_FOLDER_DETAILS,
    ENDPOINT_GET_ALERT_DETAIL,
    ENDPOINT_GET_ALERT_TOPICS,
    ENDPOINT_GET_CATEGORY_DETAIL,
    ENDPOINT_GET_INTEL_CATEGORY_DETAIL,
    ENDPOINT_GET_INTEL_DETAIL,
    ENDPOINT_GET_IR_FOLLOWERS,
    ENDPOINT_GET_MEMBER,
    ENDPOINT_GET_MESSAGE_ATTACHMENTS,
    ENDPOINT_GET_ORG_IP_DOMAINS,
    ENDPOINT_GET_ORG_LEVELS,
    ENDPOINT_GET_ORGANIZATION_TYPES,
    ENDPOINT_GET_RECOMMENDED_ACTIONS,
    ENDPOINT_GET_RFI_DETAIL,
    ENDPOINT_GET_RFI_RESPONSES,
    ENDPOINT_GET_TOPIC_MESSAGES,
    ENDPOINT_INTEL_INDICATOR_STATS,
    ENDPOINT_INTEL_SHARING_REPORT,
    ENDPOINT_LIST_ADDITIONAL_FIELDS,
    ENDPOINT_LIST_ALERTS,
    ENDPOINT_LIST_ALERTS_BY_IR,
    ENDPOINT_LIST_ALLOWED_INDICATORS,
    ENDPOINT_LIST_CATEGORIES,
    ENDPOINT_LIST_CHANNELS,
    ENDPOINT_LIST_INFO_SOURCES,
    ENDPOINT_LIST_INTEL,
    ENDPOINT_LIST_INTEL_CATEGORIES,
    ENDPOINT_LIST_IRS,
    ENDPOINT_LIST_MEMBERS,
    ENDPOINT_LIST_ORGANIZATIONS,
    ENDPOINT_LIST_RECIPIENT_GROUPS,
    ENDPOINT_LIST_RFI,
    ENDPOINT_LIST_TAGS,
    ENDPOINT_MEMBER_LOCATIONS,
    ENDPOINT_MEMBER_STATUS,
    ENDPOINT_MEMBER_STATUSES,
    ENDPOINT_MEMBER_STATS,
    ENDPOINT_RELATED_ALERTS,
    ENDPOINT_REPORT_INTEL,
    ENDPOINT_TEST_CONNECTIVITY,
    ENDPOINT_TOP_CHANNEL_TAGS,
    ENDPOINT_UPDATE_ALERT,
    ENDPOINT_UPDATE_MEMBER,
    ENDPOINT_UPDATE_ORG_ANALYST,
    ENDPOINT_UPDATE_ORG_MEMBER,
    ENDPOINT_UPLOAD_DOC,
    ENDPOINT_UPLOAD_RFI_ATTACHMENT,
    ENDPOINT_WIDGET_DATA,
    ENDPOINT_WIDGET_LIBRARY,
    ERR_CONNECTIVITY_TEST,
    ERR_INVALID_JSON_PARAM,
    ERR_REST_CALL,
    ERR_SERVER_CONNECTION,
    ERR_VAULT_FILE_NOT_FOUND,
    ERR_VAULT_INFO,
    ERR_VAULT_SAVE,
    SIGNATURE_EXPIRY_SECONDS,
    SUCC_CONNECTIVITY_TEST,
)


class FSISACSharePortalConnector(BaseConnector):

    def __init__(self):
        super(FSISACSharePortalConnector, self).__init__()
        self._base_url = None
        self._access_id = None
        self._secret_key = None
        self._verify_server_cert = None

    def initialize(self):
        config = self.get_config()
        self._base_url = config["base_url"].rstrip("/")
        self._access_id = config["access_id"]
        self._secret_key = config["secret_key"]
        self._verify_server_cert = config.get("verify_server_cert", True)
        return phantom.APP_SUCCESS

    def finalize(self):
        return phantom.APP_SUCCESS

    # ------------------------------------------------------------------ #
    #                         Helper Methods                              #
    # ------------------------------------------------------------------ #

    def _generate_signature(self, expires):
        """Generate HMAC-SHA1 signature for API authentication."""
        string_to_sign = "{}\n{}".format(self._access_id, expires)
        signature = base64.b64encode(
            hmac.new(
                self._secret_key.encode("utf-8"),
                string_to_sign.encode("utf-8"),
                hashlib.sha1,
            ).digest()
        ).decode("utf-8")
        return signature

    def _get_auth_params(self):
        """Return authentication query parameters dict."""
        expires = int(time.time()) + SIGNATURE_EXPIRY_SECONDS
        signature = self._generate_signature(expires)
        return {
            "AccessID": self._access_id,
            "Expires": str(expires),
            "Signature": signature,
        }

    def _make_rest_call(self, endpoint, action_result, method="get", json_data=None, params=None):
        """Make a JSON REST API call. Returns (ret_val, response_dict)."""
        url = "{}{}".format(self._base_url, endpoint)
        auth_params = self._get_auth_params()
        if params:
            auth_params.update(params)

        try:
            request_func = getattr(requests, method)
            resp = request_func(
                url,
                params=auth_params,
                json=json_data,
                verify=self._verify_server_cert,
                timeout=60,
            )
        except requests.exceptions.ConnectionError:
            return action_result.set_status(phantom.APP_ERROR, ERR_SERVER_CONNECTION), None
        except Exception as e:
            return action_result.set_status(phantom.APP_ERROR, "Error: {}".format(str(e))), None

        if resp.status_code < 200 or resp.status_code >= 400:
            try:
                error_body = resp.json()
                error_msg = error_body.get("message", error_body.get("detail", resp.text))
            except Exception:
                error_msg = resp.text
            return (
                action_result.set_status(
                    phantom.APP_ERROR,
                    ERR_REST_CALL.format(status_code=resp.status_code, error=error_msg),
                ),
                None,
            )

        try:
            response_data = resp.json()
        except Exception:
            response_data = {}

        return phantom.APP_SUCCESS, response_data

    def _make_rest_call_raw(self, endpoint, action_result, params=None):
        """Make a raw REST call for binary downloads. Returns (ret_val, content_bytes, content_type)."""
        url = "{}{}".format(self._base_url, endpoint)
        auth_params = self._get_auth_params()
        if params:
            auth_params.update(params)

        try:
            resp = requests.get(
                url,
                params=auth_params,
                verify=self._verify_server_cert,
                timeout=120,
                stream=True,
            )
        except requests.exceptions.ConnectionError:
            return action_result.set_status(phantom.APP_ERROR, ERR_SERVER_CONNECTION), None, None
        except Exception as e:
            return action_result.set_status(phantom.APP_ERROR, "Error: {}".format(str(e))), None, None

        if resp.status_code < 200 or resp.status_code >= 400:
            return (
                action_result.set_status(
                    phantom.APP_ERROR,
                    ERR_REST_CALL.format(status_code=resp.status_code, error=resp.text[:500]),
                ),
                None,
                None,
            )

        content_type = resp.headers.get("Content-Type", "application/octet-stream")
        return phantom.APP_SUCCESS, resp.content, content_type

    def _make_rest_call_file(self, endpoint, action_result, files, data=None):
        """Make a multipart file upload REST call. Returns (ret_val, response_dict)."""
        url = "{}{}".format(self._base_url, endpoint)
        auth_params = self._get_auth_params()

        try:
            resp = requests.post(
                url,
                params=auth_params,
                files=files,
                data=data,
                verify=self._verify_server_cert,
                timeout=120,
            )
        except requests.exceptions.ConnectionError:
            return action_result.set_status(phantom.APP_ERROR, ERR_SERVER_CONNECTION), None
        except Exception as e:
            return action_result.set_status(phantom.APP_ERROR, "Error: {}".format(str(e))), None

        if resp.status_code < 200 or resp.status_code >= 400:
            try:
                error_body = resp.json()
                error_msg = error_body.get("message", error_body.get("detail", resp.text))
            except Exception:
                error_msg = resp.text
            return (
                action_result.set_status(
                    phantom.APP_ERROR,
                    ERR_REST_CALL.format(status_code=resp.status_code, error=error_msg),
                ),
                None,
            )

        try:
            response_data = resp.json()
        except Exception:
            response_data = {}

        return phantom.APP_SUCCESS, response_data

    def _get_file_from_vault(self, action_result, vault_id):
        """Read a file from the SOAR vault. Returns (ret_val, file_bytes, file_name)."""
        try:
            success, message, vault_info = Vault.get_file_info(vault_id=vault_id, container_id=self.get_container_id())
            if not success:
                return action_result.set_status(phantom.APP_ERROR, ERR_VAULT_INFO.format(error=message)), None, None
        except Exception as e:
            return action_result.set_status(phantom.APP_ERROR, ERR_VAULT_INFO.format(error=str(e))), None, None

        if not vault_info:
            return action_result.set_status(phantom.APP_ERROR, ERR_VAULT_FILE_NOT_FOUND.format(vault_id=vault_id)), None, None

        vault_info = list(vault_info)
        file_path = vault_info[0].get("path")
        file_name = vault_info[0].get("name")

        try:
            with open(file_path, "rb") as f:
                file_bytes = f.read()
        except Exception as e:
            return action_result.set_status(phantom.APP_ERROR, "Error reading vault file: {}".format(str(e))), None, None

        return phantom.APP_SUCCESS, file_bytes, file_name

    def _save_to_vault(self, action_result, data_bytes, file_name):
        """Save binary data to the SOAR vault. Returns (ret_val, vault_id)."""
        try:
            tmp_dir = Vault.get_vault_tmp_dir()
            tmp_file_path = os.path.join(tmp_dir, file_name)
            with open(tmp_file_path, "wb") as f:
                f.write(data_bytes)

            success, message, vault_id = Vault.add_attachment(
                tmp_file_path,
                container_id=self.get_container_id(),
                file_name=file_name,
            )
            if not success:
                return action_result.set_status(phantom.APP_ERROR, ERR_VAULT_SAVE.format(error=message)), None
        except Exception as e:
            return action_result.set_status(phantom.APP_ERROR, ERR_VAULT_SAVE.format(error=str(e))), None

        return phantom.APP_SUCCESS, vault_id

    def _extract_data_list(self, response):
        """Extract a list of items from a possibly-nested API response."""
        if isinstance(response, list):
            return response
        if isinstance(response, dict):
            for key in ["data", "results", "result", "items", "records"]:
                if key in response:
                    val = response[key]
                    if isinstance(val, list):
                        return val
                    if isinstance(val, dict):
                        for inner_key in ["data", "results", "result", "items", "records"]:
                            if inner_key in val and isinstance(val[inner_key], list):
                                return val[inner_key]
                        return [val]
            return [response]
        return []

    def _parse_json_param(self, action_result, param, param_name):
        """Safely parse a JSON string parameter. Returns (ret_val, parsed_value)."""
        if isinstance(param, (dict, list)):
            return phantom.APP_SUCCESS, param
        try:
            parsed = json.loads(param)
            return phantom.APP_SUCCESS, parsed
        except Exception as e:
            return (
                action_result.set_status(
                    phantom.APP_ERROR,
                    ERR_INVALID_JSON_PARAM.format(param=param_name, error=str(e)),
                ),
                None,
            )

    # ------------------------------------------------------------------ #
    #                      1. Test Connectivity                           #
    # ------------------------------------------------------------------ #

    def _handle_test_connectivity(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))
        self.save_progress("Connecting to FS-ISAC Share Portal...")

        ret_val, response = self._make_rest_call(ENDPOINT_TEST_CONNECTIVITY, action_result)
        if phantom.is_fail(ret_val):
            self.save_progress(ERR_CONNECTIVITY_TEST)
            return action_result.get_status()

        self.save_progress(SUCC_CONNECTIVITY_TEST)
        return action_result.set_status(phantom.APP_SUCCESS, SUCC_CONNECTIVITY_TEST)

    # ------------------------------------------------------------------ #
    #                       2-14. Alerts (13)                             #
    # ------------------------------------------------------------------ #

    def _handle_list_alerts(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))
        query_params = {}
        for p in ["page", "page_size"]:
            if param.get(p):
                query_params[p] = str(int(param[p]))
        for p in ["status", "tlp", "title", "category_id", "start_time", "end_time", "channel_ids"]:
            if param.get(p):
                query_params[p] = param[p]

        ret_val, response = self._make_rest_call(ENDPOINT_LIST_ALERTS, action_result, params=query_params)
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        items = self._extract_data_list(response)
        for item in items:
            action_result.add_data(item)
        action_result.update_summary({"total_alerts": len(items)})
        return action_result.set_status(phantom.APP_SUCCESS)

    def _handle_get_alert(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))
        short_id = param["short_id"]
        endpoint = ENDPOINT_GET_ALERT_DETAIL.format(short_id=short_id)

        ret_val, response = self._make_rest_call(endpoint, action_result)
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        data = response.get("data", response)
        if isinstance(data, list):
            for item in data:
                action_result.add_data(item)
        else:
            action_result.add_data(data)
        action_result.update_summary({"short_id": short_id})
        return action_result.set_status(phantom.APP_SUCCESS)

    def _handle_create_alert(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))
        body = {
            "title": param["title"],
            "content": param["content"],
            "status": param["status"],
        }

        # Simple string optional params
        for opt in ["tlp", "card_category_name", "type", "severity", "urgency", "priority",
                     "kill_chain_phase", "threat_actor", "threat_method", "info_source",
                     "confidence", "credibility", "announcement_type", "systemsaffected",
                     "risk", "exploit_likelihood", "exploited_wild", "root_cause",
                     "detectionmethod", "cyber_threat_method", "physical_threat_method",
                     "document_type", "vendorsnproduct", "reportsource", "vulnerability_source",
                     "vulnerability_type", "targeted_sector", "tracking_id", "card_image",
                     "recommendation"]:
            if param.get(opt):
                body[opt] = param[opt]

        # Boolean params
        for bp in ["push_required", "push_email_notification", "display_alert_image"]:
            if param.get(bp) is not None:
                body[bp] = param[bp]

        # JSON string params
        json_fields = ["card_category", "card_group", "tags", "custom_fields",
                       "attachments", "reference_urls", "card_info", "pirs",
                       "linked_alerts", "share_with"]
        for jf in json_fields:
            if param.get(jf):
                ret_val, parsed = self._parse_json_param(action_result, param[jf], jf)
                if phantom.is_fail(ret_val):
                    return action_result.get_status()
                body[jf] = parsed

        # Catch-all additional_fields for any extra properties
        if param.get("additional_fields"):
            ret_val, extra = self._parse_json_param(action_result, param["additional_fields"], "additional_fields")
            if phantom.is_fail(ret_val):
                return action_result.get_status()
            if isinstance(extra, dict):
                body.update(extra)

        ret_val, response = self._make_rest_call(ENDPOINT_CREATE_ALERT, action_result, method="post", json_data=body)
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        data = response.get("data", response)
        action_result.add_data(data)
        action_result.update_summary({"alert_id": data.get("short_id", data.get("id", ""))})
        return action_result.set_status(phantom.APP_SUCCESS, "Alert created successfully")

    def _handle_update_alert(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))
        body = {"short_id": param["short_id"]}

        for opt in ["title", "content", "status", "tlp", "card_info",
                     "card_image", "published_time"]:
            if param.get(opt):
                body[opt] = param[opt]

        # Boolean fields
        for bf in ["push_required", "push_email_notification"]:
            if param.get(bf) is not None:
                body[bf] = param[bf]

        # JSON string fields
        json_fields = [
            "card_category", "card_group", "tags", "severity", "urgency",
            "priority", "kill_chain_phase", "threat_actor", "threat_method",
            "info_source", "confidence", "credibility", "announcement_type",
            "systemsaffected", "risk", "exploit_likelihood", "exploited_wild",
            "root_cause", "detectionmethod", "cyber_threat_method",
            "physical_threat_method", "document_type", "vendorsnproduct",
            "reportsource", "vulnerability_source", "vulnerability_type",
            "attachments", "linked_alerts", "optional_fields",
            "threat_indicators_obj", "additional_fields",
        ]
        for jf in json_fields:
            if param.get(jf):
                ret_val, parsed = self._parse_json_param(action_result, param[jf], jf)
                if phantom.is_fail(ret_val):
                    return action_result.get_status()
                if jf == "additional_fields" and isinstance(parsed, dict):
                    body.update(parsed)
                else:
                    body[jf] = parsed

        ret_val, response = self._make_rest_call(ENDPOINT_UPDATE_ALERT, action_result, method="post", json_data=body)
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        data = response.get("data", response)
        action_result.add_data(data)
        return action_result.set_status(phantom.APP_SUCCESS, "Alert updated successfully")

    def _handle_export_alert_pdf(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))
        alert_id = param["alert_id"]
        endpoint = ENDPOINT_ALERT_EXPORT.format(alert_id=alert_id)

        ret_val, content_bytes, content_type = self._make_rest_call_raw(endpoint, action_result)
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        file_name = "alert_{}.pdf".format(alert_id)
        ret_val, vault_id = self._save_to_vault(action_result, content_bytes, file_name)
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        action_result.add_data({"vault_id": vault_id, "file_name": file_name})
        action_result.update_summary({"vault_id": vault_id})
        return action_result.set_status(phantom.APP_SUCCESS, "Alert PDF exported to vault")

    def _handle_get_alert_history(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))
        short_id = param["short_id"]
        endpoint = ENDPOINT_ALERT_HISTORY.format(short_id=short_id)

        ret_val, response = self._make_rest_call(endpoint, action_result)
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        items = self._extract_data_list(response)
        for item in items:
            action_result.add_data(item)
        action_result.update_summary({"total_history": len(items)})
        return action_result.set_status(phantom.APP_SUCCESS)

    def _handle_search_alerts(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))
        query_params = {}
        if param.get("keyword"):
            query_params["keyword"] = param["keyword"]

        ret_val, response = self._make_rest_call(ENDPOINT_ALERTS_BY_KEYWORD, action_result, params=query_params)
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        items = self._extract_data_list(response)
        for item in items:
            action_result.add_data(item)
        action_result.update_summary({"total_alerts": len(items)})
        return action_result.set_status(phantom.APP_SUCCESS)

    def _handle_find_related_alerts(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))
        body = {
            "indicator_type": param["indicator_type"],
            "indicator_value": param["indicator_value"],
        }
        if param.get("counts"):
            body["counts"] = param["counts"]

        ret_val, response = self._make_rest_call(ENDPOINT_RELATED_ALERTS, action_result, method="post", json_data=body)
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        items = self._extract_data_list(response)
        for item in items:
            action_result.add_data(item)
        action_result.update_summary({"total_related": len(items)})
        return action_result.set_status(phantom.APP_SUCCESS)

    def _handle_get_alerts_by_tracking_id(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))
        query_params = {"tracking_id": param["tracking_id"]}
        if param.get("counts"):
            query_params["counts"] = param["counts"]
        if param.get("status"):
            query_params["status"] = param["status"]

        ret_val, response = self._make_rest_call(ENDPOINT_ALERTS_BY_TRACKING_ID, action_result, params=query_params)
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        items = self._extract_data_list(response)
        for item in items:
            action_result.add_data(item)
        action_result.update_summary({"total_alerts": len(items)})
        return action_result.set_status(phantom.APP_SUCCESS)

    def _handle_alert_feedback(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))
        body = {"alert_id": param["alert_id"]}
        for opt in ["like", "content_rating", "relevancy_rating", "comment"]:
            if param.get(opt) is not None:
                body[opt] = param[opt]

        ret_val, response = self._make_rest_call(ENDPOINT_ALERT_FEEDBACK, action_result, method="post", json_data=body)
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        data = response.get("data", response)
        action_result.add_data(data)
        return action_result.set_status(phantom.APP_SUCCESS, "Feedback submitted successfully")

    def _handle_list_categories(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))
        query_params = {}
        for p in ["page", "page_size"]:
            if param.get(p):
                query_params[p] = str(int(param[p]))
        if param.get("q"):
            query_params["q"] = param["q"]

        ret_val, response = self._make_rest_call(ENDPOINT_LIST_CATEGORIES, action_result, params=query_params)
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        items = self._extract_data_list(response)
        for item in items:
            action_result.add_data(item)
        action_result.update_summary({"total_categories": len(items)})
        return action_result.set_status(phantom.APP_SUCCESS)

    def _handle_get_category_detail(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))
        category_id = param["category_id"]
        endpoint = ENDPOINT_GET_CATEGORY_DETAIL.format(category_id=category_id)

        ret_val, response = self._make_rest_call(endpoint, action_result)
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        data = response.get("data", response)
        action_result.add_data(data)
        return action_result.set_status(phantom.APP_SUCCESS)

    def _handle_list_additional_fields(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))
        query_params = {}
        if param.get("field_id"):
            query_params["field_id"] = param["field_id"]

        ret_val, response = self._make_rest_call(ENDPOINT_LIST_ADDITIONAL_FIELDS, action_result, params=query_params)
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        items = self._extract_data_list(response)
        for item in items:
            action_result.add_data(item)
        action_result.update_summary({"total_fields": len(items)})
        return action_result.set_status(phantom.APP_SUCCESS)

    # ------------------------------------------------------------------ #
    #                15-19. Alert Metadata + Channels (5)                 #
    # ------------------------------------------------------------------ #

    def _handle_list_tags(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))

        ret_val, response = self._make_rest_call(ENDPOINT_LIST_TAGS, action_result)
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        items = self._extract_data_list(response)
        for item in items:
            action_result.add_data(item)
        action_result.update_summary({"total_tags": len(items)})
        return action_result.set_status(phantom.APP_SUCCESS)

    def _handle_create_tag(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))
        body = {"tag_name": param["name"]}

        ret_val, response = self._make_rest_call(ENDPOINT_CREATE_TAG, action_result, method="post", json_data=body)
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        data = response.get("data", response)
        action_result.add_data(data)
        return action_result.set_status(phantom.APP_SUCCESS, "Tag created successfully")

    def _handle_list_info_sources(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))

        ret_val, response = self._make_rest_call(ENDPOINT_LIST_INFO_SOURCES, action_result)
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        items = self._extract_data_list(response)
        for item in items:
            action_result.add_data(item)
        action_result.update_summary({"total_sources": len(items)})
        return action_result.set_status(phantom.APP_SUCCESS)

    def _handle_list_recipient_groups(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))

        query_params = {}
        if param.get("page"):
            query_params["page"] = str(int(param["page"]))
        if param.get("page_size"):
            query_params["page_size"] = str(int(param["page_size"]))
        if param.get("all_data"):
            query_params["all_data"] = param["all_data"]
        if param.get("q"):
            query_params["q"] = param["q"]

        ret_val, response = self._make_rest_call(ENDPOINT_LIST_RECIPIENT_GROUPS, action_result, params=query_params)
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        items = self._extract_data_list(response)
        for item in items:
            action_result.add_data(item)
        action_result.update_summary({"total_groups": len(items)})
        return action_result.set_status(phantom.APP_SUCCESS)

    def _handle_get_member_locations(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))
        query_params = {}
        for p in ["page", "page_size"]:
            if param.get(p):
                query_params[p] = str(int(param[p]))
        if param.get("search"):
            query_params["search"] = param["search"]

        ret_val, response = self._make_rest_call(ENDPOINT_MEMBER_LOCATIONS, action_result, params=query_params)
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        items = self._extract_data_list(response)
        for item in items:
            action_result.add_data(item)
        action_result.update_summary({"total_locations": len(items)})
        return action_result.set_status(phantom.APP_SUCCESS)

    def _handle_list_channels(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))
        query_params = {}
        if param.get("channel_type"):
            query_params["channel_type"] = param["channel_type"]
        if param.get("pagesize"):
            query_params["pagesize"] = str(int(param["pagesize"]))
        if param.get("page"):
            query_params["page"] = str(int(param["page"]))

        ret_val, response = self._make_rest_call(ENDPOINT_LIST_CHANNELS, action_result, params=query_params)
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        items = self._extract_data_list(response)
        for item in items:
            action_result.add_data(item)
        action_result.update_summary({"total_channels": len(items)})
        return action_result.set_status(phantom.APP_SUCCESS)

    # ------------------------------------------------------------------ #
    #                        20-24. Intel (5)                             #
    # ------------------------------------------------------------------ #

    def _handle_report_intel(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))
        body = {
            "title": param["title"],
            "description": param["description"],
            "category": param["category"],
            "tlp": param["tlp"],
        }

        # Simple string optional params
        for opt in ["indicators", "recommendation"]:
            if param.get(opt):
                body[opt] = param[opt]

        # Boolean params
        if param.get("submitted_anonymously") is not None:
            body["submitted_anonymously"] = param["submitted_anonymously"]

        # JSON string params
        json_fields = ["user_group", "organizations", "priority", "optional_fields",
                       "severity", "urgency", "credibility", "announcement_type",
                       "systemsaffected", "threat_actors", "threat_methods",
                       "detectionmethod", "report_sources", "custom_fields"]
        for jf in json_fields:
            if param.get(jf):
                ret_val, parsed = self._parse_json_param(action_result, param[jf], jf)
                if phantom.is_fail(ret_val):
                    return action_result.get_status()
                body[jf] = parsed

        ret_val, response = self._make_rest_call(ENDPOINT_REPORT_INTEL, action_result, method="post", json_data=body)
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        data = response.get("data", response)
        action_result.add_data(data)
        return action_result.set_status(phantom.APP_SUCCESS, "Intel reported successfully")

    def _handle_list_intel(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))
        query_params = {}
        for p in ["page", "page_size"]:
            if param.get(p):
                query_params[p] = str(int(param[p]))

        ret_val, response = self._make_rest_call(ENDPOINT_LIST_INTEL, action_result, params=query_params)
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        items = self._extract_data_list(response)
        for item in items:
            action_result.add_data(item)
        action_result.update_summary({"total_intel": len(items)})
        return action_result.set_status(phantom.APP_SUCCESS)

    def _handle_get_intel(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))
        incident_id = param["incident_id"]
        endpoint = ENDPOINT_GET_INTEL_DETAIL.format(incident_id=incident_id)

        ret_val, response = self._make_rest_call(endpoint, action_result)
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        data = response.get("data", response)
        action_result.add_data(data)
        action_result.update_summary({"incident_id": incident_id})
        return action_result.set_status(phantom.APP_SUCCESS)

    def _handle_list_intel_categories(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))

        ret_val, response = self._make_rest_call(ENDPOINT_LIST_INTEL_CATEGORIES, action_result)
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        items = self._extract_data_list(response)
        for item in items:
            action_result.add_data(item)
        action_result.update_summary({"total_categories": len(items)})
        return action_result.set_status(phantom.APP_SUCCESS)

    def _handle_get_intel_category_detail(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))
        category_id = param["category_id"]
        endpoint = ENDPOINT_GET_INTEL_CATEGORY_DETAIL.format(category_id=category_id)

        ret_val, response = self._make_rest_call(endpoint, action_result)
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        data = response.get("data", response)
        action_result.add_data(data)
        return action_result.set_status(phantom.APP_SUCCESS)

    # ------------------------------------------------------------------ #
    #                   25-31. Member Management (7)                      #
    # ------------------------------------------------------------------ #

    def _handle_list_members(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))
        query_params = {}
        for p in ["page", "page_size"]:
            if param.get(p):
                query_params[p] = str(int(param[p]))
        if param.get("organization_id"):
            query_params["organization_id"] = param["organization_id"]
        if param.get("email"):
            query_params["email"] = param["email"]

        ret_val, response = self._make_rest_call(ENDPOINT_LIST_MEMBERS, action_result, params=query_params)
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        items = self._extract_data_list(response)
        for item in items:
            action_result.add_data(item)
        action_result.update_summary({"total_members": len(items)})
        return action_result.set_status(phantom.APP_SUCCESS)

    def _handle_get_member(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))
        user_id = param["user_id"]
        endpoint = ENDPOINT_GET_MEMBER.format(user_id=user_id)

        ret_val, response = self._make_rest_call(endpoint, action_result)
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        data = response.get("data", response)
        action_result.add_data(data)
        action_result.update_summary({"user_id": user_id})
        return action_result.set_status(phantom.APP_SUCCESS)

    def _handle_create_member(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))
        body = {
            "first_name": param["first_name"],
            "email": param["email"],
        }

        # Optional string fields
        for opt in ["last_name", "country_code", "phone_number"]:
            if param.get(opt):
                body[opt] = param[opt]

        # Boolean fields
        if param.get("send_welcome_email") is not None:
            body["send_welcome_email"] = param["send_welcome_email"]

        # JSON fields
        for jf in ["user_group", "organization", "organization_type", "member_roles",
                    "features", "mailing_address", "member_email_whitelisted_domains"]:
            if param.get(jf):
                ret_val, parsed = self._parse_json_param(action_result, param[jf], jf)
                if phantom.is_fail(ret_val):
                    return action_result.get_status()
                body[jf] = parsed

        ret_val, response = self._make_rest_call(ENDPOINT_CREATE_MEMBER, action_result, method="post", json_data=body)
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        data = response.get("data", response)
        action_result.add_data(data)
        return action_result.set_status(phantom.APP_SUCCESS, "Member created successfully")

    def _handle_update_member(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))
        body = {"id": param["id"]}

        for opt in ["email", "first_name", "last_name"]:
            if param.get(opt):
                body[opt] = param[opt]

        for jf in ["user_group", "organization_detail", "organization_type",
                    "features", "mailing_address"]:
            if param.get(jf):
                ret_val, parsed = self._parse_json_param(action_result, param[jf], jf)
                if phantom.is_fail(ret_val):
                    return action_result.get_status()
                body[jf] = parsed

        ret_val, response = self._make_rest_call(ENDPOINT_UPDATE_MEMBER, action_result, method="put", json_data=body)
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        data = response.get("data", response)
        action_result.add_data(data)
        return action_result.set_status(phantom.APP_SUCCESS, "Member updated successfully")

    def _handle_set_member_status(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))

        ret_val, member_ids = self._parse_json_param(action_result, param["member_ids"], "member_ids")
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        body = {
            "member_ids": member_ids,
            "is_active": param["is_active"],
        }

        ret_val, response = self._make_rest_call(ENDPOINT_MEMBER_STATUS, action_result, method="post", json_data=body)
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        data = response.get("data", response)
        action_result.add_data(data)
        return action_result.set_status(phantom.APP_SUCCESS, "Member status updated successfully")

    def _handle_create_location(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))
        body = {"location_site": param["location_site"]}

        for opt in ["location_city", "location_state", "location_country"]:
            if param.get(opt):
                body[opt] = param[opt]

        if param.get("is_active") is not None:
            body["is_active"] = param["is_active"]

        ret_val, response = self._make_rest_call(ENDPOINT_CREATE_LOCATION, action_result, method="post", json_data=body)
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        data = response.get("data", response)
        action_result.add_data(data)
        return action_result.set_status(phantom.APP_SUCCESS, "Location created successfully")

    def _handle_create_recipient_group(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))
        body = {"group_name": param["group_name"]}

        for opt in ["group_desc", "group_tlp", "group_type"]:
            if param.get(opt):
                body[opt] = param[opt]

        # Boolean fields
        for bf in ["is_active", "allowed_for_intel_submission", "allowed_for_rfi_submission",
                    "request_to_join_group"]:
            if param.get(bf) is not None:
                body[bf] = param[bf]

        # JSON fields
        if param.get("features"):
            ret_val, parsed = self._parse_json_param(action_result, param["features"], "features")
            if phantom.is_fail(ret_val):
                return action_result.get_status()
            body["features"] = parsed

        ret_val, response = self._make_rest_call(ENDPOINT_CREATE_RECIPIENT_GROUP, action_result, method="post", json_data=body)
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        data = response.get("data", response)
        action_result.add_data(data)
        return action_result.set_status(phantom.APP_SUCCESS, "Recipient group created successfully")

    # ------------------------------------------------------------------ #
    #                     32-39. Organizations (8)                        #
    # ------------------------------------------------------------------ #

    def _handle_list_organizations(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))

        ret_val, response = self._make_rest_call(ENDPOINT_LIST_ORGANIZATIONS, action_result)
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        items = self._extract_data_list(response)
        for item in items:
            action_result.add_data(item)
        action_result.update_summary({"total_organizations": len(items)})
        return action_result.set_status(phantom.APP_SUCCESS)

    def _handle_get_organization_types(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))

        ret_val, response = self._make_rest_call(ENDPOINT_GET_ORGANIZATION_TYPES, action_result)
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        items = self._extract_data_list(response)
        for item in items:
            action_result.add_data(item)
        action_result.update_summary({"total_types": len(items)})
        return action_result.set_status(phantom.APP_SUCCESS)

    def _handle_get_org_ip_domains(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))
        organization_id = param["organization_id"]
        endpoint = ENDPOINT_GET_ORG_IP_DOMAINS.format(organization_id=organization_id)
        query_params = {}
        if param.get("type"):
            query_params["type"] = param["type"]

        ret_val, response = self._make_rest_call(endpoint, action_result, params=query_params)
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        items = self._extract_data_list(response)
        for item in items:
            action_result.add_data(item)
        action_result.update_summary({"total_records": len(items)})
        return action_result.set_status(phantom.APP_SUCCESS)

    def _handle_get_organization_levels(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))
        query_params = {}
        for p in ["page", "page_size"]:
            if param.get(p):
                query_params[p] = str(int(param[p]))

        ret_val, response = self._make_rest_call(ENDPOINT_GET_ORG_LEVELS, action_result, params=query_params)
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        items = self._extract_data_list(response)
        for item in items:
            action_result.add_data(item)
        action_result.update_summary({"total_levels": len(items)})
        return action_result.set_status(phantom.APP_SUCCESS)

    def _handle_create_organization(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))
        body = {"organization_name": param["organization_name"]}

        for opt in ["description", "organization_url", "organization_hq"]:
            if param.get(opt):
                body[opt] = param[opt]

        for jf in ["organization_types", "member_email_whitelisted_domains"]:
            if param.get(jf):
                ret_val, parsed = self._parse_json_param(action_result, param[jf], jf)
                if phantom.is_fail(ret_val):
                    return action_result.get_status()
                body[jf] = parsed

        ret_val, response = self._make_rest_call(ENDPOINT_CREATE_ORGANIZATION, action_result, method="post", json_data=body)
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        data = response.get("data", response)
        action_result.add_data(data)
        return action_result.set_status(phantom.APP_SUCCESS, "Organization created successfully")

    def _handle_update_org_analyst(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))
        body = {"org_id": param["org_id"]}

        for opt in ["org_name", "description", "organization_url", "organization_hq"]:
            if param.get(opt):
                body[opt] = param[opt]

        # Boolean/numeric fields
        for opt in ["mobile_access", "webapp_access", "intel_approval_count", "member_admin_count"]:
            if param.get(opt) is not None:
                body[opt] = param[opt]

        for jf in ["organization_types", "organization_level"]:
            if param.get(jf):
                ret_val, parsed = self._parse_json_param(action_result, param[jf], jf)
                if phantom.is_fail(ret_val):
                    return action_result.get_status()
                body[jf] = parsed

        ret_val, response = self._make_rest_call(ENDPOINT_UPDATE_ORG_ANALYST, action_result, method="put", json_data=body)
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        data = response.get("data", response)
        action_result.add_data(data)
        return action_result.set_status(phantom.APP_SUCCESS, "Organization updated successfully")

    def _handle_update_org_member(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))
        body = {}

        for opt in ["description", "organization_hq", "organization_url"]:
            if param.get(opt):
                body[opt] = param[opt]

        ret_val, response = self._make_rest_call(ENDPOINT_UPDATE_ORG_MEMBER, action_result, method="put", json_data=body)
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        data = response.get("data", response)
        action_result.add_data(data)
        return action_result.set_status(phantom.APP_SUCCESS, "Organization updated successfully")

    def _handle_set_org_status(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))

        ret_val, org_ids = self._parse_json_param(action_result, param["org_ids"], "org_ids")
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        body = {
            "org_ids": org_ids,
            "is_active": param["is_active"],
        }

        ret_val, response = self._make_rest_call(ENDPOINT_ACTIVATE_ORG, action_result, method="put", json_data=body)
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        data = response.get("data", response)
        action_result.add_data(data)
        return action_result.set_status(phantom.APP_SUCCESS, "Organization status updated successfully")

    # ------------------------------------------------------------------ #
    #                       40-42. Messenger (3)                          #
    # ------------------------------------------------------------------ #

    def _handle_get_alert_topics(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))
        query_params = {}
        if param.get("alert_id"):
            query_params["alert_id"] = param["alert_id"]
        if param.get("group_id"):
            query_params["group_id"] = param["group_id"]

        ret_val, response = self._make_rest_call(ENDPOINT_GET_ALERT_TOPICS, action_result, params=query_params)
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        items = self._extract_data_list(response)
        for item in items:
            action_result.add_data(item)
        action_result.update_summary({"total_topics": len(items)})
        return action_result.set_status(phantom.APP_SUCCESS)

    def _handle_get_topic_messages(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))
        query_params = {}
        if param.get("topic_id"):
            query_params["topic_id"] = param["topic_id"]
        if param.get("from_time"):
            query_params["from_time"] = param["from_time"]
        if param.get("to_time"):
            query_params["to_time"] = param["to_time"]
        if param.get("limit"):
            query_params["limit"] = str(int(param["limit"]))

        ret_val, response = self._make_rest_call(ENDPOINT_GET_TOPIC_MESSAGES, action_result, params=query_params)
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        items = self._extract_data_list(response)
        for item in items:
            action_result.add_data(item)
        action_result.update_summary({"total_messages": len(items)})
        return action_result.set_status(phantom.APP_SUCCESS)

    def _handle_get_message_attachments(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))
        query_params = {}
        if param.get("seq_id"):
            query_params["seq_id"] = param["seq_id"]
        if param.get("topic_id"):
            query_params["topic_id"] = param["topic_id"]
        if param.get("expiration_time"):
            query_params["expiration_time"] = param["expiration_time"]

        ret_val, response = self._make_rest_call(ENDPOINT_GET_MESSAGE_ATTACHMENTS, action_result, params=query_params)
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        items = self._extract_data_list(response)
        for item in items:
            action_result.add_data(item)
        action_result.update_summary({"total_attachments": len(items)})
        return action_result.set_status(phantom.APP_SUCCESS)

    # ------------------------------------------------------------------ #
    #                          43-49. RFI (7)                             #
    # ------------------------------------------------------------------ #

    def _handle_list_rfi(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))

        ret_val, response = self._make_rest_call(ENDPOINT_LIST_RFI, action_result)
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        items = self._extract_data_list(response)
        for item in items:
            action_result.add_data(item)
        action_result.update_summary({"total_rfis": len(items)})
        return action_result.set_status(phantom.APP_SUCCESS)

    def _handle_get_rfi(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))
        incident_id = param["incident_id"]
        endpoint = ENDPOINT_GET_RFI_DETAIL.format(incident_id=incident_id)

        ret_val, response = self._make_rest_call(endpoint, action_result)
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        data = response.get("data", response)
        action_result.add_data(data)
        action_result.update_summary({"incident_id": incident_id})
        return action_result.set_status(phantom.APP_SUCCESS)

    def _handle_create_rfi(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))
        body = {}
        for opt in ["title", "description", "tlp"]:
            if param.get(opt):
                body[opt] = param[opt]

        for jf in ["user_group", "available_patch"]:
            if param.get(jf):
                ret_val, parsed = self._parse_json_param(action_result, param[jf], jf)
                if phantom.is_fail(ret_val):
                    return action_result.get_status()
                body[jf] = parsed

        ret_val, response = self._make_rest_call(ENDPOINT_CREATE_RFI, action_result, method="post", json_data=body)
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        data = response.get("data", response)
        action_result.add_data(data)
        return action_result.set_status(phantom.APP_SUCCESS, "RFI created successfully")

    def _handle_get_rfi_responses(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))
        incident_id = param["incident_id"]
        endpoint = ENDPOINT_GET_RFI_RESPONSES.format(incident_id=incident_id)

        ret_val, response = self._make_rest_call(endpoint, action_result)
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        items = self._extract_data_list(response)
        for item in items:
            action_result.add_data(item)
        action_result.update_summary({"total_responses": len(items)})
        return action_result.set_status(phantom.APP_SUCCESS)

    def _handle_create_rfi_response(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))
        alert_id = param["alert_id"]
        endpoint = ENDPOINT_CREATE_RFI_RESPONSE.format(alert_id=alert_id)
        body = {"content": param["content"]}

        if param.get("attachments"):
            ret_val, parsed = self._parse_json_param(action_result, param["attachments"], "attachments")
            if phantom.is_fail(ret_val):
                return action_result.get_status()
            body["attachments"] = parsed

        ret_val, response = self._make_rest_call(endpoint, action_result, method="post", json_data=body)
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        data = response.get("data", response)
        action_result.add_data(data)
        return action_result.set_status(phantom.APP_SUCCESS, "RFI response created successfully")

    def _handle_upload_rfi_attachment(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))
        vault_id = param["vault_id"]

        ret_val, file_bytes, file_name = self._get_file_from_vault(action_result, vault_id)
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        files = {"file": (file_name, file_bytes)}
        ret_val, response = self._make_rest_call_file(ENDPOINT_UPLOAD_RFI_ATTACHMENT, action_result, files=files)
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        data = response.get("data", response)
        action_result.add_data(data)
        media_id = data.get("media_id", data.get("id", ""))
        action_result.update_summary({"media_id": media_id})
        return action_result.set_status(phantom.APP_SUCCESS, "RFI attachment uploaded successfully")

    # ------------------------------------------------------------------ #
    #                   50-51. Recommended Actions (2)                    #
    # ------------------------------------------------------------------ #

    def _handle_get_recommended_actions(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))
        query_params = {}
        if param.get("alert_id"):
            query_params["alert_id"] = param["alert_id"]
        if param.get("is_recommended_action") is not None:
            query_params["is_recommended_action"] = str(param["is_recommended_action"]).lower()
        for p in ["page", "page_size"]:
            if param.get(p):
                query_params[p] = str(int(param[p]))

        ret_val, response = self._make_rest_call(ENDPOINT_GET_RECOMMENDED_ACTIONS, action_result, params=query_params)
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        items = self._extract_data_list(response)
        for item in items:
            action_result.add_data(item)
        action_result.update_summary({"total_actions": len(items)})
        return action_result.set_status(phantom.APP_SUCCESS)

    def _handle_create_recommended_action(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))
        body = {}
        for opt in ["alert_id", "title", "description", "due_date", "assigned_to", "recipient_type"]:
            if param.get(opt):
                body[opt] = param[opt]

        if param.get("assigned_groups"):
            ret_val, parsed = self._parse_json_param(action_result, param["assigned_groups"], "assigned_groups")
            if phantom.is_fail(ret_val):
                return action_result.get_status()
            body["assigned_groups"] = parsed

        ret_val, response = self._make_rest_call(ENDPOINT_CREATE_RECOMMENDED_ACTION, action_result, method="post", json_data=body)
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        data = response.get("data", response)
        action_result.add_data(data)
        return action_result.set_status(phantom.APP_SUCCESS, "Recommended action created successfully")

    # ------------------------------------------------------------------ #
    #                           52-54. IR (3)                             #
    # ------------------------------------------------------------------ #

    def _handle_list_irs(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))

        ret_val, response = self._make_rest_call(ENDPOINT_LIST_IRS, action_result)
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        items = self._extract_data_list(response)
        for item in items:
            action_result.add_data(item)
        action_result.update_summary({"total_irs": len(items)})
        return action_result.set_status(phantom.APP_SUCCESS)

    def _handle_get_alerts_by_ir(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))
        query_params = {}
        if param.get("ir_id"):
            query_params["ir_id"] = param["ir_id"]
        for p in ["page", "page_size"]:
            if param.get(p):
                query_params[p] = str(int(param[p]))

        ret_val, response = self._make_rest_call(ENDPOINT_LIST_ALERTS_BY_IR, action_result, params=query_params)
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        items = self._extract_data_list(response)
        for item in items:
            action_result.add_data(item)
        action_result.update_summary({"total_alerts": len(items)})
        return action_result.set_status(phantom.APP_SUCCESS)

    def _handle_get_ir_followers(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))
        ir_id = param["ir_id"]
        endpoint = ENDPOINT_GET_IR_FOLLOWERS.format(ir_id=ir_id)

        ret_val, response = self._make_rest_call(endpoint, action_result)
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        items = self._extract_data_list(response)
        for item in items:
            action_result.add_data(item)
        action_result.update_summary({"total_followers": len(items)})
        return action_result.set_status(phantom.APP_SUCCESS)

    # ------------------------------------------------------------------ #
    #                  55-56. Allowed Indicators (2)                      #
    # ------------------------------------------------------------------ #

    def _handle_list_allowed_indicators(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))
        query_params = {}
        for p in ["page", "page_size"]:
            if param.get(p):
                query_params[p] = str(int(param[p]))
        if param.get("type"):
            query_params["type"] = param["type"]
        if param.get("value"):
            query_params["value"] = param["value"]

        ret_val, response = self._make_rest_call(ENDPOINT_LIST_ALLOWED_INDICATORS, action_result, params=query_params)
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        items = self._extract_data_list(response)
        for item in items:
            action_result.add_data(item)
        action_result.update_summary({"total_indicators": len(items)})
        return action_result.set_status(phantom.APP_SUCCESS)

    def _handle_add_allowed_indicator(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))
        body = {
            "threat_indicators": param["threat_indicators"],
        }

        ret_val, response = self._make_rest_call(ENDPOINT_ADD_ALLOWED_INDICATORS, action_result, method="post", json_data=body)
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        data = response.get("data", response)
        action_result.add_data(data)
        return action_result.set_status(phantom.APP_SUCCESS, "Allowed indicator added successfully")

    # ------------------------------------------------------------------ #
    #                      57-60. Doc Library (4)                         #
    # ------------------------------------------------------------------ #

    def _handle_get_document_details(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))
        query_params = {}
        if param.get("document_id"):
            query_params["document_id"] = param["document_id"]

        ret_val, response = self._make_rest_call(ENDPOINT_DOC_DETAILS, action_result, params=query_params)
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        data = response.get("data", response)
        if isinstance(data, list):
            for item in data:
                action_result.add_data(item)
        else:
            action_result.add_data(data)
        return action_result.set_status(phantom.APP_SUCCESS)

    def _handle_upload_document(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))
        vault_id = param["vault_id"]

        ret_val, file_bytes, file_name = self._get_file_from_vault(action_result, vault_id)
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        # Use explicit file_name if provided
        if param.get("file_name"):
            file_name = param["file_name"]

        files = {"file": (file_name, file_bytes)}
        data = {}
        if param.get("tlp"):
            data["tlp"] = param["tlp"]
        if param.get("parent_folder_id"):
            data["parent_folder_id"] = param["parent_folder_id"]
        if param.get("user_groups"):
            data["user_groups"] = param["user_groups"]
        if param.get("individual_recipients"):
            data["individual_recipients"] = param["individual_recipients"]

        ret_val, response = self._make_rest_call_file(ENDPOINT_UPLOAD_DOC, action_result, files=files, data=data if data else None)
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        resp_data = response.get("data", response)
        action_result.add_data(resp_data)
        action_result.update_summary({"document_id": resp_data.get("id", resp_data.get("document_id", ""))})
        return action_result.set_status(phantom.APP_SUCCESS, "Document uploaded successfully")

    def _handle_get_folder_details(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))
        query_params = {}
        if param.get("folder_id"):
            query_params["folder_id"] = param["folder_id"]
        for p in ["page", "page_size"]:
            if param.get(p):
                query_params[p] = str(int(param[p]))

        ret_val, response = self._make_rest_call(ENDPOINT_FOLDER_DETAILS, action_result, params=query_params)
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        data = response.get("data", response)
        if isinstance(data, list):
            for item in data:
                action_result.add_data(item)
        else:
            action_result.add_data(data)
        return action_result.set_status(phantom.APP_SUCCESS)

    def _handle_create_folder(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))
        body = {"folder_name": param["folder_name"]}

        for opt in ["description", "parent_folder_id"]:
            if param.get(opt):
                body[opt] = param[opt]

        for jf in ["individual_recipients", "recipient_groups"]:
            if param.get(jf):
                ret_val, parsed = self._parse_json_param(action_result, param[jf], jf)
                if phantom.is_fail(ret_val):
                    return action_result.get_status()
                body[jf] = parsed

        ret_val, response = self._make_rest_call(ENDPOINT_CREATE_FOLDER, action_result, method="post", json_data=body)
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        data = response.get("data", response)
        action_result.add_data(data)
        return action_result.set_status(phantom.APP_SUCCESS, "Folder created successfully")

    # ------------------------------------------------------------------ #
    #                  61-76. Reports / Analytics (16)                    #
    # ------------------------------------------------------------------ #

    def _handle_get_alert_readers(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))
        query_params = {}
        if param.get("start"):
            query_params["start"] = str(param["start"])
        if param.get("end"):
            query_params["end"] = str(param["end"])
        for p in ["page", "page_size"]:
            if param.get(p):
                query_params[p] = str(int(param[p]))

        ret_val, response = self._make_rest_call(ENDPOINT_ALERT_READ_STATUS, action_result, params=query_params)
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        items = self._extract_data_list(response)
        for item in items:
            action_result.add_data(item)
        action_result.update_summary({"total_records": len(items)})
        return action_result.set_status(phantom.APP_SUCCESS)

    def _handle_get_alert_stats(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))
        query_params = {}
        for p in ["page", "page_size"]:
            if param.get(p):
                query_params[p] = str(int(param[p]))
        if param.get("email"):
            query_params["email"] = param["email"]

        ret_val, response = self._make_rest_call(ENDPOINT_ALERT_STATS, action_result, params=query_params)
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        items = self._extract_data_list(response)
        for item in items:
            action_result.add_data(item)
        action_result.update_summary({"total_records": len(items)})
        return action_result.set_status(phantom.APP_SUCCESS)

    def _handle_get_alerts_by_category_report(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))
        query_params = {}
        for p in ["start_date", "end_date", "page", "page_size"]:
            if param.get(p):
                query_params[p] = str(param[p])

        ret_val, response = self._make_rest_call(ENDPOINT_ALERTS_BY_CATEGORY_REPORT, action_result, params=query_params)
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        items = self._extract_data_list(response)
        for item in items:
            action_result.add_data(item)
        action_result.update_summary({"total_records": len(items)})
        return action_result.set_status(phantom.APP_SUCCESS)

    def _handle_get_alerts_by_intel_source_report(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))
        query_params = {}
        for p in ["start_date", "end_date", "page", "page_size"]:
            if param.get(p):
                query_params[p] = str(param[p])

        ret_val, response = self._make_rest_call(ENDPOINT_ALERTS_BY_INTEL_SOURCE_REPORT, action_result, params=query_params)
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        items = self._extract_data_list(response)
        for item in items:
            action_result.add_data(item)
        action_result.update_summary({"total_records": len(items)})
        return action_result.set_status(phantom.APP_SUCCESS)

    def _handle_get_alerts_by_group_report(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))
        query_params = {}
        for p in ["start_date", "end_date", "page", "page_size"]:
            if param.get(p):
                query_params[p] = str(param[p])

        ret_val, response = self._make_rest_call(ENDPOINT_ALERTS_BY_GROUP_REPORT, action_result, params=query_params)
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        items = self._extract_data_list(response)
        for item in items:
            action_result.add_data(item)
        action_result.update_summary({"total_records": len(items)})
        return action_result.set_status(phantom.APP_SUCCESS)

    def _handle_get_alert_details_report(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))
        query_params = {}
        if param.get("start"):
            query_params["start"] = str(param["start"])
        if param.get("end"):
            query_params["end"] = str(param["end"])
        for p in ["page", "page_size"]:
            if param.get(p):
                query_params[p] = str(int(param[p]))
        if param.get("sortby"):
            query_params["sortby"] = param["sortby"]
        if param.get("searchCards"):
            query_params["searchCards"] = param["searchCards"]

        ret_val, response = self._make_rest_call(ENDPOINT_ALERT_DETAILS_REPORT, action_result, params=query_params)
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        items = self._extract_data_list(response)
        for item in items:
            action_result.add_data(item)
        action_result.update_summary({"total_records": len(items)})
        return action_result.set_status(phantom.APP_SUCCESS)

    def _handle_get_alerts_by_location_report(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))
        query_params = {}
        for p in ["start_date", "end_date", "page", "page_size"]:
            if param.get(p):
                query_params[p] = str(param[p])

        ret_val, response = self._make_rest_call(ENDPOINT_ALERTS_BY_LOCATION_REPORT, action_result, params=query_params)
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        items = self._extract_data_list(response)
        for item in items:
            action_result.add_data(item)
        action_result.update_summary({"total_records": len(items)})
        return action_result.set_status(phantom.APP_SUCCESS)

    def _handle_get_alerts_by_report_source(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))
        query_params = {}
        for p in ["type", "q"]:
            if param.get(p):
                query_params[p] = param[p]
        for p in ["page", "page_size"]:
            if param.get(p):
                query_params[p] = str(int(param[p]))

        ret_val, response = self._make_rest_call(ENDPOINT_ALERTS_BY_REPORT_SOURCE, action_result, params=query_params)
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        items = self._extract_data_list(response)
        for item in items:
            action_result.add_data(item)
        action_result.update_summary({"total_records": len(items)})
        return action_result.set_status(phantom.APP_SUCCESS)

    def _handle_get_intel_indicator_stats(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))
        query_params = {}
        for p in ["start_date", "end_date", "page", "page_size"]:
            if param.get(p):
                query_params[p] = str(param[p])

        ret_val, response = self._make_rest_call(ENDPOINT_INTEL_INDICATOR_STATS, action_result, params=query_params)
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        items = self._extract_data_list(response)
        for item in items:
            action_result.add_data(item)
        action_result.update_summary({"total_records": len(items)})
        return action_result.set_status(phantom.APP_SUCCESS)

    def _handle_get_intel_sharing_report(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))
        query_params = {}
        for p in ["page", "page_size"]:
            if param.get(p):
                query_params[p] = str(int(param[p]))
        if param.get("start"):
            query_params["start"] = param["start"]
        if param.get("end"):
            query_params["end"] = param["end"]

        ret_val, response = self._make_rest_call(ENDPOINT_INTEL_SHARING_REPORT, action_result, params=query_params)
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        items = self._extract_data_list(response)
        for item in items:
            action_result.add_data(item)
        action_result.update_summary({"total_records": len(items)})
        return action_result.set_status(phantom.APP_SUCCESS)

    def _handle_get_channel_stats(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))
        query_params = {}
        for p in ["start_date", "end_date", "page", "page_size"]:
            if param.get(p):
                query_params[p] = str(param[p])

        ret_val, response = self._make_rest_call(ENDPOINT_CHANNEL_STATS, action_result, params=query_params)
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        items = self._extract_data_list(response)
        for item in items:
            action_result.add_data(item)
        action_result.update_summary({"total_records": len(items)})
        return action_result.set_status(phantom.APP_SUCCESS)

    def _handle_get_top_channel_tags(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))
        query_params = {}
        for p in ["start_date", "end_date", "page", "page_size"]:
            if param.get(p):
                query_params[p] = str(param[p])

        ret_val, response = self._make_rest_call(ENDPOINT_TOP_CHANNEL_TAGS, action_result, params=query_params)
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        items = self._extract_data_list(response)
        for item in items:
            action_result.add_data(item)
        action_result.update_summary({"total_records": len(items)})
        return action_result.set_status(phantom.APP_SUCCESS)

    def _handle_get_document_stats(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))
        query_params = {}
        if param.get("n"):
            query_params["n"] = str(int(param["n"]))
        for p in ["start_date", "end_date"]:
            if param.get(p):
                query_params[p] = str(param[p])

        ret_val, response = self._make_rest_call(ENDPOINT_DOCUMENT_STATS, action_result, params=query_params)
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        items = self._extract_data_list(response)
        for item in items:
            action_result.add_data(item)
        action_result.update_summary({"total_records": len(items)})
        return action_result.set_status(phantom.APP_SUCCESS)

    def _handle_get_document_downloaders(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))
        document_id = param["document_id"]
        endpoint = ENDPOINT_DOCUMENT_DOWNLOADERS.format(document_id=document_id)
        query_params = {}
        for p in ["start_date", "end_date", "page", "page_size"]:
            if param.get(p):
                query_params[p] = str(param[p])

        ret_val, response = self._make_rest_call(endpoint, action_result, params=query_params)
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        items = self._extract_data_list(response)
        for item in items:
            action_result.add_data(item)
        action_result.update_summary({"total_records": len(items)})
        return action_result.set_status(phantom.APP_SUCCESS)

    def _handle_get_member_statuses(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))
        query_params = {}
        for p in ["start_date", "end_date", "page", "page_size"]:
            if param.get(p):
                query_params[p] = str(param[p])

        ret_val, response = self._make_rest_call(ENDPOINT_MEMBER_STATUSES, action_result, params=query_params)
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        items = self._extract_data_list(response)
        for item in items:
            action_result.add_data(item)
        action_result.update_summary({"total_records": len(items)})
        return action_result.set_status(phantom.APP_SUCCESS)

    def _handle_get_member_stats(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))
        query_params = {}
        if param.get("stats_type"):
            query_params["stats_type"] = param["stats_type"]
        if param.get("alert_id"):
            query_params["alert_id"] = param["alert_id"]
        for p in ["start_date", "end_date", "page", "page_size"]:
            if param.get(p):
                query_params[p] = str(param[p])

        ret_val, response = self._make_rest_call(ENDPOINT_MEMBER_STATS, action_result, params=query_params)
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        items = self._extract_data_list(response)
        for item in items:
            action_result.add_data(item)
        action_result.update_summary({"total_records": len(items)})
        return action_result.set_status(phantom.APP_SUCCESS)

    # ------------------------------------------------------------------ #
    #                       77-78. Dashboard (2)                          #
    # ------------------------------------------------------------------ #

    def _handle_list_widgets(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))
        query_params = {}
        if param.get("is_active") is not None:
            query_params["is_active"] = str(param["is_active"]).lower()
        if param.get("widget_origin"):
            query_params["widget_origin"] = param["widget_origin"]
        for p in ["page", "page_size"]:
            if param.get(p):
                query_params[p] = str(int(param[p]))
        if param.get("q"):
            query_params["q"] = param["q"]

        ret_val, response = self._make_rest_call(ENDPOINT_WIDGET_LIBRARY, action_result, params=query_params)
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        items = self._extract_data_list(response)
        for item in items:
            action_result.add_data(item)
        action_result.update_summary({"total_widgets": len(items)})
        return action_result.set_status(phantom.APP_SUCCESS)

    def _handle_get_widget_data(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))
        query_params = {}
        if param.get("widget_id"):
            query_params["widget_id"] = param["widget_id"]

        ret_val, response = self._make_rest_call(ENDPOINT_WIDGET_DATA, action_result, params=query_params)
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        data = response.get("data", response)
        if isinstance(data, list):
            for item in data:
                action_result.add_data(item)
        else:
            action_result.add_data(data)
        return action_result.set_status(phantom.APP_SUCCESS)

    # ------------------------------------------------------------------ #
    #                        Action Dispatcher                            #
    # ------------------------------------------------------------------ #

    def handle_action(self, param):
        action_id = self.get_action_identifier()
        self.debug_print("action_id", self.get_action_identifier())

        action_mapping = {
            # Test Connectivity (1)
            "test_connectivity": self._handle_test_connectivity,
            # Alerts (13)
            "list_alerts": self._handle_list_alerts,
            "get_alert": self._handle_get_alert,
            "create_alert": self._handle_create_alert,
            "update_alert": self._handle_update_alert,
            "export_alert_pdf": self._handle_export_alert_pdf,
            "get_alert_history": self._handle_get_alert_history,
            "search_alerts": self._handle_search_alerts,
            "find_related_alerts": self._handle_find_related_alerts,
            "get_alerts_by_tracking_id": self._handle_get_alerts_by_tracking_id,
            "alert_feedback": self._handle_alert_feedback,
            "list_categories": self._handle_list_categories,
            "get_category_detail": self._handle_get_category_detail,
            "list_additional_fields": self._handle_list_additional_fields,
            # Alert Metadata + Channels (5)
            "list_tags": self._handle_list_tags,
            "create_tag": self._handle_create_tag,
            "list_info_sources": self._handle_list_info_sources,
            "list_recipient_groups": self._handle_list_recipient_groups,
            "get_member_locations": self._handle_get_member_locations,
            "list_channels": self._handle_list_channels,
            # Intel (5)
            "report_intel": self._handle_report_intel,
            "list_intel": self._handle_list_intel,
            "get_intel": self._handle_get_intel,
            "list_intel_categories": self._handle_list_intel_categories,
            "get_intel_category_detail": self._handle_get_intel_category_detail,
            # Member Management (7)
            "list_members": self._handle_list_members,
            "get_member": self._handle_get_member,
            "create_member": self._handle_create_member,
            "update_member": self._handle_update_member,
            "set_member_status": self._handle_set_member_status,
            "create_location": self._handle_create_location,
            "create_recipient_group": self._handle_create_recipient_group,
            # Organizations (8)
            "list_organizations": self._handle_list_organizations,
            "get_organization_types": self._handle_get_organization_types,
            "get_org_ip_domains": self._handle_get_org_ip_domains,
            "get_organization_levels": self._handle_get_organization_levels,
            "create_organization": self._handle_create_organization,
            "update_org_analyst": self._handle_update_org_analyst,
            "update_org_member": self._handle_update_org_member,
            "set_org_status": self._handle_set_org_status,
            # Messenger (3)
            "get_alert_topics": self._handle_get_alert_topics,
            "get_topic_messages": self._handle_get_topic_messages,
            "get_message_attachments": self._handle_get_message_attachments,
            # RFI (7)
            "list_rfi": self._handle_list_rfi,
            "get_rfi": self._handle_get_rfi,
            "create_rfi": self._handle_create_rfi,
            "get_rfi_responses": self._handle_get_rfi_responses,
            "create_rfi_response": self._handle_create_rfi_response,
            "upload_rfi_attachment": self._handle_upload_rfi_attachment,
            # Recommended Actions (2)
            "get_recommended_actions": self._handle_get_recommended_actions,
            "create_recommended_action": self._handle_create_recommended_action,
            # IR (3)
            "list_irs": self._handle_list_irs,
            "get_alerts_by_ir": self._handle_get_alerts_by_ir,
            "get_ir_followers": self._handle_get_ir_followers,
            # Allowed Indicators (2)
            "list_allowed_indicators": self._handle_list_allowed_indicators,
            "add_allowed_indicator": self._handle_add_allowed_indicator,
            # Doc Library (4)
            "get_document_details": self._handle_get_document_details,
            "upload_document": self._handle_upload_document,
            "get_folder_details": self._handle_get_folder_details,
            "create_folder": self._handle_create_folder,
            # Reports / Analytics (16)
            "get_alert_readers": self._handle_get_alert_readers,
            "get_alert_stats": self._handle_get_alert_stats,
            "get_alerts_by_category_report": self._handle_get_alerts_by_category_report,
            "get_alerts_by_intel_source_report": self._handle_get_alerts_by_intel_source_report,
            "get_alerts_by_group_report": self._handle_get_alerts_by_group_report,
            "get_alert_details_report": self._handle_get_alert_details_report,
            "get_alerts_by_location_report": self._handle_get_alerts_by_location_report,
            "get_alerts_by_report_source": self._handle_get_alerts_by_report_source,
            "get_intel_indicator_stats": self._handle_get_intel_indicator_stats,
            "get_intel_sharing_report": self._handle_get_intel_sharing_report,
            "get_channel_stats": self._handle_get_channel_stats,
            "get_top_channel_tags": self._handle_get_top_channel_tags,
            "get_document_stats": self._handle_get_document_stats,
            "get_document_downloaders": self._handle_get_document_downloaders,
            "get_member_statuses": self._handle_get_member_statuses,
            "get_member_stats": self._handle_get_member_stats,
            # Dashboard (2)
            "list_widgets": self._handle_list_widgets,
            "get_widget_data": self._handle_get_widget_data,
        }

        handler = action_mapping.get(action_id)
        if handler:
            return handler(param)

        return phantom.APP_ERROR


def main():
    import argparse
    import sys

    argparser = argparse.ArgumentParser()
    argparser.add_argument("input_test_json", help="Input Test JSON file")
    argparser.add_argument("-u", "--username", help="username", required=False)
    argparser.add_argument("-p", "--password", help="password", required=False)
    argparser.add_argument("-v", "--verify", action="store_true", help="verify", required=False, default=False)

    args = argparser.parse_args()
    session_id = None

    with open(args.input_test_json) as f:
        in_json = f.read()
        in_json = json.loads(in_json)
        print(json.dumps(in_json, indent=4))

        connector = FSISACSharePortalConnector()
        connector.print_progress_message = True

        if session_id is not None:
            in_json["user_session_token"] = session_id
            connector._set_csrf_info(in_json["user_session_token"], in_json["user_session_token"])

        ret_val = connector._handle_action(json.dumps(in_json), None)
        print(json.dumps(json.loads(ret_val), indent=4))

    sys.exit(0)


if __name__ == "__main__":
    main()
