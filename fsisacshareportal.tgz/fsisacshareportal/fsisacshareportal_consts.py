# File: fsisacshareportal_consts.py
#
# Copyright (c) 2026 Splunk SOAR Community
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software distributed under
# the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
# either express or implied. See the License for the specific language governing permissions
# and limitations under the License.

# ---- Authentication ----
ENDPOINT_TEST_CONNECTIVITY = "/v1/test_connectivity/"

# ---- Alerts ----
ENDPOINT_LIST_ALERTS = "/v1/list_alert/"
ENDPOINT_GET_ALERT_DETAIL = "/v1/get_alert_detail/{short_id}"
ENDPOINT_CREATE_ALERT = "/v1/create_card/"
ENDPOINT_UPDATE_ALERT = "/v1/alert_update/"
ENDPOINT_ALERT_EXPORT = "/v1/alert-pdf/{alert_id}/"
ENDPOINT_ALERT_HISTORY = "/v1/get_alert_history/{short_id}/"
ENDPOINT_ALERTS_BY_KEYWORD = "/v1/get_news/"
ENDPOINT_RELATED_ALERTS = "/v1/get_related_alerts/"
ENDPOINT_ALERTS_BY_TRACKING_ID = "/v1/get_tracking_id_details/"
ENDPOINT_ALERT_FEEDBACK = "/v1/alert_feedback/"

# ---- Alert Metadata ----
ENDPOINT_LIST_CATEGORIES = "/v1/list_category/"
ENDPOINT_GET_CATEGORY_DETAIL = "/v1/list_category/{category_id}/"
ENDPOINT_LIST_ADDITIONAL_FIELDS = "/v1/list_additional_fields/"
ENDPOINT_LIST_TAGS = "/v1/tag/"
ENDPOINT_CREATE_TAG = "/v1/tag/"
ENDPOINT_LIST_RECIPIENT_GROUPS = "/v1/list_recipient_group/"
ENDPOINT_LIST_INFO_SOURCES = "/v1/list_info_source/"
ENDPOINT_MEMBER_LOCATIONS = "/v1/get_location_list/"

# ---- Channels ----
ENDPOINT_LIST_CHANNELS = "/csap/v1/channels/"

# ---- Intel ----
ENDPOINT_REPORT_INTEL = "/v1/report_intel/"
ENDPOINT_LIST_INTEL = "/v1/list_intel_reported/"
ENDPOINT_GET_INTEL_DETAIL = "/v1/get_intel_detail/{incident_id}"
ENDPOINT_LIST_INTEL_CATEGORIES = "/v1/list_intel_category/"
ENDPOINT_GET_INTEL_CATEGORY_DETAIL = "/v1/reports/form_details/{category_id}/"

# ---- Messenger ----
ENDPOINT_GET_ALERT_TOPICS = "/v1/get_alert_topics/"
ENDPOINT_GET_TOPIC_MESSAGES = "/v1/get_topic_messages/"
ENDPOINT_GET_MESSAGE_ATTACHMENTS = "/v1/get_messages_attachments/"

# ---- Request for Information (RFI) ----
ENDPOINT_LIST_RFI = "/v1/rfi/"
ENDPOINT_CREATE_RFI = "/v1/rfi/"
ENDPOINT_GET_RFI_DETAIL = "/v1/rfi/{incident_id}/"
ENDPOINT_GET_RFI_RESPONSES = "/v1/rfi_responses/{incident_id}/"
ENDPOINT_CREATE_RFI_RESPONSE = "/v1/create/rfi_responses/{alert_id}/"
ENDPOINT_UPLOAD_RFI_ATTACHMENT = "/v1/upload_attachment/rfi_responses/"

# ---- Recommended Actions ----
ENDPOINT_GET_RECOMMENDED_ACTIONS = "/v1/recommended_action/"
ENDPOINT_CREATE_RECOMMENDED_ACTION = "/v1/recommended_action/"

# ---- Intelligence Requirements (IRs) ----
ENDPOINT_LIST_IRS = "/v1/irs/"
ENDPOINT_LIST_ALERTS_BY_IR = "/v1/ir-alerts/"
ENDPOINT_GET_IR_FOLLOWERS = "/v1/ir_followers/{ir_id}/"

# ---- Organizations ----
ENDPOINT_LIST_ORGANIZATIONS = "/v1/get_organization_list/"
ENDPOINT_GET_ORGANIZATION_TYPES = "/v1/get_organization_type/"
ENDPOINT_GET_ORG_IP_DOMAINS = "/v1/organization/{organization_id}/ip_domains/"
ENDPOINT_GET_ORG_LEVELS = "/v1/organization_levels/"
ENDPOINT_CREATE_ORGANIZATION = "/v1/create_organization/"
ENDPOINT_UPDATE_ORG_ANALYST = "/v1/organization_details_update/"
ENDPOINT_UPDATE_ORG_MEMBER = "/v1/organization_update/"
ENDPOINT_ACTIVATE_ORG = "/v1/organization_activation/"

# ---- Member Management ----
ENDPOINT_LIST_MEMBERS = "/v1/member/"
ENDPOINT_GET_MEMBER = "/v1/member/{user_id}/"
ENDPOINT_CREATE_MEMBER = "/v1/create_end_user/"
ENDPOINT_UPDATE_MEMBER = "/v1/update_member/"
ENDPOINT_MEMBER_STATUS = "/csap/v1/end-users-status/"
ENDPOINT_CREATE_LOCATION = "/v1/locations/"
ENDPOINT_CREATE_RECIPIENT_GROUP = "/csap/v1/recipient-group/"

# ---- Allowed Indicators ----
ENDPOINT_LIST_ALLOWED_INDICATORS = "/v1/allowed_indicators/"
ENDPOINT_ADD_ALLOWED_INDICATORS = "/v1/allowed_indicators/"

# ---- Doc Library ----
ENDPOINT_DOC_DETAILS = "/v1/upload_media/"
ENDPOINT_UPLOAD_DOC = "/v1/upload_media/"
ENDPOINT_FOLDER_DETAILS = "/v1/folder-details/"
ENDPOINT_CREATE_FOLDER = "/v1/folder-details/"

# ---- Reports / Analytics ----
ENDPOINT_ALERT_READ_STATUS = "/v1/alert_read_status/"
ENDPOINT_ALERT_STATS = "/v1/alert_stats/"
ENDPOINT_ALERTS_BY_CATEGORY_REPORT = "/v1/card_published_per_category_card_category/"
ENDPOINT_ALERTS_BY_INTEL_SOURCE_REPORT = "/v1/card_published_per_category_intel_source/"
ENDPOINT_ALERTS_BY_GROUP_REPORT = "/v1/card_published_per_category_user_group/"
ENDPOINT_ALERT_DETAILS_REPORT = "/v1/card_reader_detail_list/"
ENDPOINT_ALERTS_BY_LOCATION_REPORT = "/v1/published_card_locations/"
ENDPOINT_ALERTS_BY_REPORT_SOURCE = "/v1/reports/"
ENDPOINT_INTEL_INDICATOR_STATS = "/v1/indicator_related_stats/"
ENDPOINT_INTEL_SHARING_REPORT = "/v1/intel_sharing_report/"
ENDPOINT_CHANNEL_STATS = "/v1/channel_stats/"
ENDPOINT_TOP_CHANNEL_TAGS = "/v1/channel_stats/tags/"
ENDPOINT_DOCUMENT_STATS = "/v1/document_stats/"
ENDPOINT_DOCUMENT_DOWNLOADERS = "/v1/document_stats/{document_id}/"
ENDPOINT_MEMBER_STATUSES = "/v1/tenant_user_status/"
ENDPOINT_MEMBER_STATS = "/v1/user_stats/"

# ---- Dashboard ----
ENDPOINT_WIDGET_LIBRARY = "/v1/widget_library/"
ENDPOINT_WIDGET_DATA = "/csap/v1/widget_library/data/"

# Signature expiration margin (seconds)
SIGNATURE_EXPIRY_SECONDS = 300

# Pagination defaults
DEFAULT_PAGE_SIZE = 10
MAX_PAGE_SIZE = 100

# TLP values
TLP_VALUES = ["RED", "AMBER", "GREEN", "WHITE"]

# Success messages
SUCC_CONNECTIVITY_TEST = "Test Connectivity Passed"

# Error messages
ERR_CONNECTIVITY_TEST = "Test Connectivity Failed"
ERR_SERVER_CONNECTION = "Connection to FS-ISAC Share Portal API failed"
ERR_REST_CALL = "Error from server. Status Code: {status_code}. Error: {error}"
ERR_INVALID_JSON_PARAM = "Invalid JSON in parameter '{param}': {error}"
ERR_VAULT_INFO = "Could not retrieve vault file info: {error}"
ERR_VAULT_FILE_NOT_FOUND = "No vault file found for vault ID: {vault_id}"
ERR_VAULT_SAVE = "Could not save file to vault: {error}"
