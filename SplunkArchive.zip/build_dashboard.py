#!/usr/bin/env python3
"""Assemble the GSFC ES8 SOC dashboard JSON for Splunk Dashboard Studio.

1920x1080 absolute-layout dashboard tuned for a TV (16:9) with a single
shared base search and chained transforms. The logo is intentionally NOT
embedded — a placeholder marks the spot. After importing, click the
placeholder area in the Studio editor, add an Image visualization, and
upload PNC Power Link.svg via the editor's image picker.
"""
from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
OUT_PATH = ROOT / "gsfc_es8_overhead_dashboard.json"


# --- Single base search (everything else chains off of this) -----------------
# Pulls every ES8 Finding touched in the last 7 days, normalizes status,
# severity, owner, and rule name, and tags rows that landed/closed in the
# rolling 8h window. Downstream chains filter and aggregate.
BASE_SEARCH = r"""
| from datamodel:"Findings.All_Findings"
| eval _status = lower(coalesce('All_Findings.status_label', 'All_Findings.status', status_label, status))
| eval severity = lower(coalesce('All_Findings.severity', severity, urgency, "informational"))
| eval owner    = coalesce('All_Findings.owner', owner, "unassigned")
| eval rule     = coalesce('All_Findings.search_name', search_name, source, "unknown")
| eval mod_time = coalesce('All_Findings.mod_time', mod_time, _time)
| eval status_group = case(
        match(_status, "(new|open|unassigned|in.?progress|pending|assigned|investigat)"), "open",
        match(_status, "(closed|resolved|benign|true.?positive|false.?positive)"),         "closed",
        true(), "other")
| eval is_open_now      = if(status_group="open", 1, 0)
| eval is_closed_recent = if(status_group="closed" AND mod_time >= relative_time(now(),"-8h"), 1, 0)
| eval is_fired_recent  = if(_time >= relative_time(now(),"-8h"), 1, 0)
| eval sev_rank = case(severity="critical",1, severity="high",2, severity="medium",3, severity="low",4, true(),5)
"""

# --- Chained queries ---------------------------------------------------------
CHAIN_OPEN_BY_SEV = r"""
| search is_open_now=1
| stats count by severity
| eval severity = case(severity="critical","Critical",
                       severity="high","High",
                       severity="medium","Medium",
                       severity="low","Low",
                       true(),"Informational")
"""

# A separate chain per severity tile so the SingleValue blocks read cleanly.
def chain_open_only(sev: str) -> str:
    return f'| search is_open_now=1 severity="{sev}" | stats count'

CHAIN_CLOSED_8H = r"| search is_closed_recent=1 | stats count"

CHAIN_CLOSED_8H_SPARK = r"""
| search status_group=closed mod_time>=relative_time(now(),"-8h")
| eval bucket = relative_time(mod_time, "@30m")
| stats count by bucket
| sort 0 bucket
"""

CHAIN_TOP_OWNER = r"""
| search is_closed_recent=1
| stats count by owner
| sort - count
| head 1
| eval label=owner, value=count
| fields label value
"""

CHAIN_TOP_OWNER_TABLE = r"""
| search is_closed_recent=1 owner!="unassigned"
| stats count as "Closed" by owner
| sort - Closed
| head 5
| rename owner as "Owner"
"""

CHAIN_TOP_ALERT = r"""
| search is_fired_recent=1
| stats count by rule
| sort - count
| head 1
| eval label=rule, value=count
| fields label value
"""

CHAIN_TOP_ALERTS_TABLE = r"""
| search is_fired_recent=1
| stats count as "Fired" by rule severity
| sort - Fired
| head 6
| eval Severity = case(severity="critical","Critical",
                       severity="high","High",
                       severity="medium","Medium",
                       severity="low","Low",
                       true(),"Informational")
| rename rule as "Rule"
| fields Rule Severity Fired
"""

CHAIN_TIMELINE = r"""
| bucket _time span=15m
| eval Severity = case(severity="critical","Critical",
                       severity="high","High",
                       severity="medium","Medium",
                       severity="low","Low",
                       true(),"Informational")
| chart count over _time by Severity
| eval Critical      = if(isnull('Critical'),0,'Critical'),
       High          = if(isnull('High'),0,'High'),
       Medium        = if(isnull('Medium'),0,'Medium'),
       Low           = if(isnull('Low'),0,'Low'),
       Informational = if(isnull('Informational'),0,'Informational')
| fields _time Critical High Medium Low Informational
| fillnull value=0
"""

# --- Theme colors ------------------------------------------------------------
BG          = "#0B0C0F"
PANEL_BG    = "#15171C"
PANEL_LINE  = "#1F2229"
TEXT_PRIM   = "#E6E8EE"
TEXT_DIM    = "#8A93A6"
ACCENT      = "#FF3E55"  # PNC red accent
SPLUNK_PINK = "#F26196"

SEV = {
    "Critical":      {"hex": "#FF3E55", "icon": "critical"},
    "High":          {"hex": "#FF8E1A", "icon": "high"},
    "Medium":        {"hex": "#FFD024", "icon": "medium"},
    "Low":           {"hex": "#1AC8FF", "icon": "low"},
    "Informational": {"hex": "#9FA8BD", "icon": "info"},
}


def sv_block(value_color: str, unit: str = "open") -> dict:
    """Reusable single-value block options for severity tiles."""
    return {
        "majorColor": value_color,
        "majorFontSize": 96,
        "unit": unit,
        "unitPosition": "after",
        "unitColor": TEXT_DIM,
        "backgroundColor": PANEL_BG,
        "sparklineDisplay": "off",
        "trendDisplay": "off",
        "showValue": "show",
    }


def severity_viz(name: str, sev_label: str, ds_id: str) -> tuple[str, dict]:
    color = SEV[sev_label]["hex"]
    return name, {
        "type": "splunk.singlevalue",
        "title": sev_label.upper(),
        "options": {
            "majorColor": color,
            "majorFontSize": 110,
            "unit": "FINDINGS",
            "unitPosition": "after",
            "unitColor": TEXT_DIM,
            "backgroundColor": PANEL_BG,
            "sparklineDisplay": "off",
            "trendDisplay": "off",
            "showValue": "show",
            "numberPrecision": 0,
        },
        "dataSources": {"primary": ds_id},
        "encoding": {"value": "primary.count"},
    }


def main() -> None:
    # ------------------------------------------------------------------ DS --
    data_sources = {
        "ds_base": {
            "type": "ds.search",
            "name": "ES8 Findings Base",
            "options": {
                "query": BASE_SEARCH.strip(),
                "queryParameters": {"earliest": "-7d@d", "latest": "now"},
                "refresh": "5m",
                "refreshType": "delay",
            },
        },
        "ds_open_critical":      {"type": "ds.chain", "name": "Open Critical",      "options": {"extend": "ds_base", "query": chain_open_only("critical")}},
        "ds_open_high":          {"type": "ds.chain", "name": "Open High",          "options": {"extend": "ds_base", "query": chain_open_only("high")}},
        "ds_open_medium":        {"type": "ds.chain", "name": "Open Medium",        "options": {"extend": "ds_base", "query": chain_open_only("medium")}},
        "ds_open_low":           {"type": "ds.chain", "name": "Open Low",           "options": {"extend": "ds_base", "query": chain_open_only("low")}},
        "ds_open_info":          {"type": "ds.chain", "name": "Open Informational", "options": {"extend": "ds_base", "query": chain_open_only("informational")}},
        "ds_closed_8h":          {"type": "ds.chain", "name": "Closed in 8h",       "options": {"extend": "ds_base", "query": CHAIN_CLOSED_8H.strip()}},
        "ds_closed_8h_spark":    {"type": "ds.chain", "name": "Closed 8h sparkline","options": {"extend": "ds_base", "query": CHAIN_CLOSED_8H_SPARK.strip()}},
        "ds_top_owner":          {"type": "ds.chain", "name": "Top Owner 8h",       "options": {"extend": "ds_base", "query": CHAIN_TOP_OWNER.strip()}},
        "ds_top_owner_table":    {"type": "ds.chain", "name": "Owner leaderboard", "options": {"extend": "ds_base", "query": CHAIN_TOP_OWNER_TABLE.strip()}},
        "ds_top_alert":          {"type": "ds.chain", "name": "Top Alert 8h",       "options": {"extend": "ds_base", "query": CHAIN_TOP_ALERT.strip()}},
        "ds_top_alerts_table":   {"type": "ds.chain", "name": "Top alerts table",  "options": {"extend": "ds_base", "query": CHAIN_TOP_ALERTS_TABLE.strip()}},
        "ds_timeline":           {"type": "ds.chain", "name": "Findings timeline",  "options": {"extend": "ds_base", "query": CHAIN_TIMELINE.strip()}},
    }

    # ----------------------------------------------------------------- VIZ --
    visualizations: dict = {}

    # Header logo placeholder — replace this in Studio with an Image viz
    # and upload PNC Power Link.svg via the editor's image picker.
    visualizations["viz_logo_placeholder"] = {
        "type": "splunk.markdown",
        "options": {
            "markdown": (
                f'<div style="display:flex;align-items:center;justify-content:center;'
                f'height:100%;border:1px dashed {TEXT_DIM};border-radius:8px;'
                f'color:{TEXT_DIM};font-size:10px;letter-spacing:3px;text-align:center;">'
                f'ADD<br/>LOGO'
                f'</div>'
            ),
            "backgroundColor": "transparent",
        },
    }
    visualizations["viz_title"] = {
        "type": "splunk.markdown",
        "options": {
            "markdown": (
                f'# <span style="color:{TEXT_PRIM};letter-spacing:2px;">GLOBAL SECURITY FUSION CENTER</span>\n'
                f'## <span style="color:{ACCENT};letter-spacing:6px;font-weight:600;">PNC&nbsp;POWER&nbsp;LINK&nbsp;·&nbsp;ES8 OVERWATCH</span>\n'
                f'<span style="color:{TEXT_DIM};font-size:14px;letter-spacing:3px;">'
                f'OPEN FINDINGS · 8-HOUR ROLLING WINDOW · LIVE</span>'
            ),
            "backgroundColor": "transparent",
        },
    }
    visualizations["viz_clock"] = {
        "type": "splunk.markdown",
        "options": {
            "markdown": (
                f'<div style="text-align:right;line-height:1.1;">'
                f'<span style="color:{TEXT_DIM};font-size:12px;letter-spacing:4px;">AUTO REFRESH</span><br/>'
                f'<span style="color:{TEXT_PRIM};font-size:32px;font-weight:600;'
                f'font-family:Inter,Helvetica,Arial,sans-serif;letter-spacing:2px;">5&nbsp;MIN</span><br/>'
                f'<span style="color:{ACCENT};font-size:11px;letter-spacing:5px;">● LIVE</span>'
                f'</div>'
            ),
            "backgroundColor": "transparent",
        },
    }

    # Severity tiles
    sev_pairs = [
        ("viz_sev_critical", "Critical",      "ds_open_critical"),
        ("viz_sev_high",     "High",          "ds_open_high"),
        ("viz_sev_medium",   "Medium",        "ds_open_medium"),
        ("viz_sev_low",      "Low",           "ds_open_low"),
        ("viz_sev_info",     "Informational", "ds_open_info"),
    ]
    for vid, label, ds in sev_pairs:
        _, viz = severity_viz(vid, label, ds)
        visualizations[vid] = viz

    # Section header labels
    def section_label(text: str, color: str = TEXT_DIM) -> dict:
        return {
            "type": "splunk.markdown",
            "options": {
                "markdown": f'<span style="color:{color};letter-spacing:6px;font-size:12px;font-weight:600;">{text}</span>',
                "backgroundColor": "transparent",
            },
        }

    visualizations["lbl_open"]  = section_label("OPEN ES8 FINDINGS BY CRITICALITY")
    visualizations["lbl_8h"]    = section_label("ROLLING 8-HOUR ACTIVITY")
    visualizations["lbl_owner"] = section_label("TOP CLOSER · 8H")
    visualizations["lbl_alert"] = section_label("TOP FIRING ALERT · 8H")
    visualizations["lbl_time"]  = section_label("FINDINGS TIMELINE · 7D")

    # Closed in 8h - big number
    visualizations["viz_closed_count"] = {
        "type": "splunk.singlevalue",
        "options": {
            "majorColor": "#65A637",
            "majorFontSize": 110,
            "unit": "CLOSED",
            "unitPosition": "after",
            "unitColor": TEXT_DIM,
            "backgroundColor": PANEL_BG,
            "sparklineDisplay": "off",
            "trendDisplay": "off",
            "numberPrecision": 0,
        },
        "dataSources": {"primary": "ds_closed_8h"},
        "encoding": {"value": "primary.count"},
    }

    # Closed 8h sparkline
    visualizations["viz_closed_spark"] = {
        "type": "splunk.area",
        "options": {
            "backgroundColor": PANEL_BG,
            "showXAxisWithLabels": False,
            "showYAxisWithLabels": False,
            "showGridLines": False,
            "showRoundedY1AxisLabels": False,
            "seriesColors": ["#65A637"],
            "legendDisplay": "off",
            "areaOpacity": 0.35,
            "lineWidth": 2,
        },
        "dataSources": {"primary": "ds_closed_8h_spark"},
    }

    # Top owner panel: name + count
    visualizations["viz_top_owner"] = {
        "type": "splunk.singlevalue",
        "options": {
            "majorColor": SPLUNK_PINK,
            "majorFontSize": 78,
            "unit": "CLOSED",
            "unitPosition": "after",
            "unitColor": TEXT_DIM,
            "backgroundColor": PANEL_BG,
            "sparklineDisplay": "off",
            "trendDisplay": "off",
            "numberPrecision": 0,
        },
        "dataSources": {"primary": "ds_top_owner"},
        "encoding": {"value": "primary.value", "label": "primary.label"},
    }
    visualizations["viz_top_owner_table"] = {
        "type": "splunk.table",
        "options": {
            "backgroundColor": PANEL_BG,
            "tableFormat": {"rowBackgroundColors": [PANEL_BG, "#1A1D24"]},
            "rowNumbers": False,
            "headerVisibility": "fixed",
            "count": 5,
        },
        "dataSources": {"primary": "ds_top_owner_table"},
    }

    # Top alert
    visualizations["viz_top_alert"] = {
        "type": "splunk.singlevalue",
        "options": {
            "majorColor": "#F8AB1D",
            "majorFontSize": 60,
            "unit": "FIRES",
            "unitPosition": "after",
            "unitColor": TEXT_DIM,
            "backgroundColor": PANEL_BG,
            "sparklineDisplay": "off",
            "trendDisplay": "off",
            "numberPrecision": 0,
        },
        "dataSources": {"primary": "ds_top_alert"},
        "encoding": {"value": "primary.value", "label": "primary.label"},
    }
    visualizations["viz_top_alerts_table"] = {
        "type": "splunk.table",
        "options": {
            "backgroundColor": PANEL_BG,
            "tableFormat": {
                "rowBackgroundColors": [PANEL_BG, "#1A1D24"],
                "cellColors": [
                    {
                        "field": "Severity",
                        "rules": [
                            {"type": "match", "value": "Critical", "format": {"color": SEV["Critical"]["hex"]}},
                            {"type": "match", "value": "High",     "format": {"color": SEV["High"]["hex"]}},
                            {"type": "match", "value": "Medium",   "format": {"color": SEV["Medium"]["hex"]}},
                            {"type": "match", "value": "Low",      "format": {"color": SEV["Low"]["hex"]}},
                        ],
                    }
                ],
            },
            "rowNumbers": False,
            "headerVisibility": "fixed",
            "count": 6,
        },
        "dataSources": {"primary": "ds_top_alerts_table"},
    }

    # 7-day stacked timeline
    visualizations["viz_timeline"] = {
        "type": "splunk.area",
        "options": {
            "backgroundColor": PANEL_BG,
            "stackMode": "stacked",
            "areaOpacity": 0.75,
            "lineWidth": 1,
            "seriesColors": [
                SEV["Critical"]["hex"],
                SEV["High"]["hex"],
                SEV["Medium"]["hex"],
                SEV["Low"]["hex"],
                SEV["Informational"]["hex"],
            ],
            "showXAxisWithLabels": True,
            "showYAxisWithLabels": True,
            "showGridLines": False,
            "xAxisLabelColor": TEXT_DIM,
            "yAxisLabelColor": TEXT_DIM,
            "legendDisplay": "right",
            "legendLabelColor": TEXT_PRIM,
        },
        "dataSources": {"primary": "ds_timeline"},
    }

    # Decorative background panels — give the dashboard "card" feel.
    def card(name: str) -> None:
        visualizations[name] = {
            "type": "splunk.rectangle",
            "options": {
                "fill": PANEL_BG,
                "fillOpacity": 1.0,
                "strokeColor": PANEL_LINE,
                "strokeWidth": 1,
                "rx": 14,
            },
        }

    for c in [
        "card_header",
        "card_critical", "card_high", "card_medium", "card_low", "card_info",
        "card_closed", "card_owner", "card_alert", "card_timeline",
        "card_accent",
    ]:
        card(c)

    visualizations["card_accent"]["options"]["fill"] = ACCENT
    visualizations["card_accent"]["options"]["strokeColor"] = ACCENT
    visualizations["card_accent"]["options"]["rx"] = 2

    # -------------------------------------------------------------- LAYOUT --
    def at(viz: str, x: int, y: int, w: int, h: int) -> dict:
        return {"item": viz, "type": "block", "position": {"x": x, "y": y, "w": w, "h": h}}

    # 1920 x 1080 canvas.
    GUTTER = 16
    TILE_W = (1920 - GUTTER * 6) // 5  # 5 severity tiles across
    TILE_X = lambda i: GUTTER + i * (TILE_W + GUTTER)
    TILE_Y = 150
    TILE_H = 240

    ROW2_Y = TILE_Y + TILE_H + GUTTER  # 406
    ROW2_H = 280

    ROW3_Y = ROW2_Y + ROW2_H + GUTTER  # 702
    ROW3_H = 1080 - ROW3_Y - GUTTER    # ~362

    structure = [
        # Header card + accent stripe
        at("card_header", GUTTER, GUTTER, 1920 - GUTTER * 2, 110),
        at("card_accent", GUTTER, GUTTER + 110 - 4, 1920 - GUTTER * 2, 4),

        # Logo placeholder / title / clock inside the header
        at("viz_logo_placeholder", GUTTER + 18,  GUTTER + 14, 84, 84),
        at("viz_title",            GUTTER + 120, GUTTER + 18, 1100, 80),
        at("viz_clock",            1920 - GUTTER - 320, GUTTER + 18, 300, 80),

        # Severity row label
        at("lbl_open", GUTTER + 4, TILE_Y - 26, 600, 20),

        # Severity tiles
        at("card_critical", TILE_X(0), TILE_Y, TILE_W, TILE_H),
        at("card_high",     TILE_X(1), TILE_Y, TILE_W, TILE_H),
        at("card_medium",   TILE_X(2), TILE_Y, TILE_W, TILE_H),
        at("card_low",      TILE_X(3), TILE_Y, TILE_W, TILE_H),
        at("card_info",     TILE_X(4), TILE_Y, TILE_W, TILE_H),
        at("viz_sev_critical", TILE_X(0), TILE_Y, TILE_W, TILE_H),
        at("viz_sev_high",     TILE_X(1), TILE_Y, TILE_W, TILE_H),
        at("viz_sev_medium",   TILE_X(2), TILE_Y, TILE_W, TILE_H),
        at("viz_sev_low",      TILE_X(3), TILE_Y, TILE_W, TILE_H),
        at("viz_sev_info",     TILE_X(4), TILE_Y, TILE_W, TILE_H),

        # Row 2 label
        at("lbl_8h", GUTTER + 4, ROW2_Y - 26, 600, 20),

        # Row 2: Closed | Top Owner | Top Alert
        at("card_closed", GUTTER,                       ROW2_Y, 600, ROW2_H),
        at("card_owner",  GUTTER * 2 + 600,             ROW2_Y, 640, ROW2_H),
        at("card_alert",  GUTTER * 3 + 600 + 640,       ROW2_Y, 1920 - (GUTTER * 4 + 600 + 640), ROW2_H),

        # Closed panel contents
        at("viz_closed_count",  GUTTER + 24,             ROW2_Y + 50,  552, 140),
        at("viz_closed_spark",  GUTTER + 24,             ROW2_Y + 190, 552, 70),

        # Owner panel contents
        at("lbl_owner",         GUTTER * 2 + 600 + 24,   ROW2_Y + 16,  300, 18),
        at("viz_top_owner",     GUTTER * 2 + 600 + 24,   ROW2_Y + 36,  592, 100),
        at("viz_top_owner_table", GUTTER * 2 + 600 + 24, ROW2_Y + 142, 592, 124),

        # Alert panel contents
        at("lbl_alert",          GUTTER * 3 + 600 + 640 + 24, ROW2_Y + 16, 300, 18),
        at("viz_top_alert",      GUTTER * 3 + 600 + 640 + 24, ROW2_Y + 36, 1920 - (GUTTER * 4 + 600 + 640) - 48, 100),
        at("viz_top_alerts_table", GUTTER * 3 + 600 + 640 + 24, ROW2_Y + 142, 1920 - (GUTTER * 4 + 600 + 640) - 48, 124),

        # Row 3: 7-day timeline
        at("lbl_time", GUTTER + 4, ROW3_Y - 26, 600, 20),
        at("card_timeline", GUTTER, ROW3_Y, 1920 - GUTTER * 2, ROW3_H),
        at("viz_timeline",  GUTTER + 24, ROW3_Y + 24, 1920 - GUTTER * 2 - 48, ROW3_H - 48),
    ]

    layout = {
        "type": "absolute",
        "options": {
            "width": 1920,
            "height": 1080,
            "display": "auto-scale",
            "backgroundColor": BG,
        },
        "structure": structure,
        "globalInputs": [],
    }

    # ------------------------------------------------------------- ASSEMBLE --
    dashboard = {
        "version": "1.1.0",
        "title": "GSFC · ES8 Overwatch (PNC Power Link)",
        "description": "Overhead TV dashboard for the Global Security Fusion Center: ES8 finding posture, rolling 8h closure activity, top closer, and top firing alert.",
        "theme": "dark",
        "defaults": {
            "dataSources": {
                "ds.search": {
                    "options": {
                        "queryParameters": {"earliest": "-7d@d", "latest": "now"}
                    }
                }
            }
        },
        "inputs": {},
        "dataSources": data_sources,
        "visualizations": visualizations,
        "layout": layout,
    }

    OUT_PATH.write_text(json.dumps(dashboard, indent=2))
    print(f"wrote {OUT_PATH} ({OUT_PATH.stat().st_size:,} bytes)")


if __name__ == "__main__":
    main()
