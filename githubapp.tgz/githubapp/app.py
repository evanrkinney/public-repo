# File: app.py
#
# GitHub App connector for Splunk SOAR (App SDK style).
#
# All authentication is GitHub App based: a signed RS256 JWT mints short-lived
# installation access tokens on demand. Tokens are cached per-installation in
# `asset.auth_state` and refreshed automatically.
#
# `test_connectivity` drives the full GitHub App onboarding manifest flow
# end-to-end the first time it runs, then becomes a credential check on
# subsequent runs.
#
# Copyright (c) 2026 Splunk SOAR Community
# Licensed under the Apache License, Version 2.0

import base64
import hashlib
import hmac
import json
import logging
import os
import time
from pathlib import Path
from typing import Any, Optional
from urllib.parse import urlencode

import jwt
import requests
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import ed25519
from soar_sdk.action_results import ActionOutput  # OutputField available if you add typed subclasses
from soar_sdk.app import App
from soar_sdk.asset import AssetField, BaseAsset, FieldCategory
from soar_sdk.client.soar_client import SOARClient
from soar_sdk.params import Param, Params
from soar_sdk.webhooks import WebhookRequest, WebhookResponse

LOCAL_SCM_PATH = "/opt/phantom/scm/git/local"
PLAYBOOKS_SUBDIR = "playbooks"  # only thing actually on disk in the local repo
SOAR_REST_PAGE_SIZE = 500

logger = logging.getLogger(__name__)

GITHUB_ACCEPT = "application/vnd.github+json"
GITHUB_API_VERSION = "2022-11-28"
JWT_TTL_SECONDS = 540
POLL_TIMEOUT = 300
POLL_INTERVAL = 3
TOKEN_REFRESH_BUFFER = 60  # refresh installation tokens this many seconds before expiry

MANIFEST_CODE_KEY = "manifest_code"
INSTALLATION_ID_KEY = "installation_id"
TOKEN_CACHE_KEY = "installation_tokens"  # {installation_id: {token, expires_epoch}}


# ---------- asset ----------

class Asset(BaseAsset):
    github_api_url: str = AssetField(
        description="GitHub REST API base URL (https://api.github.com for github.com, or https://<ghes>/api/v3 for GHES)",
        default="https://api.github.com",
        category=FieldCategory.CONNECTIVITY,
    )
    app_name: str = AssetField(
        description="Display name for the GitHub App that test_connectivity will create",
        default="splunk-soar-github-app",
        category=FieldCategory.CONNECTIVITY,
    )
    organization: Optional[str] = AssetField(
        description="GitHub organization to create the App under (omit to create under the authenticated user)",
        required=False,
        category=FieldCategory.CONNECTIVITY,
    )
    verify_server_cert: bool = AssetField(
        description="Verify TLS certificates on outbound GitHub calls",
        default=True,
        category=FieldCategory.CONNECTIVITY,
    )

    # NOTE: onboarded credentials (app_id, private_key, webhook_secret,
    # default_installation_id) are NOT stored as Asset fields. They are
    # written to asset.auth_state["app_credentials"] by test_connectivity —
    # auth_state is the only SDK-documented persistence path. Read them with
    # _get_creds(asset), write them with _set_creds(asset, ...).

    # Optional SOAR source-control onboarding integration
    register_with_soar: bool = AssetField(
        description="If true, test_connectivity also registers a repo with /rest/source_control",
        default=False,
    )
    soar_repo_uri: Optional[str] = AssetField(
        description="Git URI for the SOAR source-control entry (e.g. git@github.com:owner/repo.git)",
        required=False,
    )
    soar_repo_branch: str = AssetField(
        description="Branch SOAR should track for source control",
        default="main",
    )
    soar_source_control_name: Optional[str] = AssetField(
        description="Display name for the SOAR source-control entry",
        required=False,
    )



app = App(
    name="GitHub App",
    appid="b2c3d4e5-f6a7-4b8c-9d0e-1f2a3b4c5d6e",
    app_type="information",
    product_vendor="GitHub",
    product_name="GitHub",
    publisher="Splunk SOAR Community",
    logo="logo.svg",
    logo_dark="logo_dark.svg",
    asset_cls=Asset,
    python_version=["3.13"],
    min_phantom_version="7.0.0",
    fips_compliant=True,
)
# Both of this app's webhooks are hit by third parties that cannot present a
# SOAR session cookie:
#   - `result` is hit by the user's browser following a redirect from github.com
#     during the manifest/install flow.
#   - `github_event` is hit by GitHub's outbound webhook workers, which
#     authenticate via X-Hub-Signature-256 (HMAC) rather than SOAR auth.
# So default_requires_auth must be False. The github_event handler does its
# own HMAC verification against the webhook_secret stored in
# asset.auth_state["app_credentials"] before doing anything meaningful, and
# the result handler only writes values into auth_state that are immediately
# validated by the rest of test_connectivity.
app.enable_webhooks(default_requires_auth=False)


# ---------- low-level helpers ----------

CREDS_KEY = "app_credentials"


def _get_creds(asset: Asset) -> dict:
    """Return the onboarded GitHub App credentials dict from asset.auth_state.

    The dict may contain: app_id (str), private_key (str PEM),
    webhook_secret (str), default_installation_id (int). Empty dict if
    test_connectivity has not been run on this asset yet.
    """
    return asset.auth_state.get(CREDS_KEY) or {}


def _set_creds(asset: Asset, **fields: Any) -> None:
    """Merge the provided fields into asset.auth_state[CREDS_KEY]. Writes to
    auth_state persist across action/webhook runs (auth_state is the SDK's
    canonical encrypted-at-rest persistence path)."""
    existing = asset.auth_state.get(CREDS_KEY) or {}
    existing.update({k: v for k, v in fields.items() if v is not None})
    asset.auth_state[CREDS_KEY] = existing


def _api(asset: Asset) -> str:
    return asset.github_api_url.rstrip("/")


def _make_jwt(asset: Asset) -> str:
    creds = _get_creds(asset)
    app_id = creds.get("app_id")
    private_key = creds.get("private_key")
    if not app_id or not private_key:
        raise RuntimeError(
            "GitHub App credentials missing — run test_connectivity to onboard the App first"
        )
    now = int(time.time())
    return jwt.encode(
        {"iat": now - 30, "exp": now + JWT_TTL_SECONDS, "iss": str(app_id)},
        private_key,
        algorithm="RS256",
    )


def _installation_token(asset: Asset, installation_id: Optional[int] = None) -> str:
    iid = installation_id or _get_creds(asset).get("default_installation_id")
    if not iid:
        raise ValueError("installation_id is required (and default_installation_id is not set)")
    cache = asset.auth_state.setdefault(TOKEN_CACHE_KEY, {})
    entry = cache.get(str(iid))
    if entry and entry.get("expires_epoch", 0) - TOKEN_REFRESH_BUFFER > time.time():
        return entry["token"]

    app_jwt = _make_jwt(asset)
    resp = requests.post(
        f"{_api(asset)}/app/installations/{iid}/access_tokens",
        headers={
            "Authorization": f"Bearer {app_jwt}",
            "Accept": GITHUB_ACCEPT,
            "X-GitHub-Api-Version": GITHUB_API_VERSION,
        },
        verify=asset.verify_server_cert,
        timeout=30,
    )
    if resp.status_code >= 300:
        raise RuntimeError(f"Installation token mint failed ({resp.status_code}): {resp.text}")
    data = resp.json()
    cache[str(iid)] = {"token": data["token"], "expires_epoch": time.time() + 3600}
    return data["token"]


def _gh(
    asset: Asset,
    method: str,
    path: str,
    *,
    installation_id: Optional[int] = None,
    use_jwt: bool = False,
    json_body: Any = None,
    params: Optional[dict] = None,
) -> Any:
    """Perform a GitHub REST call. Pass use_jwt=True for App-level endpoints
    (anything under /app or /app/installations); otherwise an installation
    token is minted automatically."""
    if use_jwt:
        token = _make_jwt(asset)
        scheme = "Bearer"
    else:
        token = _installation_token(asset, installation_id)
        scheme = "token"

    url = f"{_api(asset)}{path}"
    resp = requests.request(
        method,
        url,
        headers={
            "Authorization": f"{scheme} {token}",
            "Accept": GITHUB_ACCEPT,
            "X-GitHub-Api-Version": GITHUB_API_VERSION,
        },
        json=json_body,
        params=params,
        verify=asset.verify_server_cert,
        timeout=60,
    )
    if resp.status_code == 204 or not resp.content:
        return {}
    if resp.status_code >= 300:
        raise RuntimeError(f"GitHub {method} {path} -> {resp.status_code}: {resp.text}")
    try:
        return resp.json()
    except ValueError:
        raise RuntimeError(f"GitHub returned non-JSON: {resp.text[:200]}")


def _paginate(asset: Asset, path: str, *, installation_id: Optional[int] = None,
              use_jwt: bool = False, params: Optional[dict] = None, max_pages: int = 10) -> list:
    """Walk GitHub paginated endpoints. Caps at max_pages to keep results sane."""
    out: list = []
    params = dict(params or {})
    params.setdefault("per_page", 100)
    for page in range(1, max_pages + 1):
        params["page"] = page
        chunk = _gh(asset, "GET", path, installation_id=installation_id,
                    use_jwt=use_jwt, params=params)
        if not isinstance(chunk, list):
            # endpoints like /installation/repositories wrap results in {"repositories": [...]}
            for key in ("repositories", "items", "members"):
                if key in chunk and isinstance(chunk[key], list):
                    chunk = chunk[key]
                    break
            else:
                return [chunk]
        out.extend(chunk)
        if len(chunk) < params["per_page"]:
            break
    return out


# ---------- onboarding helpers ----------

def _build_manifest_url(asset: Asset, redirect_url: str, event_webhook_url: str) -> str:
    manifest = {
        "name": asset.app_name,
        "url": redirect_url,
        "redirect_url": redirect_url,
        "hook_attributes": {"url": event_webhook_url, "active": True},
        "public": False,
        "default_permissions": {
            "administration": "write",
            "contents": "write",
            "issues": "write",
            "members": "write",
            "metadata": "read",
            "pull_requests": "write",
        },
        "default_events": ["issues", "issue_comment", "pull_request", "push"],
    }
    base = (
        f"https://github.com/organizations/{asset.organization}/settings/apps/new"
        if asset.organization
        else "https://github.com/settings/apps/new"
    )
    return f"{base}?{urlencode({'manifest': json.dumps(manifest)})}"


def _wait_for(asset: Asset, key: str, label: str):
    logger.info("Waiting for %s...", label)
    start = time.time()
    while time.time() - start < POLL_TIMEOUT:
        time.sleep(POLL_INTERVAL)
        value = asset.auth_state.get(key)
        if value:
            return value
    raise TimeoutError(f"{label} timed out after {POLL_TIMEOUT}s")


def _convert_manifest_code(asset: Asset, code: str) -> dict:
    resp = requests.post(
        f"{_api(asset)}/app-manifests/{code}/conversions",
        headers={"Accept": GITHUB_ACCEPT, "X-GitHub-Api-Version": GITHUB_API_VERSION},
        verify=asset.verify_server_cert,
        timeout=30,
    )
    if resp.status_code >= 300:
        raise RuntimeError(f"Manifest conversion failed ({resp.status_code}): {resp.text}")
    return resp.json()


# ---------- webhook ----------

@app.webhook("result", allowed_methods=["GET"])
def handle_github_redirect(request: WebhookRequest[Asset]) -> WebhookResponse:
    """Single webhook handles both legs of the manifest flow:
    - manifest creation redirect: ?code=...
    - installation redirect:      ?installation_id=...&setup_action=install
    """
    # WebhookRequest.query is always dict[str, list[str]] (SDK normalizes it)
    query = {k: (v[0] if v else "") for k, v in request.query.items()}

    if "error" in query:
        reason = query.get("error_description", query.get("error", "unknown"))
        return WebhookResponse.text_response(f"GitHub returned an error: {reason}", status_code=400)

    if query.get("installation_id"):
        request.asset.auth_state[INSTALLATION_ID_KEY] = int(query["installation_id"])
        return WebhookResponse.text_response(
            "GitHub App installed. You can close this window.", status_code=200
        )

    code = query.get("code")
    if not code:
        return WebhookResponse.text_response(
            "Missing 'code' or 'installation_id' query parameter", status_code=400
        )
    request.asset.auth_state[MANIFEST_CODE_KEY] = code
    return WebhookResponse.text_response(
        "GitHub App created. Next, install the App on your account/org. You can close this window.",
        status_code=200,
    )


# ---------- github event ingestion ----------

EVENT_LABEL = "github_event"


def _verify_github_signature(secret: str, body: bytes, signature_header: Optional[str]) -> bool:
    """Constant-time HMAC-SHA256 verification of an X-Hub-Signature-256 header."""
    if not signature_header or not signature_header.startswith("sha256="):
        return False
    expected = "sha256=" + hmac.new(secret.encode("utf-8"), body, hashlib.sha256).hexdigest()
    return hmac.compare_digest(expected, signature_header)


def _summarize_github_event(event_type: str, payload: dict) -> tuple[str, dict]:
    """Return (human_summary, cef_fields) for a GitHub webhook payload.
    Falls back to a generic summary for event types not specifically handled."""
    repo = (payload.get("repository") or {}).get("full_name")
    sender = (payload.get("sender") or {}).get("login")
    cef: dict = {}
    if repo:
        cef["repo"] = repo
    if sender:
        cef["sender"] = sender

    if event_type == "issues":
        action = payload.get("action", "?")
        issue = payload.get("issue") or {}
        cef.update({
            "issue_number": issue.get("number"),
            "issue_title": issue.get("title"),
            "issue_state": issue.get("state"),
            "issue_url": issue.get("html_url"),
            "action": action,
        })
        return f"issues.{action}: #{issue.get('number')} {issue.get('title')}", cef

    if event_type == "issue_comment":
        action = payload.get("action", "?")
        issue = payload.get("issue") or {}
        comment = payload.get("comment") or {}
        cef.update({
            "issue_number": issue.get("number"),
            "issue_title": issue.get("title"),
            "comment_id": comment.get("id"),
            "comment_url": comment.get("html_url"),
            "action": action,
        })
        return f"issue_comment.{action} on #{issue.get('number')}", cef

    if event_type == "pull_request":
        action = payload.get("action", "?")
        pr = payload.get("pull_request") or {}
        cef.update({
            "pr_number": pr.get("number"),
            "pr_title": pr.get("title"),
            "pr_state": pr.get("state"),
            "pr_url": pr.get("html_url"),
            "pr_head": (pr.get("head") or {}).get("ref"),
            "pr_base": (pr.get("base") or {}).get("ref"),
            "action": action,
        })
        return f"pull_request.{action}: #{pr.get('number')} {pr.get('title')}", cef

    if event_type == "push":
        ref = payload.get("ref", "?")
        commits = payload.get("commits") or []
        cef.update({
            "ref": ref,
            "commit_count": len(commits),
            "head_commit": (payload.get("head_commit") or {}).get("id"),
            "before": payload.get("before"),
            "after": payload.get("after"),
        })
        return f"push to {ref} ({len(commits)} commit(s))", cef

    return f"{event_type}", cef


@app.webhook("github_event", allowed_methods=["POST"])
def handle_github_event(request: WebhookRequest[Asset]) -> WebhookResponse:
    """Receives GitHub webhook deliveries from the App. Verifies the
    X-Hub-Signature-256 HMAC, then creates a SOAR container + artifact for
    each delivery so playbooks can subscribe via the 'github_event' label."""
    asset = request.asset
    webhook_secret = _get_creds(asset).get("webhook_secret")
    if not webhook_secret:
        logger.warning("Received GitHub event but asset has no webhook_secret in auth_state; rejecting")
        return WebhookResponse.text_response(
            "webhook_secret not configured — run test_connectivity first",
            status_code=503,
        )

    # WebhookRequest.headers is dict[str, str] per the SDK; lowercase for
    # case-insensitive lookup of GitHub's X-Hub-Signature-256 etc.
    headers = {k.lower(): v for k, v in request.headers.items()}
    signature = headers.get("x-hub-signature-256")
    event_type = headers.get("x-github-event") or "unknown"
    delivery_id = headers.get("x-github-delivery") or f"no-delivery-{int(time.time())}"

    # WebhookRequest.body is str | None per the SDK — encode for HMAC
    raw_body = (request.body or "").encode("utf-8")

    if not _verify_github_signature(webhook_secret, raw_body, signature):
        logger.warning("Rejecting GitHub event %s/%s: signature verification failed",
                       event_type, delivery_id)
        return WebhookResponse.text_response("invalid signature", status_code=401)

    if event_type == "ping":
        # GitHub sends a ping when the webhook is first configured. Acknowledge
        # without creating a container.
        logger.info("Received GitHub webhook ping (delivery=%s)", delivery_id)
        return WebhookResponse.text_response("pong", status_code=200)

    try:
        payload = json.loads(raw_body.decode("utf-8")) if raw_body else {}
    except (ValueError, UnicodeDecodeError) as exc:
        logger.warning("Could not parse GitHub event body for delivery %s: %s", delivery_id, exc)
        return WebhookResponse.text_response("invalid json", status_code=400)

    summary, cef = _summarize_github_event(event_type, payload)
    logger.info("Ingesting GitHub event %s/%s: %s", event_type, delivery_id, summary)

    # The SDK updates app.soar_client with the authenticated session for the
    # calling asset before invoking webhook handlers, so we use the module-level
    # `app.soar_client` here — WebhookRequest does not carry a SOARClient.
    # Container.create() requires asset_id; set_executing_asset populates it
    # automatically for every container created through this interface.
    app.soar_client.container.set_executing_asset(str(request.asset_id))

    # Create the container and its artifact in one call by nesting the artifact
    # in the `artifacts` list on the container dict. The SOAR Container API
    # supports this and it's one round-trip instead of two.
    try:
        container_id = app.soar_client.container.create({
            "name": f"GitHub {event_type}: {summary}",
            "label": EVENT_LABEL,
            "source_data_identifier": delivery_id,
            "severity": "low",
            "status": "new",
            "run_automation": True,
            "data": {
                "github_event": event_type,
                "delivery": delivery_id,
                "repository": (payload.get("repository") or {}).get("full_name"),
            },
            "artifacts": [{
                "name": f"github.{event_type}",
                "label": "event",
                "source_data_identifier": delivery_id,
                "cef": cef,
                "data": payload,
                "run_automation": True,
            }],
        })
    except Exception as exc:
        logger.warning("Container creation failed for delivery %s: %s", delivery_id, exc)
        return WebhookResponse.text_response("container creation failed", status_code=500)

    return WebhookResponse.text_response(f"ingested as container {container_id}", status_code=202)


# =====================================================================
# ACTIONS
# =====================================================================

# Generic passthrough output. The SDK supports strongly-typed ActionOutput
# subclasses per action with OutputField metadata for SOAR's UI column
# rendering, but with 30+ actions all returning GitHub REST payloads (which
# are documented in GitHub's API spec, not ours), one generic wrapper is the
# right tradeoff. To get column rendering on a specific action, subclass
# GenericOutput and add OutputFields for the keys you care about, then pass
# output_class=YourOutput to the @app.action decorator.

# GenericOutput is a minimal ActionOutput subclass that accepts arbitrary JSON
# payloads. Because OutputField only supports cef_types/example_values/alias/
# column_name (no `description`, no `default`), we declare these as plain
# pydantic fields with no OutputField call. The SDK's datapath generator will
# produce generic action_result.data[*] / action_result.summary datapaths.
#
# For column rendering on a specific action, subclass GenericOutput (or
# ActionOutput directly), add typed fields with OutputField(column_name=...,
# example_values=..., cef_types=...), and pass output_class=YourOutput to that
# action's @app.action(...) decorator.

class GenericOutput(ActionOutput):
    data: list = []
    summary: Optional[dict] = None


# ---------- test connectivity (the full onboarding flow) ----------

@app.test_connectivity()
def test_connectivity(soar: SOARClient, asset: Asset) -> None:
    redirect_url = app.get_webhook_url("result")
    logger.info("Using GitHub redirect URL: %s", redirect_url)

    onboarded_now = False
    onboard_result: dict = {}
    event_webhook_url = app.get_webhook_url("github_event")
    logger.info("GitHub event webhook URL (auto-configured in the App): %s", event_webhook_url)

    creds = _get_creds(asset)
    if not (creds.get("app_id") and creds.get("private_key")):
        asset.auth_state.pop(MANIFEST_CODE_KEY, None)
        manifest_url = _build_manifest_url(asset, redirect_url, event_webhook_url)
        logger.info("Open the following URL, click 'Create GitHub App', then install the App when prompted:")
        logger.info(manifest_url)

        code = _wait_for(asset, MANIFEST_CODE_KEY, "GitHub App manifest creation")
        onboard_result = _convert_manifest_code(asset, code)
        _set_creds(
            asset,
            app_id=str(onboard_result["id"]),
            private_key=onboard_result["pem"],
            webhook_secret=onboard_result.get("webhook_secret"),
        )
        onboarded_now = True
        logger.info("App created: id=%s slug=%s",
                    onboard_result.get("id"), onboard_result.get("slug"))
        logger.info("Install the App from: %s", onboard_result.get("html_url"))
    else:
        logger.info("Using existing App credentials (app_id=%s)", creds.get("app_id"))

    creds = _get_creds(asset)
    if not creds.get("default_installation_id"):
        asset.auth_state.pop(INSTALLATION_ID_KEY, None)
        installation_id = _wait_for(asset, INSTALLATION_ID_KEY, "GitHub App installation")
        _set_creds(asset, default_installation_id=int(installation_id))
        logger.info("Installation captured: id=%s", installation_id)

    token = _installation_token(asset)
    logger.info("Installation token minted (length=%d)", len(token))

    if asset.register_with_soar:
        if not asset.soar_repo_uri or not asset.soar_source_control_name:
            raise ValueError("register_with_soar=True requires soar_repo_uri and soar_source_control_name")
        resp = soar.post("/rest/source_control", json={
            "name": asset.soar_source_control_name,
            "uri": asset.soar_repo_uri,
            "branch": asset.soar_repo_branch or "main",
            "username": "x-access-token",
            "password": token,
        })
        resp.raise_for_status()
        logger.info("Registered repo with SOAR /rest/source_control")

    final_creds = _get_creds(asset)
    if onboarded_now:
        # Surface the onboarding details in the action run message so they're
        # visible in SOAR's action history. SOAR does not truncate set_message
        # content, so the PEM-backup reminder goes here.
        soar.set_message(
            f"Test Connectivity Passed — GitHub App '{onboard_result.get('slug')}' provisioned.\n"
            f"App ID: {final_creds.get('app_id')}  |  "
            f"Installation: {final_creds.get('default_installation_id')}  |  "
            f"Install URL: {onboard_result.get('html_url')}\n"
            f"IMPORTANT: The PEM private key is stored in this asset's encrypted auth_state. "
            f"GitHub does not show it again, and losing SOAR's database means re-onboarding the App. "
            f"Back up the PEM out-of-band (vault, password manager) via the 'get asset credentials' action. "
            f"Installation tokens are refreshed automatically every hour — no manual rotation needed."
        )
    else:
        soar.set_message("Test Connectivity Passed")


# ---------- installations / repos ----------

class ListInstallationsParams(Params):
    pass

@app.action(
    name="list installations",
    identifier="list_installations",
    description="List installations of this GitHub App",
    action_type="investigate",
    read_only=True,
)
def list_installations(params: ListInstallationsParams, soar: SOARClient, asset: Asset) -> GenericOutput:
    data = _paginate(asset, "/app/installations", use_jwt=True)
    return GenericOutput(data=data, summary={"total": len(data)})


class ListReposParams(Params):
    installation_id: Optional[int] = Param(description="installation id", required=False)

@app.action(
    name="list repos",
    identifier="list_repos",
    description="List repositories accessible to the App installation",
    action_type="investigate",
    read_only=True,
)
def list_repos(params: ListReposParams, soar: SOARClient, asset: Asset) -> GenericOutput:
    data = _paginate(asset, "/installation/repositories", installation_id=params.installation_id)
    return GenericOutput(data=data, summary={"total": len(data)})


class RepoParams(Params):
    owner: str = Param(description="owner", required=True)
    repo: str = Param(description="repo", required=True)
    installation_id: Optional[int] = Param(description="installation id", required=False)

@app.action(name="get repo", identifier="get_repo",
            description="Get a repository", action_type="investigate", read_only=True)
def get_repo(params: RepoParams, soar: SOARClient, asset: Asset) -> GenericOutput:
    data = _gh(asset, "GET", f"/repos/{params.owner}/{params.repo}",
               installation_id=params.installation_id)
    return GenericOutput(data=[data])


class CreateRepoParams(Params):
    name: str = Param(description="name", required=True)
    owner: Optional[str] = Param(description="owner", required=False)  # org login; omit to create under the App user
    description: Optional[str] = Param(description="description", required=False)
    private: bool = Param(description="private", default=True)
    auto_init: bool = Param(description="auto init", default=True)
    installation_id: Optional[int] = Param(description="installation id", required=False)

@app.action(name="create repo", identifier="create_repo",
            description="Create a repository under an org or the authenticated user",
            action_type="generic", read_only=False)
def create_repo(params: CreateRepoParams, soar: SOARClient, asset: Asset) -> GenericOutput:
    body = {"name": params.name, "private": params.private, "auto_init": params.auto_init}
    if params.description:
        body["description"] = params.description
    path = f"/orgs/{params.owner}/repos" if params.owner else "/user/repos"
    data = _gh(asset, "POST", path, json_body=body, installation_id=params.installation_id)
    return GenericOutput(data=[data], summary={"full_name": data.get("full_name")})


@app.action(name="delete repo", identifier="delete_repo",
            description="Delete a repository", action_type="contain", read_only=False)
def delete_repo(params: RepoParams, soar: SOARClient, asset: Asset) -> GenericOutput:
    _gh(asset, "DELETE", f"/repos/{params.owner}/{params.repo}",
        installation_id=params.installation_id)
    return GenericOutput(data=[{"deleted": f"{params.owner}/{params.repo}"}])


# ---------- branches & files ----------

@app.action(name="list branches", identifier="list_branches",
            description="List branches in a repository", action_type="investigate", read_only=True)
def list_branches(params: RepoParams, soar: SOARClient, asset: Asset) -> GenericOutput:
    data = _paginate(asset, f"/repos/{params.owner}/{params.repo}/branches",
                     installation_id=params.installation_id)
    return GenericOutput(data=data, summary={"total": len(data)})


class CreateBranchParams(Params):
    owner: str = Param(description="owner", required=True)
    repo: str = Param(description="repo", required=True)
    new_branch: str = Param(description="new branch", required=True)
    from_branch: str = Param(description="from branch", default="main")
    installation_id: Optional[int] = Param(description="installation id", required=False)

@app.action(name="create branch", identifier="create_branch",
            description="Create a new branch from an existing branch",
            action_type="generic", read_only=False)
def create_branch(params: CreateBranchParams, soar: SOARClient, asset: Asset) -> GenericOutput:
    ref = _gh(asset, "GET",
              f"/repos/{params.owner}/{params.repo}/git/ref/heads/{params.from_branch}",
              installation_id=params.installation_id)
    sha = ref.get("object", {}).get("sha")
    if not sha:
        raise RuntimeError(f"Could not resolve SHA for {params.from_branch}")
    data = _gh(asset, "POST",
               f"/repos/{params.owner}/{params.repo}/git/refs",
               installation_id=params.installation_id,
               json_body={"ref": f"refs/heads/{params.new_branch}", "sha": sha})
    return GenericOutput(data=[data])


class FileReadParams(Params):
    owner: str = Param(description="owner", required=True)
    repo: str = Param(description="repo", required=True)
    path: str = Param(description="path", required=True)
    ref: Optional[str] = Param(description="ref", required=False)  # branch, tag, or commit SHA
    installation_id: Optional[int] = Param(description="installation id", required=False)

@app.action(name="get file", identifier="get_file",
            description="Get a file's contents (UTF-8 decoded)",
            action_type="investigate", read_only=True)
def get_file(params: FileReadParams, soar: SOARClient, asset: Asset) -> GenericOutput:
    p = {"ref": params.ref} if params.ref else None
    data = _gh(asset, "GET", f"/repos/{params.owner}/{params.repo}/contents/{params.path}",
               installation_id=params.installation_id, params=p)
    if isinstance(data, dict) and data.get("encoding") == "base64" and data.get("content"):
        try:
            data["decoded_content"] = base64.b64decode(data["content"]).decode("utf-8")
        except UnicodeDecodeError:
            data["decoded_content"] = None
    return GenericOutput(data=[data])


class FileWriteParams(Params):
    owner: str = Param(description="owner", required=True)
    repo: str = Param(description="repo", required=True)
    path: str = Param(description="path", required=True)
    content: str = Param(description="content", required=True)
    message: str = Param(description="message", required=True)
    branch: Optional[str] = Param(description="branch", required=False)
    installation_id: Optional[int] = Param(description="installation id", required=False)

@app.action(name="create or update file", identifier="create_or_update_file",
            description="Create a file, or update it if it already exists",
            action_type="generic", read_only=False)
def create_or_update_file(params: FileWriteParams, soar: SOARClient, asset: Asset) -> GenericOutput:
    endpoint = f"/repos/{params.owner}/{params.repo}/contents/{params.path}"
    existing_sha = None
    try:
        existing = _gh(asset, "GET", endpoint, installation_id=params.installation_id,
                       params={"ref": params.branch} if params.branch else None)
        if isinstance(existing, dict):
            existing_sha = existing.get("sha")
    except RuntimeError as e:
        # Only treat a real 404 as "new file". Surface any other error
        # (500, network, auth) rather than silently overwriting.
        if "-> 404" not in str(e):
            raise
    body = {
        "message": params.message,
        "content": base64.b64encode(params.content.encode("utf-8")).decode("ascii"),
    }
    if params.branch:
        body["branch"] = params.branch
    if existing_sha:
        body["sha"] = existing_sha
    data = _gh(asset, "PUT", endpoint, installation_id=params.installation_id, json_body=body)
    return GenericOutput(data=[data])


class FileDeleteParams(Params):
    owner: str = Param(description="owner", required=True)
    repo: str = Param(description="repo", required=True)
    path: str = Param(description="path", required=True)
    message: str = Param(description="message", required=True)
    branch: Optional[str] = Param(description="branch", required=False)
    installation_id: Optional[int] = Param(description="installation id", required=False)

@app.action(name="delete file", identifier="delete_file",
            description="Delete a file from a repository",
            action_type="contain", read_only=False)
def delete_file(params: FileDeleteParams, soar: SOARClient, asset: Asset) -> GenericOutput:
    endpoint = f"/repos/{params.owner}/{params.repo}/contents/{params.path}"
    existing = _gh(asset, "GET", endpoint, installation_id=params.installation_id,
                   params={"ref": params.branch} if params.branch else None)
    sha = existing.get("sha") if isinstance(existing, dict) else None
    if not sha:
        raise RuntimeError(f"File {params.path} not found")
    body = {"message": params.message, "sha": sha}
    if params.branch:
        body["branch"] = params.branch
    data = _gh(asset, "DELETE", endpoint, installation_id=params.installation_id, json_body=body)
    return GenericOutput(data=[data])


# ---------- pull requests ----------

class ListPRParams(Params):
    owner: str = Param(description="owner", required=True)
    repo: str = Param(description="repo", required=True)
    state: str = Param(description="state", default="open")  # open | closed | all
    installation_id: Optional[int] = Param(description="installation id", required=False)

@app.action(name="list pull requests", identifier="list_pull_requests",
            description="List pull requests in a repository",
            action_type="investigate", read_only=True)
def list_pull_requests(params: ListPRParams, soar: SOARClient, asset: Asset) -> GenericOutput:
    data = _paginate(asset, f"/repos/{params.owner}/{params.repo}/pulls",
                     installation_id=params.installation_id, params={"state": params.state})
    return GenericOutput(data=data, summary={"total": len(data)})


class CreatePRParams(Params):
    owner: str = Param(description="owner", required=True)
    repo: str = Param(description="repo", required=True)
    title: str = Param(description="title", required=True)
    head: str = Param(description="head", required=True)
    base: str = Param(description="base", default="main")
    body: Optional[str] = Param(description="body", required=False)
    draft: bool = Param(description="draft", default=False)
    installation_id: Optional[int] = Param(description="installation id", required=False)

@app.action(name="create pull request", identifier="create_pull_request",
            description="Open a pull request", action_type="generic", read_only=False)
def create_pull_request(params: CreatePRParams, soar: SOARClient, asset: Asset) -> GenericOutput:
    body = {"title": params.title, "head": params.head, "base": params.base, "draft": params.draft}
    if params.body:
        body["body"] = params.body
    data = _gh(asset, "POST", f"/repos/{params.owner}/{params.repo}/pulls",
               installation_id=params.installation_id, json_body=body)
    return GenericOutput(data=[data], summary={"number": data.get("number"), "html_url": data.get("html_url")})


class MergePRParams(Params):
    owner: str = Param(description="owner", required=True)
    repo: str = Param(description="repo", required=True)
    pull_number: int = Param(description="pull number", required=True)
    commit_title: Optional[str] = Param(description="commit title", required=False)
    commit_message: Optional[str] = Param(description="commit message", required=False)
    merge_method: str = Param(description="merge method", default="merge")  # merge | squash | rebase
    installation_id: Optional[int] = Param(description="installation id", required=False)

@app.action(name="merge pull request", identifier="merge_pull_request",
            description="Merge a pull request", action_type="generic", read_only=False)
def merge_pull_request(params: MergePRParams, soar: SOARClient, asset: Asset) -> GenericOutput:
    body = {"merge_method": params.merge_method}
    if params.commit_title:
        body["commit_title"] = params.commit_title
    if params.commit_message:
        body["commit_message"] = params.commit_message
    data = _gh(asset, "PUT",
               f"/repos/{params.owner}/{params.repo}/pulls/{params.pull_number}/merge",
               installation_id=params.installation_id, json_body=body)
    return GenericOutput(data=[data])


# ---------- issues ----------

class ListIssuesParams(Params):
    owner: str = Param(description="owner", required=True)
    repo: str = Param(description="repo", required=True)
    state: str = Param(description="state", default="open")  # open | closed | all
    labels: Optional[str] = Param(description="labels", required=False)  # comma-separated
    assignee: Optional[str] = Param(description="assignee", required=False)
    installation_id: Optional[int] = Param(description="installation id", required=False)

@app.action(name="list issues", identifier="list_issues",
            description="List issues in a repository (excludes pull requests)",
            action_type="investigate", read_only=True)
def list_issues(params: ListIssuesParams, soar: SOARClient, asset: Asset) -> GenericOutput:
    p = {"state": params.state}
    if params.labels:
        p["labels"] = params.labels
    if params.assignee:
        p["assignee"] = params.assignee
    data = _paginate(asset, f"/repos/{params.owner}/{params.repo}/issues",
                     installation_id=params.installation_id, params=p)
    # Filter out PRs (GitHub's /issues endpoint includes them)
    issues = [i for i in data if "pull_request" not in i]
    return GenericOutput(data=issues, summary={"total": len(issues)})


class IssueRefParams(Params):
    owner: str = Param(description="owner", required=True)
    repo: str = Param(description="repo", required=True)
    issue_number: int = Param(description="issue number", required=True)
    installation_id: Optional[int] = Param(description="installation id", required=False)

@app.action(name="get issue", identifier="get_issue",
            description="Get a single issue", action_type="investigate", read_only=True)
def get_issue(params: IssueRefParams, soar: SOARClient, asset: Asset) -> GenericOutput:
    data = _gh(asset, "GET",
               f"/repos/{params.owner}/{params.repo}/issues/{params.issue_number}",
               installation_id=params.installation_id)
    return GenericOutput(data=[data])


class CreateIssueParams(Params):
    owner: str = Param(description="owner", required=True)
    repo: str = Param(description="repo", required=True)
    title: str = Param(description="title", required=True)
    body: Optional[str] = Param(description="body", required=False)
    assignees: Optional[str] = Param(description="assignees", required=False)  # comma-separated
    labels: Optional[str] = Param(description="labels", required=False)     # comma-separated
    installation_id: Optional[int] = Param(description="installation id", required=False)

@app.action(name="create issue", identifier="create_issue",
            description="Create an issue", action_type="generic", read_only=False)
def create_issue(params: CreateIssueParams, soar: SOARClient, asset: Asset) -> GenericOutput:
    body: dict = {"title": params.title}
    if params.body:
        body["body"] = params.body
    if params.assignees:
        body["assignees"] = [a.strip() for a in params.assignees.split(",") if a.strip()]
    if params.labels:
        body["labels"] = [l.strip() for l in params.labels.split(",") if l.strip()]
    data = _gh(asset, "POST", f"/repos/{params.owner}/{params.repo}/issues",
               installation_id=params.installation_id, json_body=body)
    return GenericOutput(data=[data], summary={"number": data.get("number"), "html_url": data.get("html_url")})


class UpdateIssueParams(Params):
    owner: str = Param(description="owner", required=True)
    repo: str = Param(description="repo", required=True)
    issue_number: int = Param(description="issue number", required=True)
    title: Optional[str] = Param(description="title", required=False)
    body: Optional[str] = Param(description="body", required=False)
    state: Optional[str] = Param(description="state", required=False)  # open | closed
    state_reason: Optional[str] = Param(description="state reason", required=False)  # completed | not_planned | reopened
    assignees: Optional[str] = Param(description="assignees", required=False)
    labels: Optional[str] = Param(description="labels", required=False)
    installation_id: Optional[int] = Param(description="installation id", required=False)

@app.action(name="update issue", identifier="update_issue",
            description="Update an issue (title, body, state, assignees, labels)",
            action_type="generic", read_only=False)
def update_issue(params: UpdateIssueParams, soar: SOARClient, asset: Asset) -> GenericOutput:
    body: dict = {}
    if params.title is not None:
        body["title"] = params.title
    if params.body is not None:
        body["body"] = params.body
    if params.state is not None:
        body["state"] = params.state
    if params.state_reason is not None:
        body["state_reason"] = params.state_reason
    if params.assignees is not None:
        body["assignees"] = [a.strip() for a in params.assignees.split(",") if a.strip()]
    if params.labels is not None:
        body["labels"] = [l.strip() for l in params.labels.split(",") if l.strip()]
    data = _gh(asset, "PATCH",
               f"/repos/{params.owner}/{params.repo}/issues/{params.issue_number}",
               installation_id=params.installation_id, json_body=body)
    return GenericOutput(data=[data])


@app.action(name="list issue comments", identifier="list_issue_comments",
            description="List comments on an issue", action_type="investigate", read_only=True)
def list_issue_comments(params: IssueRefParams, soar: SOARClient, asset: Asset) -> GenericOutput:
    data = _paginate(asset,
                     f"/repos/{params.owner}/{params.repo}/issues/{params.issue_number}/comments",
                     installation_id=params.installation_id)
    return GenericOutput(data=data, summary={"total": len(data)})


class CreateCommentParams(Params):
    owner: str = Param(description="owner", required=True)
    repo: str = Param(description="repo", required=True)
    issue_number: int = Param(description="issue number", required=True)
    body: str = Param(description="body", required=True)
    installation_id: Optional[int] = Param(description="installation id", required=False)

@app.action(name="create issue comment", identifier="create_issue_comment",
            description="Add a comment to an issue", action_type="generic", read_only=False)
def create_issue_comment(params: CreateCommentParams, soar: SOARClient, asset: Asset) -> GenericOutput:
    data = _gh(asset, "POST",
               f"/repos/{params.owner}/{params.repo}/issues/{params.issue_number}/comments",
               installation_id=params.installation_id,
               json_body={"body": params.body})
    return GenericOutput(data=[data])


class AddLabelsParams(Params):
    owner: str = Param(description="owner", required=True)
    repo: str = Param(description="repo", required=True)
    issue_number: int = Param(description="issue number", required=True)
    labels: str = Param(description="labels", required=True)  # comma-separated
    installation_id: Optional[int] = Param(description="installation id", required=False)

@app.action(name="add issue labels", identifier="add_issue_labels",
            description="Add labels to an issue", action_type="generic", read_only=False)
def add_issue_labels(params: AddLabelsParams, soar: SOARClient, asset: Asset) -> GenericOutput:
    labels = [l.strip() for l in params.labels.split(",") if l.strip()]
    data = _gh(asset, "POST",
               f"/repos/{params.owner}/{params.repo}/issues/{params.issue_number}/labels",
               installation_id=params.installation_id,
               json_body={"labels": labels})
    return GenericOutput(data=data if isinstance(data, list) else [data])


# ---------- collaborators ----------

class CollaboratorParams(Params):
    owner: str = Param(description="owner", required=True)
    repo: str = Param(description="repo", required=True)
    username: str = Param(description="username", required=True)
    permission: str = Param(description="permission", default="push")  # pull | triage | push | maintain | admin
    installation_id: Optional[int] = Param(description="installation id", required=False)

@app.action(name="add collaborator", identifier="add_collaborator",
            description="Invite a user as a collaborator on a repository",
            action_type="generic", read_only=False)
def add_collaborator(params: CollaboratorParams, soar: SOARClient, asset: Asset) -> GenericOutput:
    data = _gh(asset, "PUT",
               f"/repos/{params.owner}/{params.repo}/collaborators/{params.username}",
               installation_id=params.installation_id,
               json_body={"permission": params.permission})
    return GenericOutput(data=[data or {"username": params.username, "permission": params.permission}])


class RemoveCollaboratorParams(Params):
    owner: str = Param(description="owner", required=True)
    repo: str = Param(description="repo", required=True)
    username: str = Param(description="username", required=True)
    installation_id: Optional[int] = Param(description="installation id", required=False)

@app.action(name="remove collaborator", identifier="remove_collaborator",
            description="Remove a collaborator from a repository",
            action_type="contain", read_only=False)
def remove_collaborator(params: RemoveCollaboratorParams, soar: SOARClient, asset: Asset) -> GenericOutput:
    _gh(asset, "DELETE",
        f"/repos/{params.owner}/{params.repo}/collaborators/{params.username}",
        installation_id=params.installation_id)
    return GenericOutput(data=[{"removed": params.username}])


# ---------- organizations / members / teams ----------

class OrgParams(Params):
    org: str = Param(description="org", required=True)
    installation_id: Optional[int] = Param(description="installation id", required=False)

@app.action(name="list org members", identifier="list_org_members",
            description="List members of an organization",
            action_type="investigate", read_only=True)
def list_org_members(params: OrgParams, soar: SOARClient, asset: Asset) -> GenericOutput:
    data = _paginate(asset, f"/orgs/{params.org}/members",
                     installation_id=params.installation_id)
    return GenericOutput(data=data, summary={"total": len(data)})


@app.action(name="list org teams", identifier="list_org_teams",
            description="List teams in an organization",
            action_type="investigate", read_only=True)
def list_org_teams(params: OrgParams, soar: SOARClient, asset: Asset) -> GenericOutput:
    data = _paginate(asset, f"/orgs/{params.org}/teams",
                     installation_id=params.installation_id)
    return GenericOutput(data=data, summary={"total": len(data)})


class TeamMemberParams(Params):
    org: str = Param(description="org", required=True)
    team_slug: str = Param(description="team slug", required=True)
    username: str = Param(description="username", required=True)
    role: str = Param(description="role", default="member")  # member | maintainer
    installation_id: Optional[int] = Param(description="installation id", required=False)

@app.action(name="add team member", identifier="add_team_member",
            description="Add or update a user's membership on a team",
            action_type="generic", read_only=False)
def add_team_member(params: TeamMemberParams, soar: SOARClient, asset: Asset) -> GenericOutput:
    data = _gh(asset, "PUT",
               f"/orgs/{params.org}/teams/{params.team_slug}/memberships/{params.username}",
               installation_id=params.installation_id,
               json_body={"role": params.role})
    return GenericOutput(data=[data])


class RemoveTeamMemberParams(Params):
    org: str = Param(description="org", required=True)
    team_slug: str = Param(description="team slug", required=True)
    username: str = Param(description="username", required=True)
    installation_id: Optional[int] = Param(description="installation id", required=False)

@app.action(name="remove team member", identifier="remove_team_member",
            description="Remove a user from a team",
            action_type="contain", read_only=False)
def remove_team_member(params: RemoveTeamMemberParams, soar: SOARClient, asset: Asset) -> GenericOutput:
    _gh(asset, "DELETE",
        f"/orgs/{params.org}/teams/{params.team_slug}/memberships/{params.username}",
        installation_id=params.installation_id)
    return GenericOutput(data=[{"removed": params.username, "team": params.team_slug}])


# ---------- activity ----------

class UserEventsParams(Params):
    username: str = Param(description="username", required=True)
    installation_id: Optional[int] = Param(description="installation id", required=False)

@app.action(name="list user events", identifier="list_user_events",
            description="List public events performed by a user",
            action_type="investigate", read_only=True)
def list_user_events(params: UserEventsParams, soar: SOARClient, asset: Asset) -> GenericOutput:
    data = _paginate(asset, f"/users/{params.username}/events",
                     installation_id=params.installation_id)
    return GenericOutput(data=data, summary={"total": len(data)})


# ---------- deploy keys ----------

def _generate_ed25519_keypair(comment: str) -> tuple[str, str]:
    """Generate an ed25519 SSH keypair. Returns (openssh_public_key, openssh_private_key_pem)."""
    private = ed25519.Ed25519PrivateKey.generate()
    public_openssh = private.public_key().public_bytes(
        encoding=serialization.Encoding.OpenSSH,
        format=serialization.PublicFormat.OpenSSH,
    ).decode("ascii")
    private_openssh = private.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.OpenSSH,
        encryption_algorithm=serialization.NoEncryption(),
    ).decode("ascii")
    return f"{public_openssh} {comment}", private_openssh


class ProvisionDeployKeyParams(Params):
    owner: str = Param(description="owner", required=True)
    repo: str = Param(description="repo", required=True)
    title: str = Param(description="title", default="splunk-soar")
    read_only: bool = Param(description="read only", default=False)
    installation_id: Optional[int] = Param(description="installation id", required=False)

@app.action(name="provision deploy key", identifier="provision_deploy_key",
            description="Generate a fresh ed25519 SSH keypair, register the public key as a deploy key on the repository, and return the private key. The private key is only returned once — store it immediately.",
            action_type="generic", read_only=False)
def provision_deploy_key(params: ProvisionDeployKeyParams, soar: SOARClient, asset: Asset) -> GenericOutput:
    public_key, private_key = _generate_ed25519_keypair(
        comment=f"{params.title}@{params.owner}/{params.repo}"
    )
    result = _gh(asset, "POST",
                 f"/repos/{params.owner}/{params.repo}/keys",
                 installation_id=params.installation_id,
                 json_body={"title": params.title, "key": public_key,
                            "read_only": params.read_only})

    soar.set_message(
        f"Deploy key {result.get('id')} added to {params.owner}/{params.repo}. "
        f"Deploy keys do not expire. The private key was returned in the action result "
        f"and is NOT stored on the asset — back it up immediately."
    )

    return GenericOutput(
        data=[{
            "id": result.get("id"),
            "url": result.get("url"),
            "title": params.title,
            "public_key": public_key,
            "private_key": private_key,
            "ssh_uri": f"git@github.com:{params.owner}/{params.repo}.git",
            "read_only": params.read_only,
            "repo": f"{params.owner}/{params.repo}",
            "note": "Deploy keys do not expire. Private key is only returned once — store it immediately.",
        }],
        summary={
            "deploy_key_id": result.get("id"),
            "repo": f"{params.owner}/{params.repo}",
            "read_only": params.read_only,
            "title": params.title,
        },
    )


# ---------- mirror local SOAR repo to GitHub ----------

def _safe_filename(name: str) -> str:
    """Sanitize a SOAR object name into a filesystem-safe filename."""
    return "".join(c if c.isalnum() or c in ("-", "_", ".") else "_" for c in name).strip("_") or "unnamed"


def _walk_playbooks(root: Path) -> list[tuple[str, bytes]]:
    """Return (repo_relative_path, content_bytes) tuples for every file under
    /opt/phantom/scm/git/local/playbooks. Skips .git."""
    pb_root = root / PLAYBOOKS_SUBDIR
    if not pb_root.is_dir():
        logger.info("No playbooks directory found at %s", pb_root)
        return []
    out: list[tuple[str, bytes]] = []
    for dirpath, dirnames, filenames in os.walk(pb_root):
        dirnames[:] = [d for d in dirnames if d != ".git"]
        for name in filenames:
            full = Path(dirpath) / name
            rel = f"{PLAYBOOKS_SUBDIR}/{full.relative_to(pb_root).as_posix()}"
            try:
                out.append((rel, full.read_bytes()))
            except OSError as exc:
                logger.warning("Skipping %s: %s", full, exc)
    return out


def _soar_paginate(soar: SOARClient, path: str) -> list[dict]:
    """Walk a paginated SOAR REST endpoint that returns {data: [...], num_pages: N}.

    SOARClient.get() returns an httpx.Response, not a parsed dict — we must
    call .json() and .raise_for_status() ourselves.
    """
    out: list[dict] = []
    page = 0
    while True:
        resp = soar.get(path, params={"page": page, "page_size": SOAR_REST_PAGE_SIZE})
        resp.raise_for_status()
        body = resp.json() if resp.content else {}
        chunk = body.get("data", []) if isinstance(body, dict) else []
        out.extend(chunk)
        num_pages = body.get("num_pages", 1) if isinstance(body, dict) else 1
        page += 1
        if page >= num_pages or not chunk:
            break
    return out


def _fetch_custom_functions(soar: SOARClient) -> list[tuple[str, bytes]]:
    """Pull every custom function from /rest/custom_function as JSON files."""
    items = _soar_paginate(soar, "/rest/custom_function")
    out: list[tuple[str, bytes]] = []
    for item in items:
        name = _safe_filename(item.get("name") or str(item.get("id", "unknown")))
        out.append((
            f"custom_functions/{name}.json",
            json.dumps(item, indent=2, sort_keys=True).encode("utf-8"),
        ))
    return out


def _fetch_custom_lists(soar: SOARClient) -> list[tuple[str, bytes]]:
    """Pull every decided_list (custom list) plus its formatted content."""
    items = _soar_paginate(soar, "/rest/decided_list")
    out: list[tuple[str, bytes]] = []
    for item in items:
        list_id = item.get("id")
        name = _safe_filename(item.get("name") or str(list_id))
        try:
            resp = soar.get(f"/rest/decided_list/{list_id}/formatted_content")
            resp.raise_for_status()
            content = resp.json() if resp.content else None
        except Exception as exc:
            logger.warning("Failed to fetch content for list %s (%s): %s", name, list_id, exc)
            content = None
        payload = {"metadata": item, "content": content}
        out.append((
            f"custom_lists/{name}.json",
            json.dumps(payload, indent=2, sort_keys=True).encode("utf-8"),
        ))
    return out


class MirrorLocalRepoParams(Params):
    owner: str = Param(description="owner", required=True)
    repo: str = Param(description="repo", required=True)
    target_path: str = Param(description="target path", default="")  # subdirectory inside the GitHub repo; "" = repo root
    branch: str = Param(description="branch", default="main")
    commit_message: str = Param(description="commit message", default="Mirror SOAR playbooks, custom functions, and custom lists")
    source_path: str = Param(description="source path", default=LOCAL_SCM_PATH)
    create_branch_if_missing: bool = Param(description="create branch if missing", default=True)
    installation_id: Optional[int] = Param(description="installation id", required=False)

@app.action(
    name="mirror local repo to github",
    identifier="mirror_local_repo",
    description=(
        "Mirror SOAR playbooks, custom functions, and custom lists from this "
        "instance's local Git repo (default /opt/phantom/scm/git/local) into a "
        "target GitHub repo at the given path. Uses the GitHub Git Data API to "
        "create blobs, a tree, and a single commit on the target branch — "
        "atomic, no local clone needed."
    ),
    action_type="generic",
    read_only=False,
)
def mirror_local_repo(params: MirrorLocalRepoParams, soar: SOARClient, asset: Asset) -> GenericOutput:
    source = Path(params.source_path)

    # Gather files from all three sources
    items: list[tuple[str, bytes]] = []
    pb = _walk_playbooks(source)
    logger.info("Collected %d playbook file(s) from %s", len(pb), source / PLAYBOOKS_SUBDIR)
    items.extend(pb)

    cf = _fetch_custom_functions(soar)
    logger.info("Collected %d custom function(s) from /rest/custom_function", len(cf))
    items.extend(cf)

    cl = _fetch_custom_lists(soar)
    logger.info("Collected %d custom list(s) from /rest/decided_list", len(cl))
    items.extend(cl)

    if not items:
        raise RuntimeError(
            "Nothing to mirror — no playbooks, custom functions, or custom lists were found"
        )

    repo_base = f"/repos/{params.owner}/{params.repo}"

    # Resolve the parent commit (if the branch exists)
    parent_sha: Optional[str] = None
    base_tree_sha: Optional[str] = None
    branch_exists = True
    try:
        ref = _gh(asset, "GET", f"{repo_base}/git/ref/heads/{params.branch}",
                  installation_id=params.installation_id)
        parent_sha = ref["object"]["sha"]
        commit = _gh(asset, "GET", f"{repo_base}/git/commits/{parent_sha}",
                     installation_id=params.installation_id)
        base_tree_sha = commit["tree"]["sha"]
    except RuntimeError as e:
        if "404" not in str(e):
            raise
        branch_exists = False
        logger.info("Branch %s does not exist; will create it", params.branch)
        if not params.create_branch_if_missing:
            raise RuntimeError(
                f"Branch {params.branch} does not exist and create_branch_if_missing=false"
            )

    # Upload each item as a blob
    target_prefix = params.target_path.strip("/")
    tree_entries: list[dict] = []
    for rel_path, content_bytes in items:
        repo_path = f"{target_prefix}/{rel_path}" if target_prefix else rel_path
        blob = _gh(asset, "POST", f"{repo_base}/git/blobs",
                   installation_id=params.installation_id,
                   json_body={
                       "content": base64.b64encode(content_bytes).decode("ascii"),
                       "encoding": "base64",
                   })
        tree_entries.append({
            "path": repo_path,
            "mode": "100644",
            "type": "blob",
            "sha": blob["sha"],
        })

    if not tree_entries:
        raise RuntimeError("No files were uploadable")

    # Build the tree (based on existing tree if branch exists, so files outside
    # the target_path are preserved)
    tree_body: dict = {"tree": tree_entries}
    if base_tree_sha:
        tree_body["base_tree"] = base_tree_sha
    tree = _gh(asset, "POST", f"{repo_base}/git/trees",
               installation_id=params.installation_id, json_body=tree_body)

    # Create the commit
    commit_body: dict = {"message": params.commit_message, "tree": tree["sha"]}
    if parent_sha:
        commit_body["parents"] = [parent_sha]
    commit = _gh(asset, "POST", f"{repo_base}/git/commits",
                 installation_id=params.installation_id, json_body=commit_body)

    # Move (or create) the branch ref
    if branch_exists:
        _gh(asset, "PATCH", f"{repo_base}/git/refs/heads/{params.branch}",
            installation_id=params.installation_id,
            json_body={"sha": commit["sha"], "force": False})
    else:
        _gh(asset, "POST", f"{repo_base}/git/refs",
            installation_id=params.installation_id,
            json_body={"ref": f"refs/heads/{params.branch}", "sha": commit["sha"]})

    soar.set_message(
        f"Mirrored {len(tree_entries)} file(s) to {params.owner}/{params.repo}@{params.branch}"
        f"{' (created)' if not branch_exists else ''} at path '{target_prefix or '(root)'}' "
        f"({len(pb)} playbooks, {len(cf)} custom functions, {len(cl)} custom lists). "
        f"Commit: {commit['sha']}"
    )

    return GenericOutput(
        data=[{
            "commit_sha": commit["sha"],
            "commit_url": commit.get("html_url"),
            "branch": params.branch,
            "files_uploaded": len(tree_entries),
            "playbooks": len(pb),
            "custom_functions": len(cf),
            "custom_lists": len(cl),
            "target_path": target_prefix or "(root)",
            "source_path": str(source),
            "branch_created": not branch_exists,
        }],
        summary={
            "commit_sha": commit["sha"],
            "commit_url": commit.get("html_url"),
            "branch": params.branch,
            "branch_created": not branch_exists,
            "target_path": target_prefix or "(root)",
            "total_files": len(tree_entries),
            "playbooks": len(pb),
            "custom_functions": len(cf),
            "custom_lists": len(cl),
        },
    )


# ---------- SOAR source control ----------

class RegisterSourceControlParams(Params):
    name: str = Param(description="Display name for the SOAR source-control entry", required=True)
    uri: Optional[str] = Param(
        description="Git URI (required unless auto_provision_deploy_key is true with owner+repo, in which case it is auto-derived)",
        required=False,
    )
    branch: str = Param(description="Branch to track", default="main")

    # Mode A: bring your own credentials
    username: Optional[str] = Param(description="Username for HTTPS auth (optional)", required=False)
    password: Optional[str] = Param(description="Password or PAT for HTTPS auth (optional)", required=False, sensitive=True)
    private_key: Optional[str] = Param(description="SSH private key for deploy-key auth (optional)", required=False, sensitive=True)

    # Mode B: auto-provision a deploy key (requires owner + repo)
    auto_provision_deploy_key: bool = Param(
        description="Generate an ed25519 deploy key, register it on the target repo via the GitHub App, and hand the matching private key to SOAR",
        default=False,
    )
    owner: Optional[str] = Param(description="Repository owner (required when auto_provision_deploy_key=true)", required=False)
    repo: Optional[str] = Param(description="Repository name (required when auto_provision_deploy_key=true)", required=False)
    deploy_key_title: str = Param(description="Deploy key title shown in GitHub", default="splunk-soar")
    deploy_key_read_only: bool = Param(description="Create the deploy key as read-only", default=False)
    installation_id: Optional[int] = Param(description="Installation ID override (defaults to the asset's default_installation_id)", required=False)

@app.action(name="register source control", identifier="register_source_control",
            description="Register a Git repository with this SOAR instance's /rest/source_control. Set auto_provision_deploy_key=true (with owner + repo) to have the App generate an ed25519 deploy key, register it on the repo, and hand the matching private key to SOAR for long-lived sync.",
            action_type="generic", read_only=False)
def register_source_control(params: RegisterSourceControlParams, soar: SOARClient, asset: Asset) -> GenericOutput:
    uri = params.uri
    private_key = params.private_key
    provisioned: dict = {}

    if params.auto_provision_deploy_key:
        if not (params.owner and params.repo):
            raise ValueError("auto_provision_deploy_key=true requires both owner and repo")
        public_key, private_key = _generate_ed25519_keypair(
            comment=f"{params.deploy_key_title}@{params.owner}/{params.repo}"
        )
        key_resp = _gh(asset, "POST",
                       f"/repos/{params.owner}/{params.repo}/keys",
                       installation_id=params.installation_id,
                       json_body={"title": params.deploy_key_title, "key": public_key,
                                  "read_only": params.deploy_key_read_only})
        provisioned = {
            "deploy_key_id": key_resp.get("id"),
            "deploy_key_title": params.deploy_key_title,
            "deploy_key_read_only": params.deploy_key_read_only,
            "public_key": public_key,
            "repo": f"{params.owner}/{params.repo}",
        }
        uri = uri or f"git@github.com:{params.owner}/{params.repo}.git"
        logger.info("Provisioned deploy key %s on %s/%s", key_resp.get("id"), params.owner, params.repo)

    if not uri:
        raise ValueError("uri is required (or set auto_provision_deploy_key with owner + repo)")

    body: dict = {"name": params.name, "uri": uri, "branch": params.branch}
    if params.username:
        body["username"] = params.username
    if params.password:
        body["password"] = params.password
    if private_key:
        body["private_key"] = private_key

    resp = soar.post("/rest/source_control", json=body)
    resp.raise_for_status()
    try:
        out = resp.json() if resp.content else {"ok": True}
    except ValueError:
        out = {"ok": True}
    if not isinstance(out, dict):
        out = {"result": out}
    if provisioned:
        out["provisioned"] = provisioned

    if provisioned:
        soar.set_message(
            f"Registered '{params.name}' with SOAR source control using a freshly provisioned "
            f"deploy key (id={provisioned['deploy_key_id']}) on {provisioned['repo']}. "
            f"Branch: {params.branch}. Deploy keys do not expire."
        )
    else:
        soar.set_message(f"Registered '{params.name}' with SOAR source control. Branch: {params.branch}.")

    return GenericOutput(data=[out])


if __name__ == "__main__":
    app.cli()
