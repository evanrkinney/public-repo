# GitHub App connector for Splunk SOAR

A SOAR connector built on the [Splunk SOAR App SDK](https://phantomcyber.github.io/splunk-soar-sdk/api_reference.html) that authenticates **only** as a GitHub App. Every action mints a short-lived installation access token from a signed RS256 JWT — no PATs, no OAuth user tokens, no shared secrets to rotate by hand.

The connector covers three things in one place:
1. **GitHub App lifecycle** — creates the App via the manifest flow, captures the credentials, mints installation tokens automatically
2. **GitHub REST operations** — 30 actions covering repos, branches, files, pull requests, issues, collaborators, orgs/teams, activity, and deploy keys
3. **SOAR ↔ GitHub integration** — mirrors playbooks/custom functions/custom lists to a target repo, registers repos with SOAR's source-control endpoint, and ingests inbound GitHub webhooks as SOAR containers

## How it's built

This is **not** a classic BaseConnector app — there is no `githubapp.json` manifest file, no `BaseConnector` subclass, and no `connector.py`. The entire connector is one `app.py` file that uses the SOAR App SDK's decorators:

| concern | how it's expressed |
| --- | --- |
| App metadata (name, vendor, logos, FIPS, Python version) | `App(name=..., appid=..., logo=..., logo_dark=..., python_version=..., min_phantom_version=..., fips_compliant=...)` constructor at module top |
| Asset configuration fields | `class Asset(BaseAsset)` with `AssetField(description=..., default=..., sensitive=..., category=...)` |
| Action parameters | Per-action `class XxxParams(Params)` with `Param(description=..., required=..., default=...)` |
| Action handlers | `@app.action(name=..., identifier=..., description=..., action_type=..., read_only=...)` decorators |
| Test connectivity | `@app.test_connectivity()` |
| Inbound webhooks | `@app.webhook(url_pattern, allowed_methods=[...])` (requires `app.enable_webhooks()` once at module load) |

The SDK reads everything it needs from those decorators and class definitions to generate the SOAR app package. There is nothing to keep in sync between Python and JSON.

## Onboarding

`test connectivity` is the entire onboarding wizard. The first time you run it on a fresh asset:

1. Builds a GitHub App **manifest URL** that pre-declares default permissions, event subscriptions, and the inbound webhook URL (`hook_attributes`)
2. Logs the URL — open it in a browser, click **Create GitHub App**
3. The connector's `result` webhook receives `?code=` → exchanges it for `app_id`, `pem`, `webhook_secret` and writes them back to the asset
4. The browser is redirected to **install** the new App on the target user/org → the same `result` webhook receives `?installation_id=` → also written back to the asset
5. Connector mints an installation token to verify everything works
6. (Optional, if `register_with_soar=true`) Calls this SOAR's `/rest/source_control` to register a repo for playbook sync
7. (Optional, if `notify_enabled=true` and `notify_on_onboard=true`) Sends a notification email with the App ID, slug, install URL, and the **PEM-backup warning**

Subsequent runs see the stored credentials and just re-mint a token to verify they still work.

The PEM is stored on the asset as a sensitive field. **Back it up out-of-band** (vault, password manager) — GitHub does not show it again, and if SOAR's database is lost you cannot recover it.

## Asset configuration

All fields are declared in the `Asset` class at the top of `app.py` using `AssetField(...)`. The SOAR UI renders them grouped by `category`.

### Connectivity

| field | type | required | default | notes |
| --- | --- | --- | --- | --- |
| `github_api_url` | string | yes | `https://api.github.com` | Use `https://<ghes>/api/v3` for GHES |
| `app_name` | string | yes | `splunk-soar-github-app` | Display name for the GitHub App that test_connectivity creates |
| `organization` | string | no |  | Org login. Omit to create the App under the authenticated user |
| `verify_server_cert` | bool | yes | true | TLS verification on outbound GitHub calls |

### Populated automatically by `test_connectivity`

You don't fill these in — they're written by the manifest flow. They're listed here so you know what's stored and where to look.

| field | type | sensitive |
| --- | --- | --- |
| `app_id` | string | no |
| `private_key` | string | **yes** (PEM) |
| `webhook_secret` | string | **yes** |
| `default_installation_id` | int | no |

### SOAR source-control onboarding (optional)

| field | type | default | notes |
| --- | --- | --- | --- |
| `register_with_soar` | bool | false | If true, `test_connectivity` also POSTs to `/rest/source_control` |
| `soar_repo_uri` | string |  | e.g. `git@github.com:owner/repo.git` |
| `soar_repo_branch` | string | `main` | |
| `soar_source_control_name` | string |  | Display name in SOAR's source control UI |

### Notifications (optional)

Notifications go through SOAR's built-in `/rest/notification` endpoint, which uses the SMTP server configured under **Administration → Email Settings**. No new credentials live on the asset.

| field | type | default | notes |
| --- | --- | --- | --- |
| `notify_enabled` | bool | false | Master switch |
| `notify_recipients` | string |  | Comma-separated email addresses |
| `notify_on_onboard` | bool | true | Email when the manifest flow completes — includes PEM backup reminder |
| `notify_on_deploy_key` | bool | true | Email on every `provision deploy key` (and `register source control` with auto-provision) |
| `notify_on_mirror` | bool | false | Email on every successful `mirror local repo to github` (off by default — can be chatty) |

## Actions (31)

| group | actions |
| --- | --- |
| onboarding | `test connectivity` |
| installations | `list installations` |
| repos | `list repos`, `get repo`, `create repo`, `delete repo` |
| branches & files | `list branches`, `create branch`, `get file`, `create or update file`, `delete file` |
| pull requests | `list pull requests`, `create pull request`, `merge pull request` |
| issues | `list issues`, `get issue`, `create issue`, `update issue`, `list issue comments`, `create issue comment`, `add issue labels` |
| collaborators | `add collaborator`, `remove collaborator` |
| orgs / teams | `list org members`, `list org teams`, `add team member`, `remove team member` |
| activity | `list user events` |
| SOAR sync | `mirror local repo to github`, `provision deploy key`, `register source control` |

### Renames vs. the legacy `splunk-soar-connectors/github` connector

| legacy | new |
| --- | --- |
| `list users` | `list org members` |
| `list events` | `list user events` |
| `list teams` | `list org teams` |
| `list comments` | `list issue comments` |
| `add labels` | `add issue labels` |
| `add member` / `remove member` | `add team member` / `remove team member` |
| `list organizations` | `list installations` (the App-native equivalent) |

### What I dropped from the legacy `splunk-soar-connectors/git` connector

Everything that operated on a local working directory: `clone repo`, `delete repo` (local), `git status`, `git checkout`, `git pull`, `git push`, `git commit`, `add file`, `update file`, `delete file` (local), `on poll`. The GitHub REST API replaces all of them — `create branch`, `create or update file`, `delete file`, `create pull request`, `merge pull request` cover the same workflows without ever cloning a repo.

### `mirror local repo to github` — what gets mirrored

The action pulls from three different sources, each via the right channel for that data type:

| content | source | committed to |
| --- | --- | --- |
| **playbooks** | filesystem walk of `/opt/phantom/scm/git/local/playbooks` | `playbooks/<original tree>` |
| **custom functions** | `GET /rest/custom_function` (paginated) | `custom_functions/<sanitized name>.json` |
| **custom lists** | `GET /rest/decided_list` then `GET /rest/decided_list/<id>/formatted_content` for each | `custom_lists/<sanitized name>.json` (`{metadata, content}` envelope) |

Everything is gathered into one in-memory list, blob-uploaded to GitHub, packed into a single tree (with `base_tree` so unrelated files in the target repo are preserved), and committed atomically via the GitHub Git Data API. No local clone, no shelling out to `git`.

### `provision deploy key` and `register source control`

Use these together for long-lived SOAR ↔ GitHub sync:

- `provision deploy key` generates an ed25519 keypair, registers the public key on the repo via the GitHub App, and returns both keys (the private key is only returned once — store it immediately).
- `register source control` with `auto_provision_deploy_key=true` (and `owner` + `repo`) does the whole thing in one shot: provisions the deploy key, derives the SSH URI, and POSTs the matching private key to SOAR's `/rest/source_control`.

Deploy keys don't expire, so this is the right pattern for ongoing playbook sync. Installation tokens (which `_installation_token` mints internally for the API actions) only last 1 hour and would be unsuitable for SOAR's source control sync, which doesn't auto-refresh.

## GitHub event ingestion (incoming webhooks)

The connector includes a **second SOAR webhook endpoint** at `app.get_webhook_url("github_event")` that receives signed event deliveries from the GitHub App and turns each one into a SOAR container.

### How it gets wired up

`test_connectivity` writes the event webhook URL into the manifest's `hook_attributes`, so when you click "Create GitHub App" the App is created with **Webhook → Active** already enabled, the **Webhook URL** pre-filled with the SOAR endpoint, and the **Secret** automatically generated by GitHub. The secret is returned by the manifest conversion step and stored on the asset as `webhook_secret`. No manual configuration in the GitHub App settings page is required.

If you ever need to rotate the secret manually in the GitHub App settings, paste the new value into the asset's `webhook_secret` field.

### What the receiver does on each delivery

1. Reads `X-Hub-Signature-256`, `X-GitHub-Event`, `X-GitHub-Delivery` from the request headers
2. Verifies the HMAC-SHA256 signature against `asset.webhook_secret` using `hmac.compare_digest` (constant-time). Mismatches return `401`.
3. Special-cases the `ping` event GitHub sends on initial webhook setup — responds `pong` without creating a container, so the GitHub UI's "Recent Deliveries" page shows green.
4. Parses the JSON payload, extracts a per-event-type summary and CEF field set
5. Calls `request.soar.container.create(...)` with `label=github_event`, `source_data_identifier=<delivery id>`, and a name like `GitHub pull_request.opened: #42 Fix the thing`
6. Calls `request.soar.artifact.create(...)` with `run_automation=True`, the extracted CEF fields, and the full GitHub payload in `data`. Active playbooks listening on the `github_event` label fire immediately.
7. Returns `202 Accepted` to GitHub with the new container ID

### Subscribing playbooks

Configure any active playbook with the `github_event` container label, then read the artifact CEF fields. Each event type populates a different set:

| event | CEF fields you can branch on |
| --- | --- |
| `issues` | `repo`, `sender`, `action`, `issue_number`, `issue_title`, `issue_state`, `issue_url` |
| `issue_comment` | `repo`, `sender`, `action`, `issue_number`, `issue_title`, `comment_id`, `comment_url` |
| `pull_request` | `repo`, `sender`, `action`, `pr_number`, `pr_title`, `pr_state`, `pr_url`, `pr_head`, `pr_base` |
| `push` | `repo`, `sender`, `ref`, `commit_count`, `head_commit`, `before`, `after` |
| anything else | `repo`, `sender` (the full payload is still in artifact `data`) |

Add more event types by editing `_summarize_github_event` in `app.py`. The default subscription set in the manifest is `issues, issue_comment, pull_request, push`; expand it via `default_events` in `_build_manifest_url` if you want more.

### Reachability requirement

GitHub.com posts deliveries from a published [IP range](https://api.github.com/meta) and needs to reach the SOAR webhook URL. If your SOAR instance is behind a firewall, either:

- Allow the GitHub IP range through to the SOAR ingest endpoint, or
- Put a tunnel/relay (Cloudflare Tunnel, ngrok, AWS API Gateway proxy) in front of the webhook URL and update `hook_attributes.url` in `_build_manifest_url` to point at the public side.

For SOAR Cloud, the webhook URL `app.get_webhook_url(...)` returns is already publicly reachable and signed — nothing extra to do.

## Splunk-side rotation reminders

The connector is event-driven — it can email you the moment the App is onboarded or a deploy key is provisioned (via the `notify_*` asset fields), but it deliberately does not run cron logic. For the **"remind me before this thing goes stale"** use case, the right tool is a Splunk saved search running against the SOAR data forwarded into Splunk by the [SOAR data forwarders](https://help.splunk.com/en/splunk-soar/soar-cloud/administer-soar-cloud/configure-administration-settings-in-splunk-soar-cloud/configure-forwarders-to-send-soar-data-to-your-splunk-deployment).

### Where the data lives

The SOAR data forwarders ship each data type into its own dedicated index:

| SOAR data type | Target index | What it contains |
| --- | --- | --- |
| Action run | `phantom_action_run` | Structured JSON event per `act` invocation: action name, app, asset, status, message, parameters, results, timestamps |
| App run | `phantom_app_run` | Structured JSON per app-level invocation (one parent → many `phantom_action_run` children) |
| SOAR logs | `splunk_app_soar` | Free-text daemon/actiond/spawn logs (fallback if you need raw `logger.*` output) |
| Audit log | `_audit` | SOAR audit events (logins, asset edits, etc.) |

Action runs are structured, so the searches below filter by real fields instead of regex'ing log lines. **You only need the SOAR forwarder for the `phantom_action_run` data type** — the system-log forwarder is not required for these alerts.

### Prerequisites

1. The SOAR forwarder is configured and shipping action run data into Splunk. Verify with `| tstats count where index=phantom_action_run`.
2. Splunk Enterprise's **email alert action** is configured (Settings → Server settings → Email settings).

### What's actually worth alerting on

| concern | reality | useful alert? |
| --- | --- | --- |
| Installation token expires every 1 hour | Auto-refreshed by the connector on every action call | ❌ no |
| Deploy keys provisioned by `provision deploy key` | Never expire on their own | ❌ no |
| GitHub App PEM stored on the asset | Never expires unless manually rotated, but **you** may want a hygiene reminder to rotate it (e.g. every 180 days) | ✅ scheduled reminder based on the last successful `test connectivity` |
| GitHub App PEM revoked or rotated externally | Connector raises `Installation token mint failed (401)` | ✅ alert on the failed action run |
| Deploy key deleted out from under SOAR | SOAR source-control sync errors land in `actiond.log` | ✅ alert on source-control errors |

### Field schema

`phantom_action_run` events are JSON-shaped, so the fields below should be auto-extracted by Splunk's `KV_MODE=json` or surfaced through the SOAR data model:

| field | meaning |
| --- | --- |
| `action` | Action name (e.g. `test connectivity`, `provision deploy key`, `mirror local repo to github`) |
| `_pretty_app` / `app` | App package name (`githubapp`) |
| `_pretty_asset` / `asset` | Asset display name |
| `status` | `success`, `failed`, or `running` |
| `message` | Action's status message — where the connector's `RuntimeError` text and `set_message(...)` content land |
| `start_time` / `end_time` | ISO timestamps (`_time` is set from `start_time`) |

If your forwarder uses different keys (older versions sometimes flatten differently), run `index=phantom_action_run app=githubapp | head 1` and adjust the field references.

### Saved search 1 — PEM rotation hygiene reminder

Finds the most recent successful `test connectivity` per asset (the canonical "this asset has working credentials" marker), calculates days since, and fires when it crosses the warning threshold.

```spl
index=phantom_action_run app=githubapp action="test connectivity" status=success
| stats max(_time) as last_success by asset
| eval days_since=round((now() - last_success)/86400, 1)
| eval rotate_after_days=180, warn_at_days=150
| where days_since >= warn_at_days
| eval rotate_in_days=rotate_after_days - days_since
| eval last_success_human=strftime(last_success, "%Y-%m-%d %H:%M:%S")
| table asset last_success_human days_since rotate_in_days
| sort - days_since
```

Schedule weekly. Adjust `rotate_after_days` / `warn_at_days` to taste; 180/150 gives you a 30-day runway before a 6-month rotation.

> The 180-day rotation is a **hygiene policy**, not a hard expiry. GitHub App PEMs do not auto-expire — this search fires because *you* haven't rotated in a while, not because GitHub is about to reject the key. To clear the alert, either re-run `test connectivity` after onboarding a fresh App, or rotate the PEM in the GitHub App settings page and update the asset.

### Saved search 2 — credential failure detector

Fires when GitHub starts rejecting the credentials, regardless of which connector action was running. The connector raises `Installation token mint failed (<status>): ...` and `GitHub <method> <path> -> <status>: ...` on auth failures, both of which land in the action run's `message` field.

```spl
index=phantom_action_run app=githubapp status=failed
    (message="*Installation token mint failed*"
     OR message="*-> 401*"
     OR message="*-> 403*"
     OR message="*Bad credentials*")
| stats count
        latest(_time) as last_seen
        latest(message) as last_error
        values(action) as actions
        by asset
| eval last_seen_human=strftime(last_seen, "%Y-%m-%d %H:%M:%S")
| table asset actions count last_seen_human last_error
| sort - last_seen
```

Schedule every 10 minutes over a 15-minute window. Any result is actionable.

### Saved search 3 — mirror health (optional)

Inverts "successful `mirror local repo to github` in the last 24h" into a quiet-failure alarm. Skip if you're not running mirrors on a schedule.

```spl
| tstats latest(_time) as last_mirror where
    index=phantom_action_run app=githubapp
    action="mirror local repo to github" status=success
    by asset
| eval hours_since=round((now() - last_mirror)/3600, 1)
| where hours_since > 24
| eval last_mirror_human=strftime(last_mirror, "%Y-%m-%d %H:%M:%S")
| table asset last_mirror_human hours_since
```

### `savedsearches.conf` stanzas

Drop these into `$SPLUNK_HOME/etc/apps/<your-app>/local/savedsearches.conf`, or create them through Settings → Searches, reports, and alerts → New Alert.

```conf
[GitHub App - PEM Rotation Reminder]
search = index=phantom_action_run app=githubapp action="test connectivity" status=success | stats max(_time) as last_success by asset | eval days_since=round((now() - last_success)/86400, 1) | eval rotate_after_days=180, warn_at_days=150 | where days_since >= warn_at_days | eval rotate_in_days=rotate_after_days - days_since | eval last_success_human=strftime(last_success, "%Y-%m-%d %H:%M:%S") | table asset last_success_human days_since rotate_in_days
dispatch.earliest_time = -200d@d
dispatch.latest_time   = now
cron_schedule          = 0 8 * * 1
enableSched            = 1
counttype              = number of events
relation               = greater than
quantity               = 0
alert.track            = 1
alert.severity         = 3
action.email           = 1
action.email.to        = soar-admins@example.com
action.email.subject   = [SOAR] GitHub App PEM rotation reminder — $result.asset$
action.email.message.alert = SOAR asset $result.asset$ has not had a successful 'test connectivity' against the githubapp connector in $result.days_since$ days, which exceeds the configured rotation window. Re-run 'test connectivity' to provision a fresh App, or rotate the existing PEM in GitHub App settings and update the asset. See https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/managing-private-keys-for-github-apps.

[GitHub App - Credential Failure]
search = index=phantom_action_run app=githubapp status=failed (message="*Installation token mint failed*" OR message="*-> 401*" OR message="*-> 403*" OR message="*Bad credentials*") | stats count latest(_time) as last_seen latest(message) as last_error values(action) as actions by asset | eval last_seen_human=strftime(last_seen, "%Y-%m-%d %H:%M:%S") | table asset actions count last_seen_human last_error | sort - last_seen
dispatch.earliest_time = -15m
dispatch.latest_time   = now
cron_schedule          = */10 * * * *
enableSched            = 1
counttype              = number of events
relation               = greater than
quantity               = 0
alert.track            = 1
alert.severity         = 5
action.email           = 1
action.email.to        = soar-admins@example.com
action.email.subject   = [SOAR] GitHub App credential failure on $result.asset$
action.email.message.alert = SOAR asset $result.asset$ is failing to authenticate against GitHub. Likely causes: (1) the App's private key was rotated or revoked, (2) the App was uninstalled from the target account, or (3) a deploy key was removed from the target repo. Re-run 'test connectivity' on the affected asset to re-onboard. Last error: $result.last_error$

[GitHub App - Mirror Stale]
search = | tstats latest(_time) as last_mirror where index=phantom_action_run app=githubapp action="mirror local repo to github" status=success by asset | eval hours_since=round((now() - last_mirror)/3600, 1) | where hours_since > 24 | eval last_mirror_human=strftime(last_mirror, "%Y-%m-%d %H:%M:%S") | table asset last_mirror_human hours_since
dispatch.earliest_time = -36h
dispatch.latest_time   = now
cron_schedule          = 0 */6 * * *
enableSched            = 1
counttype              = number of events
relation               = greater than
quantity               = 0
alert.track            = 1
alert.severity         = 3
action.email           = 1
action.email.to        = soar-admins@example.com
action.email.subject   = [SOAR] GitHub App mirror stale on $result.asset$
action.email.message.alert = SOAR asset $result.asset$ has not run a successful 'mirror local repo to github' in $result.hours_since$ hours. Check the playbook scheduler or the action run history.
```

### Tying it back to the connector's own notifications

The connector and Splunk complement each other:

- **Connector `notify_on_onboard`** — instant, single-shot, emailed the moment the App is provisioned with the PEM-backup warning.
- **Splunk saved search 1** — periodic, fires *months later* based on the most recent successful `test connectivity` action run, giving you a rolling rotation reminder.
- **Connector `notify_on_deploy_key`** — instant trail of every deploy key the App provisions.
- **Splunk saved search 2** — fires when GitHub actually starts rejecting the credentials, regardless of which action triggered it. This is the alarm you actually want — the connector cannot warn you ahead of time about a key it doesn't know is broken.

Use both. The connector tells you what *just happened*; Splunk tells you what *should be happening but isn't*.

## Notes

- All permissions and event subscriptions are declared in `_build_manifest_url` in `app.py`. Default permissions: `administration:write`, `contents:write`, `issues:write`, `members:write`, `metadata:read`, `pull_requests:write`. Default event subscriptions: `issues`, `issue_comment`, `pull_request`, `push`. Tighten before production use.
- Installation tokens are cached on `asset.auth_state[TOKEN_CACHE_KEY]` and refreshed 60 s before expiry. The cache survives between action runs because `auth_state` is a persistent property on `BaseAsset`.
- Action handlers return a single `GenericOutput(ActionOutput)` shape (`data: list, summary: Optional[dict]`). For SOAR UI column rendering on a specific action, subclass `GenericOutput`, add `OutputField` declarations for the keys you care about, and pass `output_class=YourOutput` to that action's `@app.action(...)` decorator.
- The `result` webhook handles **both legs** of the GitHub App manifest flow (the `?code=` from creation and the `?installation_id=` from installation) by inspecting which query param is present.
- The `github_event` webhook verifies HMAC-SHA256 signatures with `hmac.compare_digest` and special-cases the GitHub `ping` event so the GitHub UI's "Recent Deliveries" page shows green on first hookup.

## Files

```
githubapp/
├── app.py                # entire connector (App SDK style — no JSON manifest)
├── requirements.txt      # splunk-soar-sdk, PyJWT, cryptography, requests
├── logo.svg              # GitHub lockup, black
├── logo_dark.svg         # GitHub lockup, white
└── README.md             # this file
```

There is **no `githubapp.json`** — the SOAR App SDK reads all the metadata it needs from the `App(...)` constructor call, the `Asset` class, the `Params` subclasses, and the `@app.action` / `@app.test_connectivity` / `@app.webhook` decorators in `app.py`. If you're used to the classic `BaseConnector` model where actions are declared twice (once in JSON, once in Python) and have to be kept in sync — that's gone.
