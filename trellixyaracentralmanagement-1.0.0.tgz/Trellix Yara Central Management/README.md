# Trellix Yara Central Management (Splunk SOAR)

A focused Splunk SOAR app, built on the **Splunk SOAR SDK 3.x**, for
uploading YARA rule files from the SOAR Vault to a Trellix (formerly
FireEye) Central Management (CM) appliance via the NX `customioc/yara`
API.

This app does one thing well: take YARA files out of the Vault and push
them onto a CM appliance. It deliberately does **not** include alert
ingestion, email quarantine management, or other CM functions — if you
need those, use the standalone Trellix / FireEye apps.

---

## Actions

| Action              | Type    | Description                                                                                                       |
| ------------------- | ------- | ----------------------------------------------------------------------------------------------------------------- |
| `test connectivity` | test    | Validate the configured CM credentials, network reachability, and TLS.                                            |
| `upload yara`       | generic | Upload a single YARA file from the Vault to the CM appliance.                                                     |
| `upload all yaras`  | generic | Upload every YARA file (`.yar` / `.yara` / `.yr`) in a container's Vault to the CM appliance; non-YARA is skipped. |

---

## Asset configuration

| Field          | Required | Sensitive | Default | Notes                                                                                                                                                                                                                                                            |
| -------------- | -------- | --------- | ------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `server_url`   | yes      | no        | —       | Base URL of the CM appliance (e.g. `https://cm.example.com`). Must include scheme. Should be the appliance root — the API base path `/wsapis/v2.0.0` is appended automatically.                                                                                  |
| `username`     | yes      | no        | —       | CM account username. Must hold the `api_admin` or `api_analyst` role on the appliance for YARA uploads to be accepted.                                                                                                                                          |
| `password`     | yes      | yes       | —       | CM account password.                                                                                                                                                                                                                                              |
| `client_token` | no       | yes       | —       | Optional `X-FeClient-Token` value (sent in addition to the session `X-FeApi-Token` if configured).                                                                                                                                                                |
| `verify_ssl`   | no       | no        | `false` | Enforce TLS certificate validation. Leave off if the appliance uses a self-signed or internal-CA certificate.                                                                                                                                                     |
| `http_proxy`   | no       | no        | —       | Outbound proxy URL (e.g. `http://proxy.internal:3128`). If empty, the app bypasses any system proxy and connects to the CM appliance directly. Set this *only* if the appliance must be reached via an explicit forward proxy.                                  |

### Networking note: env-var proxies are ignored

The SOAR worker sometimes has `HTTP_PROXY` / `HTTPS_PROXY` set in its
environment for the appliance's own outbound Internet traffic. Python's
`requests` library reads those env vars by default, which would send CM
traffic through an Internet egress proxy that almost certainly can't
route to your internal CM appliance — symptom: `test connectivity`
hangs.

This app explicitly **does not** trust environment proxies
(`requests.Session.trust_env = False`). If you actually need a forward
proxy in front of CM, set the asset's `http_proxy` field. The log will
warn you when env-var proxies are present but being ignored.

---

## YARA endpoint

Uploads are sent to the NX `customioc/yara/add` endpoint:

```
POST {server_url}/wsapis/v2.0.0/customioc/yara/add/{file_type}
X-FeApi-Token: <session token from POST /wsapis/v2.0.0/auth/login>
Content-Type: multipart/form-data
  file=<YARA file content>
```

The session token is acquired transparently by the action: the asset's
`username` / `password` (and optional `client_token`) are exchanged for
an `X-FeApi-Token` for the duration of the call, then released via
`/wsapis/v2.0.0/auth/logout`.

### Permitted `file_type` values

From the NX `customioc/yara` taxonomy:

- `callback_domain`
- `domain_match`
- `exploit`
- `infection_match`
- `malware_callback`
- `malware_object`
- `uri_match`

The uploaded YARA rule file must match the chosen `file_type` — for
example, rules detecting malware payloads should be uploaded as
`malware_object`. Sending a malware-style rule with `file_type =
callback_domain` will be rejected by the appliance.

---

## Action: `upload yara`

| Parameter   | Type   | Required | Description                                                                                            |
| ----------- | ------ | -------- | ------------------------------------------------------------------------------------------------------ |
| `vault_id`  | string | yes      | Vault ID of the YARA file. Filename must end in `.yar/.yara/.yr`.                                      |
| `file_type` | string | yes      | YARA file type recognized by the appliance. Used as the URL path segment. The file's rules must match. |

Output:

| Field            | Type           | Description                                          |
| ---------------- | -------------- | ---------------------------------------------------- |
| `vault_id`       | string         | The vault_id that was uploaded.                      |
| `file_name`      | string         | The vault file's filename.                           |
| `file_type`      | string         | The `file_type` URL segment used.                    |
| `http_status`    | numeric        | HTTP status code returned by the appliance.          |
| `response_body`  | string (≤500c) | First 500 chars of the appliance's response body.    |

## Action: `upload all yaras`

| Parameter      | Type    | Required | Description                                                              |
| -------------- | ------- | -------- | ------------------------------------------------------------------------ |
| `file_type`    | string  | yes      | YARA file type. Same value list as `upload yara`. Applies to every file. |
| `container_id` | numeric | no       | Container to scan for YARA files. Defaults to the executing container.   |

Enumerates every Vault item in the container, uploads each one whose
filename ends in a YARA extension, skips everything else.

Output:

| Field                 | Type     | Description                                                          |
| --------------------- | -------- | -------------------------------------------------------------------- |
| `file_type`           | string   | The `file_type` URL segment used.                                    |
| `container_id`        | numeric  | Container that was enumerated.                                       |
| `uploaded_count`      | numeric  | Number of YARA files successfully uploaded.                          |
| `failed_count`        | numeric  | Number of YARA files the appliance rejected.                         |
| `skipped_count`       | numeric  | Number of non-YARA files in the container (skipped).                 |
| `uploaded_vault_ids`  | list     | Vault IDs of successfully uploaded files.                            |
| `failed_vault_ids`    | list     | Vault IDs of failed uploads.                                         |
| `skipped_vault_ids`   | list     | Vault IDs that were skipped (filename did not end in `.yar/.yara/.yr`). |

---

## Test connectivity behavior

`test connectivity` runs in this order, logging every step at WARNING
level so it survives in the SOAR spawn debug log:

1. Validates each asset field (`server_url`, `username`, `password`) is set.
2. Parses `server_url` — fails fast on missing scheme, unsupported scheme, no host.
3. Reports the resolved proxy state (asset-level vs. env-level).
4. **DNS probe** (`socket.getaddrinfo` with 15 s timeout) on the appliance hostname. If DNS fails you get a specific `DNS lookup failed for 'host': ...` instead of waiting 60 s.
5. Posts to `/wsapis/v2.0.0/auth/login` with 15 s connect / 60 s read timeout.
6. Validates a 2xx response and an `X-FeApi-Token` header.
7. Releases the token via `/auth/logout`.

Every failure mode produces a clean one-line error message in the SOAR
action result UI (`Action failure: ...` / `Asset misconfiguration:
...`), **not** a Python traceback:

| Failure                                         | Message                                                                                                                                                                                                                       |
| ----------------------------------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Missing asset field                             | `Asset misconfiguration: Asset 'server_url' is required.`                                                                                                                                                                     |
| Malformed `server_url`                          | `Asset misconfiguration: server_url 'cm.example.com' is missing a scheme.`                                                                                                                                                    |
| DNS doesn't resolve hostname                    | `Action failure: DNS lookup failed for 'cm.example.com': ... Verify the server_url is correct and that the SOAR worker can reach a DNS server that knows about this appliance.`                                              |
| TLS verification fails (with `verify_ssl=True`) | `Action failure: TLS certificate verification failed for cm.example.com: ... set the asset's 'verify_ssl' to False (or install the appliance CA on the SOAR worker).`                                                          |
| TCP connect times out                           | `Action failure: Connection to cm.example.com timed out after 15s (connecting via the appliance directly (no proxy)): ...`                                                                                                    |
| Proxy intercepts traffic                        | `Action failure: A proxy intercepted the connection ... Either set the asset's 'http_proxy' to the correct proxy URL, or have your network team allow direct egress from the SOAR worker to the CM appliance.`               |
| Bad credentials                                 | `Action failure: CM login failed: HTTP 401. Body: {"error":"unauthorized"}`                                                                                                                                                   |
| URL points to wrong endpoint (200 + HTML)       | `Action failure: CM login succeeded (HTTP 200) but no 'X-FeApi-Token' header in the response. The appliance may have returned a login page — check that the URL points to the CM API root and that the user has the api_admin or api_analyst role.` |

---

## Build & install

```bash
# Generate the dependency lock file (only needed once, or after editing pyproject.toml).
uv lock

# Build the .tgz package.
python3 package_build.py package build . -o trellixyaracentralmanagement-1.0.0.tgz
```

`package_build.py` does two things on top of `soarapps package build`:

1. **Strips unused transitive deps** from the SDK (`extract-msg` chain,
   OAuth chain, Windows-only wheels, CLI-only deps) — keeps the bundle
   small.
2. **Injects a legacy-spawn shim** at the package root
   (`phantom_trellixyaracentralmanagement_connector.py`) so SOAR
   builds still using the pre-SDK-3.x spawn
   (`BaseConnector.__subclasses__()[0]`) can launch the app. Newer SOAR
   builds dispatch directly through the manifest's `main_module` field
   and never touch the shim.

Install via SOAR UI → **Apps** → **Install App from a file**.

---

## Implementation

The entire app is defined in [src/app.py](src/app.py):

- `Asset(BaseAsset)` declares the six asset fields.
- `_CMSession` is a `requests.Session` wrapper that handles login,
  logout, and YARA uploads. `trust_env=False` is set so environment
  proxy variables are ignored unless `http_proxy` is set on the asset.
- `@app.test_connectivity()` performs the asset validation + DNS probe
  + login round-trip with structured logging and `ActionFailure` /
  `AssetMisconfiguration` for every failure mode.
- `@app.action(name="upload yara", ...)` and
  `@app.action(name="upload all yaras", ...)` implement the two upload
  flows.
- `_vault_get` / `_vault_list_container` are thin wrappers around
  `soar.vault.get_attachment` returning plain dicts so the action code
  doesn't deal with `VaultAttachment` directly.
