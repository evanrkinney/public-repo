"""Trellix Yara Central Management - Splunk SOAR SDK app.

A focused app that uploads YARA rule files from the SOAR Vault to a
Trellix (formerly FireEye) Central Management (CM) appliance via the
NX customioc/yara/add endpoint.

Actions:
  - test connectivity
  - upload yara         (single Vault file)
  - upload all yaras    (every YARA file in a container's Vault)
"""

import os
import socket
import traceback
from urllib.parse import urlparse

import requests
from soar_sdk.abstract import SOARClient
from soar_sdk.action_results import ActionOutput, OutputField
from soar_sdk.app import App
from soar_sdk.asset import AssetField, BaseAsset
from soar_sdk.exceptions import ActionFailure, AssetMisconfiguration
from soar_sdk.logging import getLogger
from soar_sdk.params import Param, Params


logger = getLogger()
logger.info("trellixyaracentralmanagement module loading.")


# ---------------------------------------------------------------------------
# CM API endpoints + protocol constants
# ---------------------------------------------------------------------------

CM_BASE_PATH = "/wsapis/v2.0.0"
CM_AUTH_LOGIN_URL = f"{CM_BASE_PATH}/auth/login"
CM_AUTH_LOGOUT_URL = f"{CM_BASE_PATH}/auth/logout"
CM_YARA_UPLOAD_URL = f"{CM_BASE_PATH}/customioc/yara/add"

CM_TOKEN_HEADER = "X-FeApi-Token"
CM_CLIENT_TOKEN_HEADER = "X-FeClient-Token"

_USER_AGENT = "splunk-soar-trellixyaracentralmanagement/1.0"

# (connect, read) timeouts in seconds. Short connect timeout so a wedged
# proxy/firewall surfaces as a fast failure instead of hanging on TCP.
_CONNECT_TIMEOUT = 15
_READ_TIMEOUT = 60
_LOGIN_TIMEOUT = (_CONNECT_TIMEOUT, _READ_TIMEOUT)

YARA_FILE_EXTENSIONS = (".yar", ".yara", ".yr")
YARA_FILE_TYPES = [
    "callback_domain",
    "domain_match",
    "exploit",
    "infection_match",
    "malware_callback",
    "malware_object",
    "uri_match",
]


# ---------------------------------------------------------------------------
# Asset
# ---------------------------------------------------------------------------


class Asset(BaseAsset):
    server_url: str = AssetField(
        description="CM Server URL (e.g. https://cm.example.com).",
    )
    username: str = AssetField(
        description="CM Username.",
    )
    password: str = AssetField(
        description="CM Password.",
        sensitive=True,
    )
    client_token: str | None = AssetField(
        description="CM Client Token (optional X-FeClient-Token).",
        sensitive=True,
        default=None,
    )
    verify_ssl: bool = AssetField(
        description="Verify SSL Certificate.",
        default=False,
    )
    http_proxy: str | None = AssetField(
        description=(
            "Optional outbound proxy URL (e.g. http://proxy.internal:3128). "
            "If empty, the app bypasses any system proxy and connects to the "
            "CM appliance directly. Set this ONLY if the appliance must be "
            "reached via an explicit forward proxy."
        ),
        default=None,
    )


app = App(
    asset_cls=Asset,
    name="Trellix Yara Central Management",
    appid="644f14b5-40c2-4648-9e34-c65d148ec206",
    app_type="generic",
    product_vendor="Trellix",
    product_name="Trellix Central Management",
    publisher="Splunk SOAR Community",
    logo="logo.svg",
    logo_dark="logo_dark.svg",
    min_phantom_version="7.0.0",
    fips_compliant=False,
)


# ---------------------------------------------------------------------------
# CM session (auth token + HTTP plumbing)
# ---------------------------------------------------------------------------


class _CMSession:
    """Single CM auth session.

    Uses a ``requests.Session`` with ``trust_env=False`` so the SOAR worker's
    ``HTTP_PROXY`` / ``HTTPS_PROXY`` / ``NO_PROXY`` / ``REQUESTS_CA_BUNDLE``
    environment variables are ignored. A forward proxy is used only when the
    asset's ``http_proxy`` field is explicitly set.
    """

    def __init__(self, asset: Asset):
        self.base_url = asset.server_url.rstrip("/")
        self.username = asset.username
        self.password = asset.password
        self.client_token = (asset.client_token or "").strip() or None
        self.verify_ssl = bool(asset.verify_ssl)
        self.http_proxy = (asset.http_proxy or "").strip() or None
        self._token: str | None = None

        self._session = requests.Session()
        # Critical: do NOT inherit HTTP_PROXY / HTTPS_PROXY / NO_PROXY /
        # REQUESTS_CA_BUNDLE from the SOAR worker environment. CM appliances
        # are typically reached directly on the internal network, and a
        # mis-routed system proxy is the #1 cause of test_connectivity hangs.
        self._session.trust_env = False
        self._session.verify = self.verify_ssl
        if self.http_proxy:
            self._session.proxies = {"http": self.http_proxy, "https": self.http_proxy}
            logger.warning(
                f"CM session: routing through explicit proxy {self.http_proxy!r}"
            )
        else:
            self._session.proxies = {}

    def login(self) -> str:
        url = f"{self.base_url}{CM_AUTH_LOGIN_URL}"
        headers = {"User-Agent": _USER_AGENT, "Accept": "application/json"}
        if self.client_token:
            headers[CM_CLIENT_TOKEN_HEADER] = self.client_token

        logger.info(
            f"CM login: POST {url} (verify_ssl={self.verify_ssl}, "
            f"username={self.username!r}, "
            f"client_token={'set' if self.client_token else 'not set'}, "
            f"proxy={self.http_proxy or '<none>'}, "
            f"timeout=(connect={_CONNECT_TIMEOUT}s, read={_READ_TIMEOUT}s))"
        )

        resp = self._session.post(
            url,
            auth=(self.username, self.password),
            headers=headers,
            timeout=_LOGIN_TIMEOUT,
        )

        logger.info(
            f"CM login response: status={resp.status_code} "
            f"content_type={resp.headers.get('Content-Type', '<none>')!r} "
            f"content_length={len(resp.content)}"
        )

        if not (200 <= resp.status_code < 400):
            snippet = (resp.text or "")[:500].replace("\n", " ")
            logger.warning(f"CM login non-2xx body: {snippet!r}")
            raise RuntimeError(
                f"CM login failed: HTTP {resp.status_code}. "
                f"Body: {snippet or '<empty>'}"
            )

        token = resp.headers.get(CM_TOKEN_HEADER)
        if not token:
            visible_headers = {
                k: v
                for k, v in resp.headers.items()
                if not k.lower().startswith(("set-cookie",))
            }
            logger.warning(
                f"CM login 2xx but {CM_TOKEN_HEADER!r} header missing. "
                f"Response headers: {visible_headers}"
            )
            raise RuntimeError(
                f"CM login succeeded (HTTP {resp.status_code}) but no "
                f"{CM_TOKEN_HEADER!r} header in the response. The appliance "
                f"may have returned a login page instead of the API response - "
                f"check that the URL points to the CM API root and that the "
                f"user has the api_admin or api_analyst role."
            )

        self._token = token
        logger.info("CM login: token acquired.")
        return token

    def logout(self) -> None:
        if not self._token:
            return
        url = f"{self.base_url}{CM_AUTH_LOGOUT_URL}"
        try:
            headers = {
                CM_TOKEN_HEADER: self._token,
                "User-Agent": _USER_AGENT,
            }
            if self.client_token:
                headers[CM_CLIENT_TOKEN_HEADER] = self.client_token
            resp = self._session.post(url, headers=headers, timeout=_LOGIN_TIMEOUT)
            logger.info(f"CM logout: POST {url} status={resp.status_code}")
        except Exception as exc:
            logger.warning(f"CM logout call failed (ignored): {exc}")
        finally:
            self._token = None
            try:
                self._session.close()
            except Exception:
                pass

    def upload_yara(
        self, file_type: str, file_path: str, file_name: str
    ) -> requests.Response:
        """POST a YARA file to /wsapis/v2.0.0/customioc/yara/add/{file_type}."""
        if not self._token:
            self.login()
        endpoint = f"{self.base_url}{CM_YARA_UPLOAD_URL}/{file_type}"
        headers = {
            CM_TOKEN_HEADER: self._token,
            "User-Agent": _USER_AGENT,
            "Accept": "application/json",
        }
        if self.client_token:
            headers[CM_CLIENT_TOKEN_HEADER] = self.client_token
        with open(file_path, "rb") as fh:
            files = {"file": (file_name, fh, "text/plain")}
            resp = self._session.post(
                endpoint,
                headers=headers,
                files=files,
                timeout=(_CONNECT_TIMEOUT, 180),
            )
        return resp

    def __enter__(self) -> "_CMSession":
        self.login()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        self.logout()


def _login_or_action_failure(asset: Asset) -> _CMSession:
    """Construct a ``_CMSession`` and authenticate. Converts every known
    network / HTTP failure mode into a clean :class:`ActionFailure` so the
    SOAR action result UI gets a one-line message instead of a Python
    traceback.

    The caller is responsible for calling ``session.logout()`` (typically
    inside a ``try / finally`` so partial uploads still release the token).
    """
    session = _CMSession(asset)
    parsed_host = urlparse(session.base_url).netloc or session.base_url
    try:
        session.login()
    except requests.exceptions.SSLError as exc:
        raise ActionFailure(
            f"TLS certificate verification failed for {parsed_host}: {exc}. "
            f"If the appliance uses a self-signed or internal-CA certificate, "
            f"set the asset's 'verify_ssl' to False (or install the appliance "
            f"CA on the SOAR worker)."
        ) from exc
    except requests.exceptions.ProxyError as exc:
        if session.http_proxy:
            raise ActionFailure(
                f"Proxy {session.http_proxy!r} failed to connect to "
                f"{parsed_host}: {exc}. Verify the proxy URL/credentials "
                f"and that the proxy can route to the CM appliance."
            ) from exc
        raise ActionFailure(
            f"A proxy intercepted the connection to {parsed_host} even "
            f"though no proxy is configured on the asset: {exc}. Either "
            f"set the asset's 'http_proxy' to the correct proxy URL, or "
            f"have your network team allow direct egress from the SOAR "
            f"worker to the CM appliance."
        ) from exc
    except requests.exceptions.ConnectTimeout as exc:
        hint = (
            f"explicit proxy {session.http_proxy!r}"
            if session.http_proxy
            else "the appliance directly (no proxy)"
        )
        raise ActionFailure(
            f"Connection to {parsed_host} timed out after "
            f"{_CONNECT_TIMEOUT}s (connecting via {hint}): {exc}. Verify "
            f"the appliance is reachable from the SOAR worker (firewall, "
            f"VPN, routing) and that the port is open."
        ) from exc
    except requests.exceptions.ReadTimeout as exc:
        raise ActionFailure(
            f"Read from {parsed_host} timed out after {_READ_TIMEOUT}s: "
            f"{exc}. The appliance accepted the TCP connection but did not "
            f"respond to the login POST in time."
        ) from exc
    except requests.exceptions.ConnectionError as exc:
        raise ActionFailure(
            f"Could not connect to {parsed_host}: {exc}. Check the "
            f"server_url (DNS, hostname, port) and that the appliance is "
            f"reachable from the SOAR worker."
        ) from exc
    except requests.exceptions.MissingSchema as exc:
        raise AssetMisconfiguration(
            f"server_url is malformed: {exc}. Use the full URL including "
            f"scheme, e.g. 'https://cm.example.com'."
        ) from exc
    except requests.exceptions.InvalidURL as exc:
        raise AssetMisconfiguration(f"server_url is invalid: {exc}.") from exc
    except RuntimeError as exc:
        # _CMSession.login() raises RuntimeError with a detailed message for
        # HTTP-level failures (non-2xx, missing token header). Surface it
        # verbatim instead of wrapping in a traceback.
        raise ActionFailure(str(exc)) from exc
    return session


# ---------------------------------------------------------------------------
# Test connectivity
# ---------------------------------------------------------------------------


def _safe_attr(asset: Asset, name: str) -> tuple[bool, object]:
    """Read an asset attribute without raising. Returns ``(ok, value_or_error)``.

    Used in test_connectivity so we can surface a clean message even if
    Pydantic validation or attribute access raises after the action handler
    has already been entered.
    """
    try:
        return True, getattr(asset, name)
    except Exception as exc:
        return False, exc


@app.test_connectivity()
def test_connectivity(soar: SOARClient, asset: Asset) -> None:
    # ERROR-level so it lands in the persistent spawn error log
    # (logger.info goes to a progress stream that gets overwritten).
    logger.error("test_connectivity: entered")

    try:
        _do_test_connectivity(asset)
    except ActionFailure:
        raise
    except Exception as exc:
        tb = traceback.format_exc()
        logger.error(
            f"test_connectivity: unexpected {type(exc).__name__}: {exc}\n{tb}"
        )
        raise ActionFailure(
            f"Unexpected {type(exc).__name__} during test connectivity: {exc}. "
            f"Check the SOAR spawn log for the full traceback."
        ) from exc

    logger.error("test_connectivity: OK")


def _do_test_connectivity(asset: Asset) -> None:
    # Probe each asset field individually and log each result at WARNING
    # so it's visible in the persistent log even if something downstream
    # raises.
    for field in ("server_url", "username", "password", "client_token", "verify_ssl", "http_proxy"):
        ok, value = _safe_attr(asset, field)
        if not ok:
            logger.error(
                f"test_connectivity: cannot read asset.{field}: "
                f"{type(value).__name__}: {value}"
            )
            raise AssetMisconfiguration(
                f"Could not read asset.{field}: {value}. The asset "
                f"configuration is missing or malformed for this field."
            )
        if field == "password":
            logger.warning(
                f"test_connectivity: asset.password={'set' if value else 'NOT SET'}"
            )
        elif field == "client_token":
            logger.warning(
                f"test_connectivity: asset.client_token={'set' if value else 'not set'}"
            )
        else:
            logger.warning(f"test_connectivity: asset.{field}={value!r}")

    server_url = (asset.server_url or "").strip()
    username = (asset.username or "").strip()

    if not server_url:
        raise AssetMisconfiguration("Asset 'server_url' is required.")
    if not username:
        raise AssetMisconfiguration("Asset 'username' is required.")
    if not asset.password:
        raise AssetMisconfiguration("Asset 'password' is required.")

    parsed = urlparse(server_url)
    if not parsed.scheme:
        raise AssetMisconfiguration(
            f"server_url {server_url!r} is missing a scheme. "
            f"Use 'https://hostname' (or 'http://hostname' for plaintext)."
        )
    if parsed.scheme not in ("http", "https"):
        raise AssetMisconfiguration(
            f"server_url {server_url!r} has unsupported scheme "
            f"{parsed.scheme!r}; only http and https are supported."
        )
    if not parsed.netloc:
        raise AssetMisconfiguration(f"server_url {server_url!r} has no host.")

    logger.warning(
        f"test_connectivity: parsed scheme={parsed.scheme} host={parsed.hostname!r} "
        f"port={parsed.port} path={parsed.path!r}"
    )

    if parsed.path and parsed.path.rstrip("/"):
        logger.warning(
            f"test_connectivity: server_url contains a path component "
            f"({parsed.path!r}); the API base path '{CM_BASE_PATH}' will be "
            f"appended to it. Set server_url to the appliance root (e.g. "
            f"'https://cm.example.com') if test connectivity fails with a 404."
        )

    # --- Proxy / environment diagnostics -----------------------------------
    env_http = os.environ.get("HTTP_PROXY") or os.environ.get("http_proxy")
    env_https = os.environ.get("HTTPS_PROXY") or os.environ.get("https_proxy")
    env_no_proxy = os.environ.get("NO_PROXY") or os.environ.get("no_proxy")
    if env_http or env_https:
        logger.warning(
            f"test_connectivity: SOAR worker env has HTTP_PROXY="
            f"{env_http or '<unset>'} HTTPS_PROXY={env_https or '<unset>'} "
            f"NO_PROXY={env_no_proxy or '<unset>'}. The app IGNORES these "
            f"by default (trust_env=False) and connects directly. Set the "
            f"asset's 'http_proxy' field if you actually need to route "
            f"through a proxy."
        )
    explicit_proxy = (asset.http_proxy or "").strip()
    if explicit_proxy:
        logger.warning(
            f"test_connectivity: explicit asset http_proxy is set: "
            f"{explicit_proxy!r}. CM traffic will be routed through this "
            f"proxy."
        )
    else:
        logger.warning(
            "test_connectivity: no explicit proxy; connecting directly to "
            "the CM appliance."
        )

    # --- DNS probe ---------------------------------------------------------
    if not explicit_proxy:
        host = parsed.hostname
        port = parsed.port or (443 if parsed.scheme == "https" else 80)
        logger.warning(f"test_connectivity: DNS probe for {host}:{port}...")
        try:
            socket.setdefaulttimeout(_CONNECT_TIMEOUT)
            infos = socket.getaddrinfo(host, port, type=socket.SOCK_STREAM)
            resolved = sorted({i[4][0] for i in infos})
            logger.warning(
                f"test_connectivity: DNS resolved {host} -> {resolved}"
            )
        except socket.gaierror as exc:
            raise ActionFailure(
                f"DNS lookup failed for {host!r}: {exc}. The SOAR worker "
                f"cannot resolve this hostname. Verify the server_url is "
                f"correct and that the SOAR worker can reach a DNS server "
                f"that knows about this appliance (or use an IP literal "
                f"like 'https://10.1.2.3')."
            ) from exc
        except OSError as exc:
            logger.warning(
                f"test_connectivity: DNS probe non-fatal error: {exc}"
            )
        finally:
            socket.setdefaulttimeout(None)

    if not asset.verify_ssl:
        logger.warning(
            "test_connectivity: SSL certificate verification is DISABLED. "
            "Traffic is encrypted, but the server certificate is not validated."
        )
        try:
            import urllib3

            urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
        except Exception as exc:
            logger.warning(
                f"test_connectivity: could not suppress InsecureRequestWarning: {exc}"
            )

    logger.warning("test_connectivity: attempting CM login...")
    session = _login_or_action_failure(asset)
    logger.warning("test_connectivity: CM login succeeded; releasing token.")
    session.logout()


# ---------------------------------------------------------------------------
# Upload YARA (single Vault file)
# ---------------------------------------------------------------------------


class UploadYaraParams(Params):
    vault_id: str = Param(
        description="Vault ID of the YARA file to upload.",
        cef_types=["vault id"],
        primary=True,
    )
    file_type: str = Param(
        description=(
            "YARA file type the appliance will accept. Mapped into the URL "
            "path: POST /wsapis/v2.0.0/customioc/yara/add/{file_type}. The "
            "uploaded file must match this type."
        ),
        value_list=YARA_FILE_TYPES,
    )


class UploadYaraOutput(ActionOutput):
    vault_id: str = OutputField(column_name="Vault ID", cef_types=["vault id"])
    file_name: str = OutputField(column_name="File Name")
    file_type: str = OutputField(column_name="File Type")
    http_status: int = OutputField(column_name="HTTP Status", example_values=[200])
    response_body: str | None = OutputField(column_name="Response Body")


@app.action(
    name="upload yara",
    identifier="upload_yara",
    description=(
        "Upload a single YARA rule file from the Vault to a Trellix CM "
        "appliance via POST /wsapis/v2.0.0/customioc/yara/add/{file_type}. "
        "The Vault file must be a YARA source file (.yar / .yara / .yr) "
        "whose rules match the chosen file_type."
    ),
    action_type="generic",
    read_only=False,
)
def upload_yara(
    params: UploadYaraParams, soar: SOARClient, asset: Asset
) -> UploadYaraOutput:
    logger.info(
        f"=> ACTION START: upload_yara vault_id={params.vault_id} "
        f"file_type={params.file_type}"
    )

    vault_file = _vault_get(soar, params.vault_id)
    file_name = vault_file["name"]
    file_path = vault_file["path"]

    if not _is_yara_filename(file_name):
        raise ActionFailure(
            f"Vault file {file_name!r} is not a YARA file. Expected one of: "
            f"{', '.join(YARA_FILE_EXTENSIONS)}"
        )

    session = _login_or_action_failure(asset)
    try:
        try:
            resp = session.upload_yara(params.file_type, file_path, file_name)
        except FileNotFoundError as exc:
            raise ActionFailure(
                f"Vault file path {file_path!r} for vault_id "
                f"{params.vault_id!r} could not be opened: {exc}."
            ) from exc
        except requests.exceptions.RequestException as exc:
            raise ActionFailure(
                f"YARA upload for {file_name!r} failed during transport: "
                f"{type(exc).__name__}: {exc}."
            ) from exc

        if not (200 <= resp.status_code < 400):
            body = (resp.text or "")[:500].replace("\n", " ")
            raise ActionFailure(
                f"YARA upload for {file_name!r} failed: HTTP "
                f"{resp.status_code}. Body: {body or '<empty>'}"
            )
    finally:
        session.logout()

    soar.set_message(
        f"Uploaded YARA file {file_name} as type {params.file_type}"
    )
    return UploadYaraOutput(
        vault_id=params.vault_id,
        file_name=file_name,
        file_type=params.file_type,
        http_status=resp.status_code,
        response_body=(resp.text[:500] if resp.text else None),
    )


# ---------------------------------------------------------------------------
# Upload all YARAs (every YARA file in a container)
# ---------------------------------------------------------------------------


class UploadAllYarasParams(Params):
    file_type: str = Param(
        description=(
            "YARA file type the appliance will accept. Mapped into the URL "
            "path: POST /wsapis/v2.0.0/customioc/yara/add/{file_type}. Every "
            "uploaded file must match this type."
        ),
        value_list=YARA_FILE_TYPES,
    )
    container_id: int | None = Param(
        description=(
            "Container to scan for YARA files. Defaults to the executing "
            "playbook's container."
        ),
        default=None,
    )


class UploadAllYarasOutput(ActionOutput):
    file_type: str = OutputField(column_name="File Type")
    container_id: int = OutputField(column_name="Container ID")
    uploaded_count: int = OutputField(column_name="Uploaded Count", example_values=[3])
    failed_count: int = OutputField(column_name="Failed Count", example_values=[0])
    skipped_count: int = OutputField(column_name="Skipped Count", example_values=[1])
    uploaded_vault_ids: list[str] = OutputField(column_name="Uploaded Vault IDs")
    failed_vault_ids: list[str] = OutputField(column_name="Failed Vault IDs")
    skipped_vault_ids: list[str] = OutputField(column_name="Skipped Vault IDs")


@app.action(
    name="upload all yaras",
    identifier="upload_all_yaras",
    description=(
        "Upload every YARA rule file (.yar / .yara / .yr) present in a "
        "container's Vault to a Trellix CM appliance via POST "
        "/wsapis/v2.0.0/customioc/yara/add/{file_type}. Non-YARA files in "
        "the container are skipped; every uploaded file must match the "
        "chosen file_type."
    ),
    action_type="generic",
    read_only=False,
)
def upload_all_yaras(
    params: UploadAllYarasParams, soar: SOARClient, asset: Asset
) -> UploadAllYarasOutput:
    container_id = params.container_id or int(soar.get_executing_container_id() or 0)
    if not container_id:
        raise ActionFailure(
            "No container_id supplied and no executing container context "
            "available. Pass container_id to the action."
        )
    logger.info(
        f"=> ACTION START: upload_all_yaras container_id={container_id} "
        f"file_type={params.file_type}"
    )

    attachments = _vault_list_container(soar, container_id)
    if not attachments:
        soar.set_message(f"Container {container_id} has no Vault items to upload")
        return UploadAllYarasOutput(
            file_type=params.file_type,
            container_id=container_id,
            uploaded_count=0,
            failed_count=0,
            skipped_count=0,
            uploaded_vault_ids=[],
            failed_vault_ids=[],
            skipped_vault_ids=[],
        )

    uploaded: list[str] = []
    failed: list[str] = []
    skipped: list[str] = []

    session = _login_or_action_failure(asset)
    try:
        for att in attachments:
            vault_id = att["vault_id"]
            file_name = att["name"]
            file_path = att["path"]
            if not _is_yara_filename(file_name):
                logger.info(
                    f"Skipping non-YARA file {file_name!r} (vault_id={vault_id})"
                )
                skipped.append(vault_id)
                continue
            try:
                resp = session.upload_yara(params.file_type, file_path, file_name)
                if 200 <= resp.status_code < 400:
                    uploaded.append(vault_id)
                else:
                    logger.warning(
                        f"YARA upload failed for {file_name!r}: "
                        f"HTTP {resp.status_code} {resp.text[:200]}"
                    )
                    failed.append(vault_id)
            except Exception as exc:
                logger.warning(
                    f"YARA upload errored for {file_name!r}: "
                    f"{type(exc).__name__}: {exc}"
                )
                failed.append(vault_id)
    finally:
        session.logout()

    soar.set_message(
        f"Uploaded {len(uploaded)} YARA file(s) as type {params.file_type}; "
        f"skipped {len(skipped)} non-YARA; failed {len(failed)}."
    )
    return UploadAllYarasOutput(
        file_type=params.file_type,
        container_id=container_id,
        uploaded_count=len(uploaded),
        failed_count=len(failed),
        skipped_count=len(skipped),
        uploaded_vault_ids=uploaded,
        failed_vault_ids=failed,
        skipped_vault_ids=skipped,
    )


# ---------------------------------------------------------------------------
# Vault helpers
# ---------------------------------------------------------------------------


def _is_yara_filename(file_name: str) -> bool:
    name = (file_name or "").lower()
    return name.endswith(YARA_FILE_EXTENSIONS)


def _vault_get(soar: SOARClient, vault_id: str) -> dict:
    """Look up a Vault file by ID. Returns ``{'vault_id', 'name', 'path'}``."""
    items = soar.vault.get_attachment(vault_id=vault_id)
    if not items:
        raise ActionFailure(f"Vault item {vault_id!r} not found.")
    att = items[0]
    return {"vault_id": att.vault_id, "name": att.name, "path": att.path}


def _vault_list_container(soar: SOARClient, container_id: int) -> list[dict]:
    """Enumerate Vault items in a container."""
    items = soar.vault.get_attachment(container_id=container_id)
    return [
        {"vault_id": att.vault_id, "name": att.name, "path": att.path}
        for att in (items or [])
    ]
