"""Trellix Yara Central Management - Splunk SOAR SDK app."""
