"""Legacy-spawn entry point for SOAR builds predating SDK 3.x dispatch.

Splunk SOAR's legacy ``spawn3`` launcher imports this file, then locates the
connector class via ``BaseConnector.__subclasses__()[0]`` and instantiates it.
Newer SOAR builds dispatch directly through the manifest's ``main_module``
field (``src.app:app``) and never touch this module.

This shim:

  1. Inserts the app install directory onto ``sys.path`` so ``src.app`` is
     importable.
  2. Defines a ``BaseConnector`` subclass BEFORE importing the SDK app, so
     ``__subclasses__()[0]`` returns this class (not ``soar_sdk``'s internal
     ``ActionsManager``) — Python orders ``__subclasses__()`` by class-creation
     time on CPython.
  3. Imports the SDK App instance so all ``@app.action()`` decorators run and
     register their handlers on the App's actions_manager.
  4. Delegates ``_handle_action`` (the legacy spawn entry call) to
     ``App.handle()``, which runs the full SDK 3.x action lifecycle including
     credential decryption, params validation, and result serialization.
"""

import os
import sys


_HERE = os.path.dirname(os.path.abspath(__file__))
if _HERE not in sys.path:
    sys.path.insert(0, _HERE)


try:
    # Real SOAR runtime provides this.
    from phantom.base_connector import BaseConnector
except ImportError:
    # Dev fallback only — the SDK ships a stub.
    from soar_sdk.shims.phantom.base_connector import BaseConnector


class TrellixYaraCentralManagementConnector(BaseConnector):
    """Legacy spawn adapter for Trellix Yara Central Management.

    Defined before the SDK import so that ``BaseConnector.__subclasses__()[0]``
    resolves to us, not to ``soar_sdk.actions_manager.ActionsManager``.
    """

    def _handle_action(self, in_json, handle=None):
        # ``_SDK_APP`` is bound at module load time, after this class is defined.
        return _SDK_APP.handle(in_json, handle)


# Import the SDK app LAST: this registers actions on the App's
# actions_manager and exposes the App instance the shim delegates to.
from src.app import app as _SDK_APP  # noqa: E402
