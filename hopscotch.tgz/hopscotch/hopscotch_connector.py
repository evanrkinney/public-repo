# File: hopscotch_connector.py
#
# HopScotch - a Splunk SOAR app for hopping around the network with IP
# lookup, ping, nslookup, and traceroute actions. Designed to run on a
# Splunk SOAR Automation Broker.

import ipaddress
import json
import shutil
import socket
import subprocess

import phantom.app as phantom
from phantom.action_result import ActionResult
from phantom.base_connector import BaseConnector


class HopScotchConnector(BaseConnector):

    def __init__(self):
        super().__init__()

    # ------------------------------------------------------------------ utils
    def _validate_ip(self, ip, action_result):
        try:
            ipaddress.ip_address(ip)
            return phantom.APP_SUCCESS
        except ValueError:
            return action_result.set_status(
                phantom.APP_ERROR, f"Invalid IP address: {ip}"
            )

    def _run_command(self, cmd, action_result, timeout=60):
        if not shutil.which(cmd[0]):
            return None, action_result.set_status(
                phantom.APP_ERROR,
                f"Command '{cmd[0]}' not found on the automation broker host",
            )
        try:
            proc = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=timeout,
                check=False,
            )
        except subprocess.TimeoutExpired:
            return None, action_result.set_status(
                phantom.APP_ERROR, f"Command timed out: {' '.join(cmd)}"
            )
        except Exception as e:
            return None, action_result.set_status(
                phantom.APP_ERROR, f"Error running command: {e}"
            )

        return proc, phantom.APP_SUCCESS

    # ------------------------------------------------------------------ actions
    def _handle_test_connectivity(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))
        self.save_progress("Checking that required commands are available")

        missing = [c for c in ("ping", "nslookup", "traceroute") if not shutil.which(c)]
        if missing:
            self.save_progress(f"Missing commands: {', '.join(missing)}")
            return action_result.set_status(
                phantom.APP_ERROR,
                f"Missing required commands on broker: {', '.join(missing)}",
            )

        self.save_progress("Test connectivity passed")
        return action_result.set_status(phantom.APP_SUCCESS)

    def _handle_lookup_ip(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))
        ip = param["ip"]

        if phantom.is_fail(self._validate_ip(ip, action_result)):
            return action_result.get_status()

        ip_obj = ipaddress.ip_address(ip)
        data = {
            "ip": ip,
            "version": ip_obj.version,
            "is_private": ip_obj.is_private,
            "is_global": ip_obj.is_global,
            "is_loopback": ip_obj.is_loopback,
            "is_multicast": ip_obj.is_multicast,
            "is_reserved": ip_obj.is_reserved,
            "is_link_local": ip_obj.is_link_local,
        }

        try:
            host, aliases, addrs = socket.gethostbyaddr(ip)
            data["hostname"] = host
            data["aliases"] = aliases
            data["addresses"] = addrs
        except (socket.herror, socket.gaierror):
            data["hostname"] = None
            data["aliases"] = []
            data["addresses"] = []

        action_result.add_data(data)
        summary = action_result.update_summary({})
        summary["hostname"] = data.get("hostname") or "n/a"
        summary["is_private"] = data["is_private"]

        return action_result.set_status(phantom.APP_SUCCESS, "IP lookup complete")

    def _handle_ping_ip(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))
        ip = param["ip"]
        count = int(param.get("count", 4))

        if phantom.is_fail(self._validate_ip(ip, action_result)):
            return action_result.get_status()

        cmd = ["ping", "-c", str(count), "-W", "5", ip]
        proc, status = self._run_command(cmd, action_result, timeout=count * 10 + 15)
        if proc is None:
            return action_result.get_status()

        data = {
            "ip": ip,
            "count": count,
            "return_code": proc.returncode,
            "stdout": proc.stdout,
            "stderr": proc.stderr,
            "reachable": proc.returncode == 0,
        }
        action_result.add_data(data)
        summary = action_result.update_summary({})
        summary["reachable"] = data["reachable"]

        if proc.returncode == 0:
            return action_result.set_status(phantom.APP_SUCCESS, "Ping succeeded")
        return action_result.set_status(
            phantom.APP_SUCCESS, f"Ping failed (rc={proc.returncode})"
        )

    def _handle_nslookup_ip(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))
        ip = param["ip"]

        if phantom.is_fail(self._validate_ip(ip, action_result)):
            return action_result.get_status()

        cmd = ["nslookup", ip]
        proc, status = self._run_command(cmd, action_result, timeout=30)
        if proc is None:
            return action_result.get_status()

        data = {
            "ip": ip,
            "return_code": proc.returncode,
            "stdout": proc.stdout,
            "stderr": proc.stderr,
        }
        action_result.add_data(data)
        summary = action_result.update_summary({})
        summary["return_code"] = proc.returncode

        if proc.returncode != 0:
            return action_result.set_status(
                phantom.APP_ERROR, f"nslookup failed: {proc.stderr.strip() or proc.stdout.strip()}"
            )
        return action_result.set_status(phantom.APP_SUCCESS, "nslookup complete")

    def _handle_traceroute_ip(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))
        ip = param["ip"]
        max_hops = int(param.get("max_hops", 30))

        if phantom.is_fail(self._validate_ip(ip, action_result)):
            return action_result.get_status()

        cmd = ["traceroute", "-n", "-m", str(max_hops), ip]
        proc, status = self._run_command(cmd, action_result, timeout=max_hops * 5 + 30)
        if proc is None:
            return action_result.get_status()

        data = {
            "ip": ip,
            "max_hops": max_hops,
            "return_code": proc.returncode,
            "stdout": proc.stdout,
            "stderr": proc.stderr,
        }
        action_result.add_data(data)
        summary = action_result.update_summary({})
        summary["hops"] = max(0, len([l for l in proc.stdout.splitlines() if l.strip()]) - 1)

        if proc.returncode != 0:
            return action_result.set_status(
                phantom.APP_ERROR, f"traceroute failed: {proc.stderr.strip() or proc.stdout.strip()}"
            )
        return action_result.set_status(phantom.APP_SUCCESS, "traceroute complete")

    # ------------------------------------------------------------------ dispatch
    def handle_action(self, param):
        action_id = self.get_action_identifier()
        handlers = {
            "test_connectivity": self._handle_test_connectivity,
            "lookup_ip": self._handle_lookup_ip,
            "ping_ip": self._handle_ping_ip,
            "nslookup_ip": self._handle_nslookup_ip,
            "traceroute_ip": self._handle_traceroute_ip,
        }
        handler = handlers.get(action_id)
        if not handler:
            return phantom.APP_ERROR
        return handler(param)


def main():
    import sys

    if len(sys.argv) < 2:
        print("No input file provided")
        sys.exit(1)

    with open(sys.argv[1]) as f:
        in_json = json.load(f)

    connector = HopScotchConnector()
    connector.print_progress_message = True
    ret = connector._handle_action(json.dumps(in_json), None)
    print(ret)
    sys.exit(0)


if __name__ == "__main__":
    main()
