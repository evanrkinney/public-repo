# File: hopscotch_connector.py
#
# HopScotch - a Splunk SOAR app for hopping around the network with IP
# lookup, ping, nslookup, and traceroute actions. Pure Python: no
# dependency on system ping/nslookup/traceroute binaries, designed to
# run on a Splunk SOAR Automation Broker in restricted environments
# such as an OpenShift container without CAP_NET_RAW.

import ipaddress
import json
import os
import socket
import struct
import time

import phantom.app as phantom
from phantom.action_result import ActionResult
from phantom.base_connector import BaseConnector


# TCP ports tried by the TCP-reachability fallback (in order).
TCP_PING_PORTS = (443, 80, 22, 53)

# ICMP message types we care about.
ICMP_ECHO_REPLY = 0
ICMP_DEST_UNREACH = 3
ICMP_ECHO_REQUEST = 8
ICMP_TIME_EXCEEDED = 11

# sock_extended_err.ee_origin value for ICMP-sourced errors.
SO_EE_ORIGIN_ICMP = 2

# Standard UDP base port used by traceroute probes.
TRACEROUTE_BASE_PORT = 33434


class HopScotchConnector(BaseConnector):

    def __init__(self):
        super().__init__()

    # ------------------------------------------------------------------ utils
    def _validate_ip(self, ip, action_result):
        try:
            ipaddress.ip_address(ip)
            return phantom.APP_SUCCESS
        except ValueError:
            return action_result.set_status(
                phantom.APP_ERROR, f"Invalid IP address: {ip}"
            )

    @staticmethod
    def _reverse_dns(ip):
        try:
            return socket.gethostbyaddr(ip)[0]
        except (socket.herror, socket.gaierror, OSError):
            return None

    # ------------------------------------------------------------------ ICMP primitives
    @staticmethod
    def _icmp_checksum(data):
        if len(data) % 2:
            data += b"\x00"
        s = 0
        for i in range(0, len(data), 2):
            s += (data[i] << 8) + data[i + 1]
        s = (s >> 16) + (s & 0xFFFF)
        s += s >> 16
        return ~s & 0xFFFF

    def _build_icmp_echo(self, ident, seq, payload):
        header = struct.pack("!BBHHH", ICMP_ECHO_REQUEST, 0, 0, ident, seq)
        chk = self._icmp_checksum(header + payload)
        return struct.pack("!BBHHH", ICMP_ECHO_REQUEST, 0, chk, ident, seq) + payload

    def _icmp_ping(self, ip, count, timeout=2.0):
        """Datagram ICMP echo. Linux-unprivileged when the running GID is
        in net.ipv4.ping_group_range. Returns (attempts, error_or_none)."""
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM, socket.IPPROTO_ICMP)
        except (PermissionError, OSError) as e:
            return None, f"unprivileged ICMP not permitted ({e})"

        sock.settimeout(timeout)
        ident = os.getpid() & 0xFFFF
        attempts = []
        try:
            for seq in range(1, count + 1):
                payload = struct.pack("!d", time.time()) + b"hopscotch-icmp"
                packet = self._build_icmp_echo(ident, seq, payload)
                attempt = {"seq": seq, "reachable": False, "rtt_ms": None, "from": None, "error": None}

                start = time.monotonic()
                try:
                    sock.sendto(packet, (ip, 0))
                    deadline = start + timeout
                    while True:
                        remaining = deadline - time.monotonic()
                        if remaining <= 0:
                            attempt["error"] = "timeout"
                            break
                        sock.settimeout(remaining)
                        data, addr = sock.recvfrom(2048)
                        if len(data) < 8:
                            continue
                        rtype, _, _, _, rseq = struct.unpack("!BBHHH", data[:8])
                        if rtype == ICMP_ECHO_REPLY and rseq == seq:
                            attempt["reachable"] = True
                            attempt["rtt_ms"] = round((time.monotonic() - start) * 1000.0, 2)
                            attempt["from"] = addr[0] if addr else ip
                            break
                except socket.timeout:
                    attempt["error"] = "timeout"
                except OSError as e:
                    attempt["error"] = str(e)
                attempts.append(attempt)
        finally:
            sock.close()
        return attempts, None

    def _tcp_ping(self, ip, count, per_attempt_timeout=2.0):
        """TCP-connect reachability check across a small set of common
        ports. Counts a refused (RST) response as 'host alive', since
        both an accepted connection and an active refusal prove the host
        responded."""
        family = socket.AF_INET6 if ":" in ip else socket.AF_INET
        attempts = []
        for i in range(count):
            attempt = {"seq": i + 1, "reachable": False, "rtt_ms": None, "port": None, "error": None}
            for port in TCP_PING_PORTS:
                start = time.monotonic()
                sock = socket.socket(family, socket.SOCK_STREAM)
                sock.settimeout(per_attempt_timeout)
                try:
                    sock.connect((ip, port))
                    rtt = (time.monotonic() - start) * 1000.0
                    attempt.update({"reachable": True, "rtt_ms": round(rtt, 2), "port": port})
                    break
                except ConnectionRefusedError:
                    rtt = (time.monotonic() - start) * 1000.0
                    attempt.update({"reachable": True, "rtt_ms": round(rtt, 2), "port": port, "error": "refused"})
                    break
                except (socket.timeout, OSError) as e:
                    attempt["error"] = str(e)
                finally:
                    sock.close()
            attempts.append(attempt)
        return attempts

    # ------------------------------------------------------------------ traceroute primitive
    def _python_traceroute(self, ip, max_hops, timeout=2.0):
        """Unprivileged traceroute via UDP + IP_RECVERR/MSG_ERRQUEUE.

        Sends one UDP probe per TTL and reads ICMP TIME_EXCEEDED /
        DEST_UNREACH out of the kernel's socket error queue. Linux-only,
        no CAP_NET_RAW, no root. Each hop is annotated with reverse DNS.
        """
        if ":" in ip:
            return None, "IPv6 traceroute is not supported"
        if not hasattr(socket, "IP_RECVERR") or not hasattr(socket, "MSG_ERRQUEUE"):
            return None, "kernel does not expose IP_RECVERR/MSG_ERRQUEUE (Linux required)"

        hops = []
        for ttl in range(1, max_hops + 1):
            sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            sock.setsockopt(socket.IPPROTO_IP, socket.IP_TTL, ttl)
            try:
                sock.setsockopt(socket.IPPROTO_IP, socket.IP_RECVERR, 1)
            except OSError as e:
                sock.close()
                return None, f"IP_RECVERR not supported: {e}"
            sock.settimeout(timeout)

            port = TRACEROUTE_BASE_PORT + ttl
            start = time.monotonic()
            hop = {
                "hop": ttl,
                "ip": None,
                "hostname": None,
                "rtt_ms": None,
                "icmp_type": None,
                "icmp_code": None,
                "error": None,
            }

            try:
                sock.sendto(b"hopscotch-trace", (ip, port))
            except OSError as e:
                hop["error"] = f"send failed: {e}"

            deadline = start + timeout
            while True:
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    if hop["ip"] is None and hop["error"] is None:
                        hop["error"] = "timeout"
                    break
                sock.settimeout(remaining)
                try:
                    _, ancdata, _, _ = sock.recvmsg(1024, 1024, socket.MSG_ERRQUEUE)
                except (socket.timeout, BlockingIOError):
                    if hop["error"] is None:
                        hop["error"] = "timeout"
                    break
                except OSError as e:
                    hop["error"] = str(e)
                    break

                parsed = False
                for level, ctype, cdata in ancdata:
                    if level == socket.IPPROTO_IP and ctype == socket.IP_RECVERR and len(cdata) >= 16:
                        _ee_errno, ee_origin, ee_type, ee_code, _pad, _info, _data = (
                            struct.unpack("IBBBBII", cdata[:16])
                        )
                        if ee_origin == SO_EE_ORIGIN_ICMP:
                            hop["icmp_type"] = ee_type
                            hop["icmp_code"] = ee_code
                            # struct sockaddr_in follows: family(2) port(2) addr(4) ...
                            if len(cdata) >= 24:
                                hop["ip"] = socket.inet_ntoa(cdata[20:24])
                                hop["hostname"] = self._reverse_dns(hop["ip"])
                            hop["rtt_ms"] = round((time.monotonic() - start) * 1000.0, 2)
                            parsed = True
                            break
                if parsed:
                    break

            sock.close()
            hops.append(hop)

            # Stop when we hit the destination (router == target, or
            # destination sent ICMP DEST_UNREACH for our probe port).
            if hop["ip"] == ip:
                break
            if hop["icmp_type"] == ICMP_DEST_UNREACH:
                break

        return hops, None

    # ------------------------------------------------------------------ actions
    def _handle_test_connectivity(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))
        self.save_progress("Probing pure-Python diagnostic capabilities on the broker")

        # Datagram ICMP socket creation probe.
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM, socket.IPPROTO_ICMP)
            s.close()
            have_dgram_icmp = True
            dgram_icmp_err = None
        except (PermissionError, OSError) as e:
            have_dgram_icmp = False
            dgram_icmp_err = str(e)

        have_recverr = hasattr(socket, "IP_RECVERR") and hasattr(socket, "MSG_ERRQUEUE")

        self.save_progress(f"unprivileged ICMP (ping): {'available' if have_dgram_icmp else f'unavailable ({dgram_icmp_err}) — TCP fallback will be used'}")
        self.save_progress(f"socket reverse DNS (nslookup): always available")
        self.save_progress(f"IP_RECVERR (traceroute): {'available' if have_recverr else 'unavailable — traceroute action will fail'}")

        try:
            socket.gethostbyname("localhost")
        except Exception as e:
            return action_result.set_status(phantom.APP_ERROR, f"Python socket resolution failing: {e}")

        if not have_recverr:
            return action_result.set_status(
                phantom.APP_ERROR,
                "Kernel does not expose IP_RECVERR/MSG_ERRQUEUE — Linux required for traceroute",
            )

        return action_result.set_status(phantom.APP_SUCCESS, "Test connectivity passed")

    def _handle_lookup_ip(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))
        ip = param["ip"]

        if phantom.is_fail(self._validate_ip(ip, action_result)):
            return action_result.get_status()

        ip_obj = ipaddress.ip_address(ip)
        data = {
            "ip": ip,
            "version": ip_obj.version,
            "is_private": ip_obj.is_private,
            "is_global": ip_obj.is_global,
            "is_loopback": ip_obj.is_loopback,
            "is_multicast": ip_obj.is_multicast,
            "is_reserved": ip_obj.is_reserved,
            "is_link_local": ip_obj.is_link_local,
        }

        try:
            host, aliases, addrs = socket.gethostbyaddr(ip)
            data["hostname"] = host
            data["aliases"] = aliases
            data["addresses"] = addrs
        except (socket.herror, socket.gaierror):
            data["hostname"] = None
            data["aliases"] = []
            data["addresses"] = []

        action_result.add_data(data)
        summary = action_result.update_summary({})
        summary["hostname"] = data.get("hostname") or "n/a"
        summary["is_private"] = data["is_private"]

        return action_result.set_status(phantom.APP_SUCCESS, "IP lookup complete")

    def _handle_ping_ip(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))
        ip = param["ip"]
        count = int(param.get("count", 4))

        if phantom.is_fail(self._validate_ip(ip, action_result)):
            return action_result.get_status()

        # Try unprivileged datagram ICMP first; fall back to TCP if the
        # kernel doesn't allow it for our GID.
        attempts, err = self._icmp_ping(ip, count)
        if attempts is not None:
            method = "icmp"
            self.save_progress("Using unprivileged datagram ICMP")
        else:
            self.save_progress(f"Datagram ICMP unavailable ({err}); using TCP connectivity check")
            attempts = self._tcp_ping(ip, count)
            method = "tcp"

        reachable = any(a["reachable"] for a in attempts)
        rtts = [a["rtt_ms"] for a in attempts if a["rtt_ms"] is not None]

        stdout_lines = [f"{method} ping to {ip}"]
        for a in attempts:
            if a["reachable"]:
                detail = f"rtt={a['rtt_ms']} ms"
                if a.get("port"):
                    detail = f"port={a['port']} " + detail
                if a.get("from"):
                    detail = f"from={a['from']} " + detail
                stdout_lines.append(f"  seq={a['seq']} {detail}")
            else:
                stdout_lines.append(f"  seq={a['seq']} unreachable ({a.get('error') or 'timeout'})")
        if rtts:
            stdout_lines.append(
                f"min/avg/max = {min(rtts):.2f}/{sum(rtts) / len(rtts):.2f}/{max(rtts):.2f} ms"
            )

        data = {
            "ip": ip,
            "count": count,
            "method": method,
            "return_code": 0 if reachable else 1,
            "stdout": "\n".join(stdout_lines),
            "stderr": "",
            "reachable": reachable,
            "attempts": attempts,
        }
        action_result.add_data(data)
        summary = action_result.update_summary({})
        summary["reachable"] = reachable

        if reachable:
            return action_result.set_status(phantom.APP_SUCCESS, f"{method} ping succeeded")
        return action_result.set_status(phantom.APP_SUCCESS, f"{method} ping failed (host unreachable)")

    def _handle_traceroute_ip(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))
        ip = param["ip"]
        max_hops = int(param.get("max_hops", 30))

        if phantom.is_fail(self._validate_ip(ip, action_result)):
            return action_result.get_status()

        hops, err = self._python_traceroute(ip, max_hops)
        if hops is None:
            return action_result.set_status(phantom.APP_ERROR, f"traceroute unavailable: {err}")

        lines = [f"traceroute to {ip}, {max_hops} hops max"]
        for h in hops:
            if h.get("ip"):
                label = h["hostname"] if h.get("hostname") else h["ip"]
                lines.append(f"  {h['hop']:>2}  {label} ({h['ip']})  {h['rtt_ms']} ms")
            else:
                lines.append(f"  {h['hop']:>2}  *  ({h.get('error') or 'no response'})")

        last = hops[-1] if hops else None
        reached = bool(last and last.get("ip") == ip)

        data = {
            "ip": ip,
            "max_hops": max_hops,
            "method": "udp-recverr",
            "return_code": 0 if reached else 1,
            "stdout": "\n".join(lines),
            "stderr": "",
            "hops": hops,
        }
        action_result.add_data(data)
        summary = action_result.update_summary({})
        summary["hops"] = sum(1 for h in hops if h.get("ip"))
        summary["reached_destination"] = reached

        if reached:
            return action_result.set_status(
                phantom.APP_SUCCESS, f"traceroute reached destination in {len(hops)} hops"
            )
        return action_result.set_status(
            phantom.APP_SUCCESS,
            f"traceroute completed without reaching destination ({len(hops)} hops shown)",
        )

    # ------------------------------------------------------------------ dispatch
    def handle_action(self, param):
        action_id = self.get_action_identifier()
        handlers = {
            "test_connectivity": self._handle_test_connectivity,
            "lookup_ip": self._handle_lookup_ip,
            "ping_ip": self._handle_ping_ip,
            "traceroute_ip": self._handle_traceroute_ip,
        }
        handler = handlers.get(action_id)
        if not handler:
            return phantom.APP_ERROR
        return handler(param)


def main():
    import sys

    if len(sys.argv) < 2:
        print("No input file provided")
        sys.exit(1)

    with open(sys.argv[1]) as f:
        in_json = json.load(f)

    connector = HopScotchConnector()
    connector.print_progress_message = True
    ret = connector._handle_action(json.dumps(in_json), None)
    print(ret)
    sys.exit(0)


if __name__ == "__main__":
    main()
