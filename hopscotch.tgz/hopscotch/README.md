# HopScotch — Splunk SOAR App

**HopScotch** is a Splunk SOAR app for hopping around the network. It provides
basic IP diagnostic actions intended to run on a **Splunk SOAR Automation
Broker**, including restricted environments such as an OpenShift container
without `CAP_NET_RAW`. All actions are implemented in pure Python using the
stdlib `socket` module — no system binaries (`ping`, `nslookup`, `traceroute`)
are required on the broker.

## Actions

| Action            | Description                                                                  |
| ----------------- | ---------------------------------------------------------------------------- |
| test connectivity | Probes the broker's Python network primitives                                |
| lookup ip         | Reverse DNS + IP classification (private/global/loopback/etc.)               |
| ping ip           | ICMP echo via unprivileged datagram socket; falls back to TCP-connect        |
| traceroute ip     | UDP probes per TTL with reverse DNS per hop, via `IP_RECVERR`/`MSG_ERRQUEUE` |

## Broker Requirements

- Linux kernel that exposes `IP_RECVERR` and `MSG_ERRQUEUE` (any modern Linux,
  including the Splunk SOAR Automation Broker base image)
- For ICMP ping without TCP fallback: the broker's GID must fall within
  `net.ipv4.ping_group_range` (typical default on modern distros)

No `CAP_NET_RAW`, no root, and no system binaries are required.

## Files

- `hopscotch.json` — app manifest
- `hopscotch_connector.py` — connector implementing the actions
- `hopscotch.svg` — app logo
- `requirements.txt` — no third-party dependencies

## Running on the Automation Broker

When running an action from a playbook, set the **execution target** to the
desired Automation Broker so the diagnostics are executed from that broker's
network vantage point.
