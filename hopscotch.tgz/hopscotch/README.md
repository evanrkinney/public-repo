# HopScotch — Splunk SOAR App

**HopScotch** is a Splunk SOAR app for hopping around the network. It provides
basic IP diagnostic actions intended to run on a **Splunk SOAR Automation
Broker**. All actions shell out to standard Linux network utilities, so the
broker host must have them installed.

## Actions

| Action            | Description                                               |
| ----------------- | --------------------------------------------------------- |
| test connectivity | Verifies `ping`, `nslookup`, and `traceroute` are present |
| lookup ip         | Reverse DNS + IP classification (private/global/etc.)     |
| ping ip           | Runs `ping -c <count>` against the IP                     |
| nslookup ip       | Runs `nslookup` against the IP                            |
| traceroute ip     | Runs `traceroute -n -m <max_hops>` against the IP         |

## Broker Requirements

- `ping` (iputils-ping)
- `nslookup` (bind-utils / dnsutils)
- `traceroute`

Debian/Ubuntu: `apt-get install -y iputils-ping dnsutils traceroute`
RHEL/CentOS:   `yum install -y iputils bind-utils traceroute`

## Files

- `hopscotch.json` — app manifest
- `hopscotch_connector.py` — connector implementing the actions
- `hopscotch.svg` — app logo
- `requirements.txt` — no third-party dependencies

## Running on the Automation Broker

When running an action from a playbook, set the **execution target** to the
desired Automation Broker so the diagnostic commands are executed from that
broker's network vantage point.
