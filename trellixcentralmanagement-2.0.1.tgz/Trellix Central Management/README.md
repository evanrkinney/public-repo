# Trellix Central Management (Splunk SOAR)

A Splunk SOAR app, built on the **Splunk SOAR SDK 3.x**, for the Trellix
(formerly FireEye) Central Management (CM) appliance.

Originally distributed as `fireeyecentralmanagement` on the legacy SOAR
connector framework; this 2.x release rewrites the app on the new SDK,
rebrands it for Trellix, and adds YARA rule upload actions.

---

## Asset configuration

| Field              | Required | Sensitive | Default | Notes                                                                                                                                                                                                                                                       |
| ------------------ | -------- | --------- | ------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `server_url`       | yes      | no        | —       | Base URL of the CM appliance (e.g. `https://cm.example.com`). Must include scheme. Should be the appliance root — the API base path `/wsapis/v2.0.0` is appended automatically.                                                                             |
| `username`         | yes      | no        | —       | CM account username. Must hold the `api_admin` or `api_analyst` role on the appliance for YARA uploads to work.                                                                                                                                             |
| `password`         | yes      | yes       | —       | CM account password.                                                                                                                                                                                                                                        |
| `client_token`     | no       | yes       | —       | Optional `X-FeClient-Token` value (sent in addition to the session `X-FeApi-Token` if configured).                                                                                                                                                          |
| `verify_ssl`       | no       | no        | `false` | Enforce TLS certificate validation. Leave off if the appliance uses a self-signed or internal-CA certificate.                                                                                                                                               |
| `product_filter`   | no       | no        | —       | On-poll product filter (comma-separated, e.g. `EX,NX,AX`). Alerts from products not in the list are skipped during ingestion.                                                                                                                               |
| `include_riskware` | no       | no        | `false` | On-poll: include riskware alerts in the ingestion results.                                                                                                                                                                                                  |
| `http_proxy`       | no       | no        | —       | **Outbound proxy URL** (e.g. `http://proxy.internal:3128`). If empty, the app **bypasses any system proxy** and connects to the CM appliance directly. Set this *only* if the appliance must be reached via an explicit forward proxy.                       |

### Networking note: env-var proxies are ignored

The SOAR worker sometimes has `HTTP_PROXY` / `HTTPS_PROXY` set in its
environment for the appliance's own outbound internet traffic. Python's
`requests` library reads those env vars by default, which would send CM
traffic through an Internet egress proxy that almost certainly can't
route to the internal CM appliance — symptom: `test connectivity` hangs.

This app explicitly **does not** trust environment proxies
(`requests.Session.trust_env = False`). If you actually need a forward
proxy in front of the CM appliance, set the asset's `http_proxy` field.
The log will warn you when env-var proxies are present but being
ignored.

### Test Connectivity

`test connectivity` runs in this order, logging every step at WARNING
level so it survives in the SOAR spawn debug log:

1. Validates each asset field (`server_url`, `username`, `password`) is set.
2. Parses `server_url` — fails fast on missing scheme, unsupported scheme, no host.
3. Reports the resolved proxy state (asset-level vs. env-level).
4. **DNS probe** (`socket.getaddrinfo` with 15 s timeout) on the appliance hostname. If DNS fails you get a specific `DNS lookup failed for 'host': ...` instead of waiting 60 s.
5. Posts to `/wsapis/v2.0.0/auth/login` with 15 s connect / 60 s read timeout.
6. Validates a 2xx response and an `X-FeApi-Token` header.
7. Releases the token via `/auth/logout`.

Every failure mode below produces a clean one-line error message in the
SOAR action result UI (`Action failure: ...` / `Asset misconfiguration:
...`), **not** a Python traceback:

| Failure                                        | Resulting message                                                                                                                                                                                                                                                                   |
| ---------------------------------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Missing asset field                            | `Asset misconfiguration: Asset 'server_url' is required.`                                                                                                                                                                                                                          |
| Malformed `server_url`                         | `Asset misconfiguration: server_url 'cm.example.com' is missing a scheme.`                                                                                                                                                                                                         |
| DNS doesn't resolve hostname                   | `Action failure: DNS lookup failed for 'cm.example.com': ... Verify the server_url is correct and that the SOAR worker can reach a DNS server that knows about this appliance.`                                                                                                    |
| TLS verification fails (with `verify_ssl=True`) | `Action failure: TLS certificate verification failed for cm.example.com: ... If the appliance uses a self-signed or internal-CA certificate, set the asset's 'verify_ssl' to False.`                                                                                              |
| TCP connect times out                          | `Action failure: Connection to cm.example.com timed out after 15s (connecting via the appliance directly (no proxy)): ... Verify the appliance is reachable from the SOAR worker.`                                                                                                 |
| Proxy can't reach appliance (env or asset)     | `Action failure: A proxy intercepted the connection ... Either set the asset's 'http_proxy' to the correct proxy URL, or have your network team allow direct egress from the SOAR worker to the CM appliance.`                                                                     |
| Bad credentials (HTTP 401)                     | `Action failure: CM login failed: HTTP 401. Body: {"error":"unauthorized"}`                                                                                                                                                                                                         |
| URL points to wrong endpoint (200 + HTML)      | `Action failure: CM login succeeded (HTTP 200) but no 'X-FeApi-Token' header in the response. The appliance may have returned a login page instead of the API response — check that the URL points to the CM API root and that the user has the api_admin or api_analyst role.` |

---

## Actions

| Action                       | Type        | Description                                                                                  |
| ---------------------------- | ----------- | -------------------------------------------------------------------------------------------- |
| `test connectivity`          | test        | Validate the configured CM credentials.                                                      |
| `on poll`                    | ingest      | Ingest CM alerts as containers / artifacts.                                                  |
| `list quarantined emails`    | investigate | Retrieve information about quarantined emails.                                               |
| `get quarantined email`      | investigate | Save a single quarantined email to the SOAR Vault.                                           |
| `release quarantined emails` | generic     | Release (and delete) quarantined emails.                                                     |
| `get alert`                  | investigate | Retrieve a single alert by ID / UUID.                                                        |
| `list alerts`                | investigate | Retrieve alerts based on time + IOC filters.                                                 |
| `upload yara`                | generic     | Upload a single YARA file from the Vault to the CM appliance.                                |
| `upload all yaras`           | generic     | Upload every YARA file (`.yar` / `.yara` / `.yr`) in a container's Vault to the CM appliance.|

### `upload yara`

| Parameter   | Type   | Required | Description                                                                                            |
| ----------- | ------ | -------- | ------------------------------------------------------------------------------------------------------ |
| `vault_id`  | string | yes      | Vault ID of the YARA file. Filename must end in `.yar/.yara/.yr`.                                      |
| `file_type` | string | yes      | YARA file type recognized by the appliance. Used as the URL path segment. The file's rules must match. |

Permitted `file_type` values (from the NX `customioc/yara` taxonomy):
`callback_domain`, `domain_match`, `exploit`, `infection_match`,
`malware_callback`, `malware_object`, `uri_match`.

### `upload all yaras`

| Parameter      | Type    | Required | Description                                                              |
| -------------- | ------- | -------- | ------------------------------------------------------------------------ |
| `file_type`    | string  | yes      | YARA file type. Same value list as `upload yara`. Applies to every file. |
| `container_id` | numeric | no       | Container to scan for YARA files. Defaults to the executing container.   |

Enumerates every Vault item in the container; uploads each one whose
filename ends in a YARA extension; skips everything else. Returns
per-vault-id breakdowns of which uploaded, failed, and were skipped.

---

## YARA endpoint

Uploads are sent to the NX `customioc/yara/add` endpoint:

```
POST {server_url}/wsapis/v2.0.0/customioc/yara/add/{file_type}
X-FeApi-Token: <session token from POST /wsapis/v2.0.0/auth/login>
Content-Type: multipart/form-data
  file=<YARA file content>
```

The session token is acquired transparently by the action — the asset's
`username` / `password` (and optional `client_token`) are exchanged for
an `X-FeApi-Token` for the duration of the call. The appliance user
account must hold the `api_admin` or `api_analyst` role.

---

## Build & install

```bash
# Generate the dependency lock file (only needed once or after editing pyproject.toml).
uv lock

# Build the .tgz package.
python3 package_build.py package build . -o trellixcentralmanagement-2.0.1.tgz
```

The `package_build.py` wrapper does two things on top of `soarapps
package build`:

1. **Strips ~17 MB of unused transitive deps** from the SDK
   (`extract-msg` chain, OAuth chain, Windows-only wheels, CLI-only
   deps) — bundle shrinks from ~22 MB to ~5.6 MB.
2. **Injects a legacy-spawn shim** at the package root
   (`phantom_trellixcentralmanagement_connector.py`) so SOAR builds
   still using the pre-SDK-3.x spawn (`BaseConnector.__subclasses__()[0]`)
   can launch the app. Newer SOAR builds dispatch directly through the
   manifest's `main_module` field and never touch the shim.

Install via SOAR UI → **Apps** → **Install App from a file**.

---

## Migration notes (1.1.0 → 2.x)

- Repackaged on the Splunk SOAR SDK 3.x. Old `fireeyecentralmanagement_connector.py`,
  `fireeyecentralmanagement_view.py`, and the manual JSON manifest are gone;
  the app definition is now expressed entirely in [src/app.py](src/app.py).
- `product_vendor` renamed to **Trellix**; `product_name` renamed to
  **Trellix Central Management**. The `appid` is unchanged
  (`b5e446c9-eb44-4991-bcbf-18945c787bee`) so existing assets carry over.
- New actions: `upload yara`, `upload all yaras`.
- New asset field: `http_proxy` (forward proxy URL; default direct connection).
- CEF type names rebranded from `fireeye cm ...` to `trellix cm ...`.

## Changelog

### 2.0.1

- **Test connectivity overhaul**: every failure path now produces a
  one-line `ActionFailure` / `AssetMisconfiguration` message in the
  action result UI instead of a Python traceback.
- Per-field WARNING-level asset diagnostics (visible in the spawn debug
  log) emitted before any network call, so an early failure no longer
  leaves you guessing what was read.
- Environment proxy bypass by default (`trust_env=False`) — fixes
  `test connectivity` hangs caused by SOAR worker `HTTP_PROXY` env
  variables routing CM traffic through an egress proxy.
- New `http_proxy` asset field for the rare case where the CM appliance
  legitimately sits behind a forward proxy.
- Short TCP connect timeout (15 s) + pre-flight DNS probe; failures
  surface in seconds, not minutes.
- Dedicated `ProxyError` exception handling with messages that name
  which proxy failed.
- Legacy-spawn shim injected post-build for compatibility with SOAR
  builds that haven't fully cut over to SDK 3.x dispatch.

### 2.0.0

- Initial Trellix-branded release on the Splunk SOAR SDK 3.x.
- Added `upload yara` and `upload all yaras` actions.
- All actions migrated from the legacy `BaseConnector` pattern to the
  decorator-based SDK 3.x model with typed `Params`, `ActionOutput`,
  and `Asset` classes.
