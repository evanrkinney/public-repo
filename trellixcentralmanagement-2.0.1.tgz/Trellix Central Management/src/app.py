"""Trellix Central Management - Splunk SOAR SDK app.

Provides investigative and response actions against a Trellix (formerly
FireEye) Central Management (CM) appliance: alert ingestion, email
quarantine management, and YARA rule upload.
"""

import os
import tempfile
import traceback
from datetime import UTC, datetime, timedelta
from urllib.parse import urlparse

import dateutil.parser
import requests
from soar_sdk.abstract import SOARClient
from soar_sdk.action_results import ActionOutput, OutputField
from soar_sdk.app import App
from soar_sdk.asset import AssetField, BaseAsset
from soar_sdk.exceptions import ActionFailure, AssetMisconfiguration
from soar_sdk.logging import getLogger
from soar_sdk.models import Artifact, Container
from soar_sdk.params import OnPollParams, Param, Params


logger = getLogger()
logger.info("trellixcentralmanagement module loading.")


CM_BASE_PATH = "/wsapis/v2.0.0"
CM_AUTH_LOGIN_URL = f"{CM_BASE_PATH}/auth/login"
CM_AUTH_LOGOUT_URL = f"{CM_BASE_PATH}/auth/logout"
CM_ALERTS_URL = f"{CM_BASE_PATH}/alerts"
CM_ALERT_URL = f"{CM_BASE_PATH}/alerts/alert/"
CM_EMAILMGMT_QUARANTINE = f"{CM_BASE_PATH}/emailmgmt/quarantine"
CM_EMAILMGMT_QUARANTINE_RELEASE = f"{CM_BASE_PATH}/emailmgmt/quarantine/release"
CM_YARA_UPLOAD_URL = f"{CM_BASE_PATH}/customioc/yara/add"

CM_TOKEN_HEADER = "X-FeApi-Token"
CM_CLIENT_TOKEN_HEADER = "X-FeClient-Token"

_USER_AGENT = "splunk-soar-trellixcentralmanagement/2.0"

# (connect, read) timeouts in seconds. Short connect timeout so a wedged
# proxy/firewall surfaces as a fast failure instead of hanging on TCP.
_CONNECT_TIMEOUT = 15
_READ_TIMEOUT = 60
_LOGIN_TIMEOUT = (_CONNECT_TIMEOUT, _READ_TIMEOUT)

CM_PRODUCTS_MAP = {"EX": "EMAIL_MPS", "NX": "WEB_MPS", "AX": "MAS"}
CM_PRODUCTS_MAP_REVERSE = {v: k for k, v in CM_PRODUCTS_MAP.items()}

YARA_FILE_EXTENSIONS = (".yar", ".yara", ".yr")


class Asset(BaseAsset):
    server_url: str = AssetField(
        description="CM Server URL (e.g. https://cm.example.com).",
    )
    username: str = AssetField(
        description="CM Username.",
    )
    password: str = AssetField(
        description="CM Password.",
        sensitive=True,
    )
    client_token: str | None = AssetField(
        description="CM Client Token (optional).",
        sensitive=True,
        default=None,
    )
    verify_ssl: bool = AssetField(
        description="Verify SSL Certificate.",
        default=False,
    )
    product_filter: str | None = AssetField(
        description="On-Poll Product Filter (comma-separated, e.g. 'EX,NX,AX').",
        default=None,
    )
    include_riskware: bool = AssetField(
        description="On-Poll: include riskware alerts.",
        default=False,
    )
    http_proxy: str | None = AssetField(
        description=(
            "Optional outbound proxy URL (e.g. http://proxy.internal:3128). "
            "If empty, the app bypasses any system proxy and connects to the "
            "CM appliance directly. Set this ONLY if the appliance must be "
            "reached via an explicit forward proxy."
        ),
        default=None,
    )


app = App(
    asset_cls=Asset,
    name="Trellix Central Management",
    appid="b5e446c9-eb44-4991-bcbf-18945c787bee",
    app_type="ticketing",
    product_vendor="Trellix",
    product_name="Trellix Central Management",
    publisher="Splunk SOAR Community",
    logo="logo.svg",
    logo_dark="logo_dark.svg",
    min_phantom_version="7.0.0",
    fips_compliant=False,
)


class _CMSession:
    """Holds a cached auth token for a single action invocation.

    Uses a ``requests.Session`` with ``trust_env=False`` so the SOAR worker's
    HTTP_PROXY/HTTPS_PROXY/NO_PROXY/REQUESTS_CA_BUNDLE environment variables
    are ignored. A forward proxy is used only when the asset explicitly
    configures ``http_proxy``.
    """

    def __init__(self, asset: Asset):
        self.base_url = asset.server_url.rstrip("/")
        self.username = asset.username
        self.password = asset.password
        self.client_token = (asset.client_token or "").strip() or None
        self.verify_ssl = bool(asset.verify_ssl)
        self.http_proxy = (asset.http_proxy or "").strip() or None
        self._token: str | None = None

        self._session = requests.Session()
        # Critical: do NOT inherit HTTP_PROXY / HTTPS_PROXY / NO_PROXY /
        # REQUESTS_CA_BUNDLE from the SOAR worker environment. CM appliances
        # are typically reached directly on the internal network, and a
        # mis-routed system proxy is the #1 cause of test_connectivity hangs.
        self._session.trust_env = False
        self._session.verify = self.verify_ssl
        if self.http_proxy:
            self._session.proxies = {"http": self.http_proxy, "https": self.http_proxy}
            logger.warning(
                f"CM session: routing through explicit proxy {self.http_proxy!r}"
            )
        else:
            # Explicit empty mapping prevents any leakage through the
            # adapter-level proxy resolution.
            self._session.proxies = {}

    def login(self) -> str:
        url = f"{self.base_url}{CM_AUTH_LOGIN_URL}"
        headers = {"User-Agent": _USER_AGENT, "Accept": "application/json"}
        if self.client_token:
            headers[CM_CLIENT_TOKEN_HEADER] = self.client_token

        logger.info(
            f"CM login: POST {url} (verify_ssl={self.verify_ssl}, "
            f"username={self.username!r}, "
            f"client_token={'set' if self.client_token else 'not set'}, "
            f"proxy={self.http_proxy or '<none>'}, "
            f"timeout=(connect={_CONNECT_TIMEOUT}s, read={_READ_TIMEOUT}s))"
        )

        resp = self._session.post(
            url,
            auth=(self.username, self.password),
            headers=headers,
            timeout=_LOGIN_TIMEOUT,
        )

        logger.info(
            f"CM login response: status={resp.status_code} "
            f"content_type={resp.headers.get('Content-Type', '<none>')!r} "
            f"content_length={len(resp.content)}"
        )

        if not (200 <= resp.status_code < 400):
            snippet = (resp.text or "")[:500].replace("\n", " ")
            logger.warning(f"CM login non-2xx body: {snippet!r}")
            raise RuntimeError(
                f"CM login failed: HTTP {resp.status_code}. "
                f"Body: {snippet or '<empty>'}"
            )

        token = resp.headers.get(CM_TOKEN_HEADER)
        if not token:
            visible_headers = {
                k: v
                for k, v in resp.headers.items()
                if not k.lower().startswith(("set-cookie",))
            }
            logger.warning(
                f"CM login 2xx but {CM_TOKEN_HEADER!r} header missing. "
                f"Response headers: {visible_headers}"
            )
            raise RuntimeError(
                f"CM login succeeded (HTTP {resp.status_code}) but no "
                f"{CM_TOKEN_HEADER!r} header in the response. The appliance "
                f"may have returned a login page instead of the API response - "
                f"check that the URL points to the CM API root and that the "
                f"user has the api_admin or api_analyst role."
            )

        self._token = token
        logger.info("CM login: token acquired.")
        return token

    def logout(self) -> None:
        if not self._token:
            return
        url = f"{self.base_url}{CM_AUTH_LOGOUT_URL}"
        try:
            resp = self._session.post(
                url,
                headers={**self._auth_headers(), "User-Agent": _USER_AGENT},
                timeout=_LOGIN_TIMEOUT,
            )
            logger.info(f"CM logout: POST {url} status={resp.status_code}")
        except Exception as exc:
            logger.warning(f"CM logout call failed (ignored): {exc}")
        finally:
            self._token = None
            try:
                self._session.close()
            except Exception:
                pass

    def _auth_headers(self) -> dict:
        if not self._token:
            self.login()
        headers = {CM_TOKEN_HEADER: self._token, "User-Agent": _USER_AGENT}
        if self.client_token:
            headers[CM_CLIENT_TOKEN_HEADER] = self.client_token
        return headers

    def request(
        self,
        method: str,
        endpoint: str,
        *,
        params: dict | None = None,
        json_body: dict | None = None,
        files: dict | None = None,
        data: dict | None = None,
        accept: str = "application/json",
        stream: bool = False,
    ) -> requests.Response:
        headers = self._auth_headers()
        headers["Accept"] = accept
        if json_body is not None and files is None:
            headers["Content-Type"] = "application/json"
        url = f"{self.base_url}{endpoint}"
        resp = self._session.request(
            method,
            url,
            headers=headers,
            params=params,
            json=json_body,
            files=files,
            data=data,
            timeout=(_CONNECT_TIMEOUT, 180),
            stream=stream,
        )
        return resp

    def __enter__(self) -> "_CMSession":
        self.login()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        self.logout()


def _raise_for_cm_error(resp: requests.Response, action: str) -> None:
    if 200 <= resp.status_code < 400:
        return
    body = resp.text[:500] if resp.text else "<empty>"
    raise RuntimeError(f"{action} failed: HTTP {resp.status_code} {body}")


def _safe_attr(asset: Asset, name: str) -> tuple[bool, object]:
    """Read an asset attribute without raising. Returns ``(ok, value_or_error)``.

    Used in test_connectivity so we can surface a clean message even if
    Pydantic validation or attribute access raises after the action handler
    has already been entered.
    """
    try:
        return True, getattr(asset, name)
    except Exception as exc:
        return False, exc


@app.test_connectivity()
def test_connectivity(soar: SOARClient, asset: Asset) -> None:
    # ERROR-level so it lands in the persistent spawn error log
    # (logger.info goes to a progress stream that gets overwritten).
    logger.error("test_connectivity: entered")

    try:
        _do_test_connectivity(asset)
    except ActionFailure:
        # ActionFailure messages are preserved verbatim by the SDK in the
        # action result; re-raise as-is.
        raise
    except Exception as exc:
        tb = traceback.format_exc()
        logger.error(
            f"test_connectivity: unexpected {type(exc).__name__}: {exc}\n{tb}"
        )
        raise ActionFailure(
            f"Unexpected {type(exc).__name__} during test connectivity: {exc}. "
            f"Check the SOAR spawn log for the full traceback."
        ) from exc

    logger.error("test_connectivity: OK")


def _do_test_connectivity(asset: Asset) -> None:
    # Probe each asset field individually and log each result at WARNING
    # (debugprint) so it's visible in the persistent log even if something
    # downstream raises.
    for field in ("server_url", "username", "password", "client_token", "verify_ssl"):
        ok, value = _safe_attr(asset, field)
        if not ok:
            logger.error(
                f"test_connectivity: cannot read asset.{field}: "
                f"{type(value).__name__}: {value}"
            )
            raise AssetMisconfiguration(
                f"Could not read asset.{field}: {value}. The asset "
                f"configuration is missing or malformed for this field."
            )
        if field == "password":
            logger.warning(
                f"test_connectivity: asset.password={'set' if value else 'NOT SET'}"
            )
        elif field == "client_token":
            logger.warning(
                f"test_connectivity: asset.client_token={'set' if value else 'not set'}"
            )
        else:
            logger.warning(f"test_connectivity: asset.{field}={value!r}")

    server_url = (asset.server_url or "").strip()
    username = (asset.username or "").strip()

    if not server_url:
        raise AssetMisconfiguration("Asset 'server_url' is required.")
    if not username:
        raise AssetMisconfiguration("Asset 'username' is required.")
    if not asset.password:
        raise AssetMisconfiguration("Asset 'password' is required.")

    parsed = urlparse(server_url)
    if not parsed.scheme:
        raise AssetMisconfiguration(
            f"server_url {server_url!r} is missing a scheme. "
            f"Use 'https://hostname' (or 'http://hostname' for plaintext)."
        )
    if parsed.scheme not in ("http", "https"):
        raise AssetMisconfiguration(
            f"server_url {server_url!r} has unsupported scheme "
            f"{parsed.scheme!r}; only http and https are supported."
        )
    if not parsed.netloc:
        raise AssetMisconfiguration(f"server_url {server_url!r} has no host.")

    logger.warning(
        f"test_connectivity: parsed scheme={parsed.scheme} host={parsed.hostname!r} "
        f"port={parsed.port} path={parsed.path!r}"
    )

    if parsed.path and parsed.path.rstrip("/"):
        logger.warning(
            f"test_connectivity: server_url contains a path component "
            f"({parsed.path!r}); the API base path '{CM_BASE_PATH}' will be "
            f"appended to it. Set server_url to the appliance root (e.g. "
            f"'https://cm.example.com') if test connectivity fails with a 404."
        )

    # --- Proxy / environment diagnostics -----------------------------------
    env_http = os.environ.get("HTTP_PROXY") or os.environ.get("http_proxy")
    env_https = os.environ.get("HTTPS_PROXY") or os.environ.get("https_proxy")
    env_no_proxy = os.environ.get("NO_PROXY") or os.environ.get("no_proxy")
    if env_http or env_https:
        logger.warning(
            f"test_connectivity: SOAR worker env has HTTP_PROXY="
            f"{env_http or '<unset>'} HTTPS_PROXY={env_https or '<unset>'} "
            f"NO_PROXY={env_no_proxy or '<unset>'}. The app IGNORES these "
            f"by default (trust_env=False) and connects directly. Set the "
            f"asset's 'http_proxy' field if you actually need to route "
            f"through a proxy."
        )
    explicit_proxy = (asset.http_proxy or "").strip()
    if explicit_proxy:
        logger.warning(
            f"test_connectivity: explicit asset http_proxy is set: "
            f"{explicit_proxy!r}. CM traffic will be routed through this "
            f"proxy."
        )
    else:
        logger.warning(
            "test_connectivity: no explicit proxy; connecting directly to "
            "the CM appliance."
        )

    # --- DNS probe ---------------------------------------------------------
    # When test_connectivity hangs, the cause is almost always at the
    # transport layer: DNS resolution stalls, or a TCP SYN goes to a proxy
    # that can't route to the appliance. Resolving here surfaces a fast,
    # specific error before we get to the slow login POST.
    if not explicit_proxy:
        import socket

        host = parsed.hostname
        port = parsed.port or (443 if parsed.scheme == "https" else 80)
        logger.warning(f"test_connectivity: DNS probe for {host}:{port}...")
        try:
            socket.setdefaulttimeout(_CONNECT_TIMEOUT)
            infos = socket.getaddrinfo(host, port, type=socket.SOCK_STREAM)
            resolved = sorted({i[4][0] for i in infos})
            logger.warning(
                f"test_connectivity: DNS resolved {host} -> {resolved}"
            )
        except socket.gaierror as exc:
            raise ActionFailure(
                f"DNS lookup failed for {host!r}: {exc}. The SOAR worker "
                f"cannot resolve this hostname. Verify the server_url is "
                f"correct and that the SOAR worker can reach a DNS server "
                f"that knows about this appliance (or use an IP literal "
                f"like 'https://10.1.2.3')."
            ) from exc
        except OSError as exc:
            logger.warning(
                f"test_connectivity: DNS probe non-fatal error: {exc}"
            )
        finally:
            socket.setdefaulttimeout(None)

    if not asset.verify_ssl:
        logger.warning(
            "test_connectivity: SSL certificate verification is DISABLED. "
            "Traffic is encrypted, but the server certificate is not validated."
        )
        try:
            import urllib3

            urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
        except Exception as exc:
            logger.warning(
                f"test_connectivity: could not suppress InsecureRequestWarning: {exc}"
            )

    logger.warning("test_connectivity: attempting CM login...")
    session = _CMSession(asset)

    try:
        session.login()
    except requests.exceptions.SSLError as exc:
        raise ActionFailure(
            f"TLS certificate verification failed for {parsed.netloc}: {exc}. "
            f"If the appliance uses a self-signed or internal-CA certificate, "
            f"set the asset's 'verify_ssl' to False (or install the appliance "
            f"CA on the SOAR worker)."
        ) from exc
    except requests.exceptions.ProxyError as exc:
        if explicit_proxy:
            raise ActionFailure(
                f"Proxy {explicit_proxy!r} failed to connect to "
                f"{parsed.netloc}: {exc}. Verify the proxy URL/credentials "
                f"and that the proxy can route to the CM appliance."
            ) from exc
        # If we get a ProxyError when no asset-level proxy is set, something
        # is intercepting outbound traffic (corporate egress proxy, etc.).
        raise ActionFailure(
            f"A proxy intercepted the connection to {parsed.netloc} even "
            f"though no proxy is configured on the asset: {exc}. Either "
            f"set the asset's 'http_proxy' to the correct proxy URL, or "
            f"have your network team allow direct egress from the SOAR "
            f"worker to the CM appliance."
        ) from exc
    except requests.exceptions.ConnectTimeout as exc:
        hint = (
            f"explicit proxy {explicit_proxy!r}"
            if explicit_proxy
            else "the appliance directly (no proxy)"
        )
        raise ActionFailure(
            f"Connection to {parsed.netloc} timed out after "
            f"{_CONNECT_TIMEOUT}s (connecting via {hint}): {exc}. Verify "
            f"the appliance is reachable from the SOAR worker (firewall, "
            f"VPN, routing) and that the port is open."
        ) from exc
    except requests.exceptions.ReadTimeout as exc:
        raise ActionFailure(
            f"Read from {parsed.netloc} timed out after {_READ_TIMEOUT}s: "
            f"{exc}. The appliance accepted the TCP connection but did not "
            f"respond to the login POST in time."
        ) from exc
    except requests.exceptions.ConnectionError as exc:
        raise ActionFailure(
            f"Could not connect to {parsed.netloc}: {exc}. Check the "
            f"server_url (DNS, hostname, port) and that the appliance is "
            f"reachable from the SOAR worker."
        ) from exc
    except requests.exceptions.MissingSchema as exc:
        raise AssetMisconfiguration(
            f"server_url is malformed: {exc}. Use the full URL including "
            f"scheme, e.g. 'https://cm.example.com'."
        ) from exc
    except requests.exceptions.InvalidURL as exc:
        raise AssetMisconfiguration(f"server_url is invalid: {exc}.") from exc
    except RuntimeError as exc:
        # _CMSession.login raises RuntimeError with a detailed message for
        # HTTP-level failures (non-2xx, missing token header). Surface that
        # message verbatim instead of wrapping it in a traceback.
        raise ActionFailure(str(exc)) from exc

    logger.warning("test_connectivity: CM login succeeded; releasing token.")
    session.logout()


def _retrieve_alerts(
    session: _CMSession,
    since: datetime,
    include_riskware: bool,
    limit: int | None,
) -> list[dict]:
    date = since.astimezone().isoformat(timespec="milliseconds")
    params = {"start_time": date, "duration": "48_hours", "info_level": "concise"}
    if include_riskware:
        params["include_riskware"] = "true"

    resp = session.request("get", CM_ALERTS_URL, params=params)
    _raise_for_cm_error(resp, "retrieve alerts")
    body = resp.json() if resp.text else {}
    alerts = body.get("alert") or []
    if limit:
        alerts = alerts[:limit]
    return alerts


def _alert_container(alert: dict) -> Container:
    alert_id = alert["id"]
    secondary = alert.get("name") or ""
    product_code = CM_PRODUCTS_MAP_REVERSE.get(alert.get("product", ""), alert.get("product", ""))
    return Container(
        name=f"{alert_id} - {secondary} - {product_code}",
        description=secondary or f"Trellix CM alert {alert_id}",
        label="events",
        source_data_identifier=str(alert_id),
        severity="medium",
        data=alert,
    )


def _alert_artifact(alert: dict) -> Artifact:
    product_code = CM_PRODUCTS_MAP_REVERSE.get(alert.get("product", ""), alert.get("product", "CM"))
    return Artifact(
        name="Trellix CM Artifact",
        label=f"Trellix {product_code}",
        source_data_identifier=str(alert["id"]),
        cef=alert,
        cef_types={"id": ["trellix cm alert id"]},
    )


@app.on_poll()
def on_poll(params: OnPollParams, soar: SOARClient, asset: Asset):
    logger.info("=> ACTION START: on_poll")

    last_run_str: str | None = None
    try:
        last_run_str = asset.ingest_state.get("last_run")
    except Exception as exc:
        logger.warning(f"Could not read ingest_state.last_run: {exc}")

    backfill = datetime.now(UTC).astimezone() - timedelta(days=2)
    is_manual = params.is_manual_poll()

    if is_manual or not last_run_str:
        since = backfill
    else:
        try:
            since = dateutil.parser.isoparse(last_run_str)
        except (ValueError, TypeError):
            logger.warning(f"Could not parse last_run={last_run_str!r}; backfilling.")
            since = backfill

    product_filter_codes: list[str] = []
    raw_filter = (asset.product_filter or "").strip()
    if raw_filter:
        for value in raw_filter.split(","):
            v = value.strip()
            if not v:
                continue
            product_filter_codes.append(CM_PRODUCTS_MAP.get(v, v))

    this_run = datetime.now(UTC).astimezone().isoformat(timespec="milliseconds")

    with _CMSession(asset) as session:
        alerts = _retrieve_alerts(
            session, since, asset.include_riskware, params.container_count
        )

    logger.info(f"Retrieved {len(alerts)} alerts since {since.isoformat()}")
    soar.set_message(f"Retrieved {len(alerts)} alerts")

    for alert in alerts:
        if product_filter_codes and alert.get("product") not in product_filter_codes:
            continue
        yield _alert_container(alert)
        yield _alert_artifact(alert)

    try:
        asset.ingest_state["last_run"] = this_run
    except Exception as exc:
        logger.warning(f"Could not persist on_poll last_run: {exc}")


class ListQuarantinedEmailsParams(Params):
    start_time: str | None = Param(description="Start Time.", default=None)
    end_time: str | None = Param(description="End Time.", default=None)
    mail_from: str | None = Param(
        description="Filter by sender (the 'from' field).",
        cef_types=["email"],
        default=None,
    )
    subject: str | None = Param(description="Filter by email subject.", default=None)
    appliance_id: str | None = Param(
        description="Filter by appliance ID.",
        cef_types=["trellix cm appliance id"],
        default=None,
    )


class QuarantinedEmailOutput(ActionOutput):
    queue_id: str = OutputField(
        cef_types=["trellix cm email queue"],
        column_name="Queue ID",
        example_values=["1.MTM0NA=="],
    )
    email_uuid: str | None = OutputField(
        cef_types=["trellix cm email uuid"],
        column_name="Email UUID",
    )
    message_id: str | None = OutputField(column_name="Message ID")
    completed_at: str | None = OutputField(column_name="Completed At")
    mail_from: str | None = OutputField(column_name="From")
    subject: str | None = OutputField(column_name="Subject")


@app.action(
    name="list quarantined emails",
    identifier="list_quarantined_emails",
    description="Retrieves information about quarantined emails.",
    action_type="investigate",
    read_only=True,
)
def list_quarantined_emails(
    params: ListQuarantinedEmailsParams, soar: SOARClient, asset: Asset
) -> list[QuarantinedEmailOutput]:
    logger.info("=> ACTION START: list_quarantined_emails")

    if (params.start_time and not params.end_time) or (params.end_time and not params.start_time):
        raise ValueError("Must provide both start_time and end_time.")

    query: dict = {}
    if params.start_time:
        query["start_time"] = params.start_time
    if params.end_time:
        query["end_time"] = params.end_time
    if params.mail_from:
        query["from"] = params.mail_from
    if params.subject:
        query["subject"] = params.subject
    if params.appliance_id:
        query["appliance_id"] = params.appliance_id

    with _CMSession(asset) as session:
        resp = session.request("get", CM_EMAILMGMT_QUARANTINE, params=query)
        _raise_for_cm_error(resp, "list quarantined emails")
        emails = resp.json() if resp.text else []

    results: list[QuarantinedEmailOutput] = []
    if isinstance(emails, list):
        for email in emails:
            results.append(
                QuarantinedEmailOutput(
                    queue_id=str(email.get("queue_id") or ""),
                    email_uuid=email.get("email_uuid"),
                    message_id=email.get("message_id"),
                    completed_at=email.get("completed_at"),
                    mail_from=email.get("from"),
                    subject=email.get("subject"),
                )
            )

    soar.set_message(f"Retrieved {len(results)} quarantined email(s)")
    return results


class GetQuarantinedEmailParams(Params):
    queue_id: str = Param(
        description="Queue ID of the quarantined email.",
        cef_types=["trellix cm email queue"],
        primary=True,
    )
    sensor_name: str = Param(description="The sensor display name.")


class GetQuarantinedEmailOutput(ActionOutput):
    vault_id: str = OutputField(
        column_name="Vault ID",
        cef_types=["vault id"],
    )
    file_name: str = OutputField(column_name="File Name")


@app.action(
    name="get quarantined email",
    identifier="get_quarantined_email",
    description="Save an individual quarantined email to the SOAR Vault.",
    action_type="investigate",
    read_only=True,
)
def get_quarantined_email(
    params: GetQuarantinedEmailParams, soar: SOARClient, asset: Asset
) -> GetQuarantinedEmailOutput:
    logger.info(f"=> ACTION START: get_quarantined_email queue_id={params.queue_id}")
    queue_id = params.queue_id
    file_name = f"{queue_id}.eml"

    container_id = int(soar.get_executing_container_id() or 0)
    if not container_id:
        raise ValueError(
            "get quarantined email must be invoked from a playbook with a "
            "container context."
        )

    with _CMSession(asset) as session:
        resp = session.request(
            "get",
            f"{CM_EMAILMGMT_QUARANTINE}/{queue_id}",
            params={"sensorName": params.sensor_name},
            accept="application/octet-stream",
            stream=True,
        )
        _raise_for_cm_error(resp, "get quarantined email")

        tmp_dir = _resolve_tmp_dir(soar)
        tmp_path = os.path.join(tmp_dir, file_name)
        with open(tmp_path, "wb") as fh:
            for chunk in resp.iter_content(chunk_size=8192):
                if chunk:
                    fh.write(chunk)

    try:
        vault_id = _vault_add(
            soar,
            container_id=container_id,
            file_path=tmp_path,
            file_name=file_name,
            metadata={"mime_type": "message/rfc822"},
        )
    finally:
        try:
            os.remove(tmp_path)
        except OSError:
            pass

    soar.set_message(f"Saved quarantined email to Vault as {vault_id}")
    return GetQuarantinedEmailOutput(vault_id=vault_id, file_name=file_name)


class ReleaseQuarantinedEmailsParams(Params):
    queue_ids: str = Param(
        description="Comma-separated list of Queue IDs of the quarantined emails to release.",
        cef_types=["trellix cm email queue ids"],
        primary=True,
    )
    sensor_name: str = Param(description="The sensor display name.")


class ReleaseQuarantinedEmailsOutput(ActionOutput):
    released_count: int = OutputField(
        column_name="Released Count",
        example_values=[3],
    )


@app.action(
    name="release quarantined emails",
    identifier="release_quarantined_emails",
    description="Releases and deletes quarantined emails.",
    action_type="generic",
    read_only=False,
)
def release_quarantined_emails(
    params: ReleaseQuarantinedEmailsParams, soar: SOARClient, asset: Asset
) -> ReleaseQuarantinedEmailsOutput:
    logger.info("=> ACTION START: release_quarantined_emails")
    queue_ids = [q.strip() for q in params.queue_ids.split(",") if q.strip()]
    if not queue_ids:
        raise ValueError("queue_ids must contain at least one queue ID.")
    if len(queue_ids) > 100:
        raise ValueError("Only up to 100 queue ids are supported for this action.")

    with _CMSession(asset) as session:
        resp = session.request(
            "post",
            CM_EMAILMGMT_QUARANTINE_RELEASE,
            params={"sensorName": params.sensor_name},
            json_body={"queue_ids": queue_ids},
        )
        _raise_for_cm_error(resp, "release quarantined emails")

    soar.set_message(f"Released {len(queue_ids)} quarantined email(s)")
    return ReleaseQuarantinedEmailsOutput(released_count=len(queue_ids))


class GetAlertParams(Params):
    id: str = Param(
        description="ID or UUID of the alert to retrieve.",
        cef_types=["trellix cm alert id"],
        primary=True,
    )


class AlertOutput(ActionOutput):
    id: str | None = OutputField(
        cef_types=["trellix cm alert id"],
        column_name="ID",
    )
    uuid: str | None = OutputField(column_name="UUID")
    name: str | None = OutputField(column_name="Name")
    action: str | None = OutputField(column_name="Action")
    occurred: str | None = OutputField(column_name="Occurred")
    appliance_id: str | None = OutputField(
        cef_types=["trellix cm appliance id"],
        column_name="Appliance ID",
    )
    attack_date: str | None = OutputField(column_name="Attack Date")
    product: str | None = OutputField(column_name="Product")
    malicious: str | None = OutputField(column_name="Malicious")


@app.action(
    name="get alert",
    identifier="get_alert",
    description="Retrieve details about an individual alert.",
    action_type="investigate",
    read_only=True,
)
def get_alert(
    params: GetAlertParams, soar: SOARClient, asset: Asset
) -> list[AlertOutput]:
    logger.info(f"=> ACTION START: get_alert id={params.id}")
    with _CMSession(asset) as session:
        resp = session.request("get", f"{CM_ALERT_URL}{params.id}")
        _raise_for_cm_error(resp, "get alert")
        body = resp.json() if resp.text else {}

    out: list[AlertOutput] = []
    for alert in body.get("alert", []) or []:
        out.append(
            AlertOutput(
                id=str(alert.get("id") or ""),
                uuid=alert.get("uuid"),
                name=alert.get("name"),
                action=alert.get("action"),
                occurred=alert.get("occurred"),
                appliance_id=alert.get("applianceId"),
                attack_date=alert.get("attackDate"),
                product=alert.get("product"),
                malicious=alert.get("malicious"),
            )
        )

    soar.set_message(f"Retrieved {len(out)} alert(s)")
    return out


class ListAlertsParams(Params):
    duration: str = Param(
        description="Specifies the time interval to search.",
        value_list=["1_hour", "2_hours", "6_hours", "12_hours", "24_hours", "48_hours"],
        default="48_hours",
    )
    info_level: str = Param(
        description="Specifies the level of information to return.",
        value_list=["concise", "normal", "extended"],
        default="normal",
    )
    start_time: str | None = Param(
        description="Start time of the search; cannot be combined with end_time.",
        default=None,
    )
    end_time: str | None = Param(
        description="End time of the search; cannot be combined with start_time.",
        default=None,
    )
    callback_domain: str | None = Param(
        description="Filter for alerts with callbacks to this domain.",
        cef_types=["domain"],
        primary=True,
        default=None,
    )
    file_name: str | None = Param(
        description="Filter for alerts with a malware file matching this name.",
        cef_types=["file name"],
        primary=True,
        default=None,
    )
    malware_name: str | None = Param(
        description="Filter for alerts with a malware of this name.",
        default=None,
    )
    malware_type: str | None = Param(
        description="Filter for alerts with a malware of this type.",
        default=None,
    )
    md5: str | None = Param(
        description="Filter for alerts with this MD5 hash.",
        cef_types=["md5", "hash"],
        primary=True,
        default=None,
    )
    recipient_email: str | None = Param(
        description="Filter for alerts with this recipient email.",
        cef_types=["email"],
        primary=True,
        default=None,
    )
    sender_email: str | None = Param(
        description="Filter for alerts with this sender email.",
        cef_types=["email"],
        primary=True,
        default=None,
    )
    src_ip: str | None = Param(
        description="Filter for alerts with this source IP.",
        cef_types=["ip"],
        primary=True,
        default=None,
    )
    dst_ip: str | None = Param(
        description="Filter for alerts with this destination IP.",
        cef_types=["ip"],
        primary=True,
        default=None,
    )
    url: str | None = Param(
        description="Filter for alerts with this URL.",
        cef_types=["url"],
        primary=True,
        default=None,
    )


@app.action(
    name="list alerts",
    identifier="list_alerts",
    description="Retrieve alerts based on provided filters.",
    action_type="investigate",
    read_only=True,
)
def list_alerts(
    params: ListAlertsParams, soar: SOARClient, asset: Asset
) -> list[AlertOutput]:
    logger.info("=> ACTION START: list_alerts")
    if params.start_time and params.end_time:
        raise ValueError("Cannot specify both start_time and end_time.")

    end_time = params.end_time
    if not params.start_time and not end_time:
        end_time = datetime.now(UTC).astimezone().isoformat(timespec="milliseconds")

    query = {
        "duration": params.duration,
        "info_level": params.info_level,
    }
    if params.start_time:
        query["start_time"] = params.start_time
    if end_time:
        query["end_time"] = end_time
    for k, v in (
        ("callback_domain", params.callback_domain),
        ("file_name", params.file_name),
        ("malware_name", params.malware_name),
        ("malware_type", params.malware_type),
        ("md5", params.md5),
        ("recipient_email", params.recipient_email),
        ("sender_email", params.sender_email),
        ("src_ip", params.src_ip),
        ("dst_ip", params.dst_ip),
        ("url", params.url),
    ):
        if v:
            query[k] = v
    if asset.include_riskware:
        query["include_riskware"] = "true"

    with _CMSession(asset) as session:
        resp = session.request("get", CM_ALERTS_URL, params=query)
        _raise_for_cm_error(resp, "list alerts")
        body = resp.json() if resp.text else {}

    out: list[AlertOutput] = []
    for alert in body.get("alert", []) or []:
        out.append(
            AlertOutput(
                id=str(alert.get("id") or ""),
                uuid=alert.get("uuid"),
                name=alert.get("name"),
                action=alert.get("action"),
                occurred=alert.get("occurred"),
                appliance_id=alert.get("applianceId"),
                attack_date=alert.get("attackDate"),
                product=alert.get("product"),
                malicious=alert.get("malicious"),
            )
        )

    soar.set_message(f"Retrieved {len(out)} alert(s); msg={body.get('msg')}")
    return out


YARA_FILE_TYPES = [
    "callback_domain",
    "domain_match",
    "exploit",
    "infection_match",
    "malware_callback",
    "malware_object",
    "uri_match",
]


class UploadYaraParams(Params):
    vault_id: str = Param(
        description="Vault ID of the YARA file to upload.",
        cef_types=["vault id"],
        primary=True,
    )
    file_type: str = Param(
        description=(
            "YARA file type the appliance will accept. Mapped into the URL "
            "path: POST /wsapis/v2.0.0/customioc/yara/add/{file_type}. The "
            "uploaded file must match this type."
        ),
        value_list=YARA_FILE_TYPES,
    )


class UploadYaraOutput(ActionOutput):
    vault_id: str = OutputField(
        column_name="Vault ID",
        cef_types=["vault id"],
    )
    file_name: str = OutputField(column_name="File Name")
    file_type: str = OutputField(column_name="File Type")
    http_status: int = OutputField(column_name="HTTP Status", example_values=[200])
    response_body: str | None = OutputField(column_name="Response Body")


class UploadAllYarasParams(Params):
    file_type: str = Param(
        description=(
            "YARA file type the appliance will accept. Mapped into the URL "
            "path: POST /wsapis/v2.0.0/customioc/yara/add/{file_type}. Every "
            "uploaded file must match this type."
        ),
        value_list=YARA_FILE_TYPES,
    )
    container_id: int | None = Param(
        description=(
            "Container to scan for YARA files. Defaults to the executing "
            "playbook's container."
        ),
        default=None,
    )


class UploadAllYarasOutput(ActionOutput):
    file_type: str = OutputField(column_name="File Type")
    container_id: int = OutputField(column_name="Container ID")
    uploaded_count: int = OutputField(column_name="Uploaded Count", example_values=[3])
    failed_count: int = OutputField(column_name="Failed Count", example_values=[0])
    skipped_count: int = OutputField(column_name="Skipped Count", example_values=[1])
    uploaded_vault_ids: list[str] = OutputField(column_name="Uploaded Vault IDs")
    failed_vault_ids: list[str] = OutputField(column_name="Failed Vault IDs")
    skipped_vault_ids: list[str] = OutputField(column_name="Skipped Vault IDs")


def _is_yara_filename(file_name: str) -> bool:
    name = (file_name or "").lower()
    return name.endswith(YARA_FILE_EXTENSIONS)


def _upload_one_yara(
    session: _CMSession,
    file_type: str,
    file_path: str,
    file_name: str,
) -> requests.Response:
    endpoint = f"{CM_YARA_UPLOAD_URL}/{file_type}"
    with open(file_path, "rb") as fh:
        files = {"file": (file_name, fh, "text/plain")}
        resp = session.request(
            "post",
            endpoint,
            files=files,
            accept="application/json",
        )
    return resp


@app.action(
    name="upload yara",
    identifier="upload_yara",
    description=(
        "Upload a single YARA rule file from the Vault to a Trellix CM "
        "appliance via POST /wsapis/v2.0.0/customioc/yara/add/{file_type}. "
        "The Vault file must be a YARA source file (.yar / .yara / .yr) "
        "whose rules match the chosen file_type."
    ),
    action_type="generic",
    read_only=False,
)
def upload_yara(
    params: UploadYaraParams, soar: SOARClient, asset: Asset
) -> UploadYaraOutput:
    logger.info(
        f"=> ACTION START: upload_yara vault_id={params.vault_id} "
        f"file_type={params.file_type}"
    )
    vault_file = _vault_get(soar, params.vault_id)
    file_name = vault_file["name"]
    file_path = vault_file["path"]

    if not _is_yara_filename(file_name):
        raise ValueError(
            f"Vault file {file_name!r} is not a YARA file. Expected one of: "
            f"{', '.join(YARA_FILE_EXTENSIONS)}"
        )

    with _CMSession(asset) as session:
        resp = _upload_one_yara(session, params.file_type, file_path, file_name)
        _raise_for_cm_error(resp, f"upload yara {file_name}")

    soar.set_message(
        f"Uploaded YARA file {file_name} as type {params.file_type}"
    )
    return UploadYaraOutput(
        vault_id=params.vault_id,
        file_name=file_name,
        file_type=params.file_type,
        http_status=resp.status_code,
        response_body=(resp.text[:500] if resp.text else None),
    )


@app.action(
    name="upload all yaras",
    identifier="upload_all_yaras",
    description=(
        "Upload every YARA rule file (.yar / .yara / .yr) present in a "
        "container's Vault to a Trellix CM appliance via POST "
        "/wsapis/v2.0.0/customioc/yara/add/{file_type}. Non-YARA files in "
        "the container are skipped; every uploaded file must match the "
        "chosen file_type."
    ),
    action_type="generic",
    read_only=False,
)
def upload_all_yaras(
    params: UploadAllYarasParams, soar: SOARClient, asset: Asset
) -> UploadAllYarasOutput:
    container_id = params.container_id or int(soar.get_executing_container_id() or 0)
    if not container_id:
        raise ValueError(
            "No container_id supplied and no executing container context "
            "available. Pass container_id to the action."
        )
    logger.info(
        f"=> ACTION START: upload_all_yaras container_id={container_id} "
        f"file_type={params.file_type}"
    )

    attachments = _vault_list_container(soar, container_id)
    if not attachments:
        soar.set_message(f"Container {container_id} has no Vault items to upload")
        return UploadAllYarasOutput(
            file_type=params.file_type,
            container_id=container_id,
            uploaded_count=0,
            failed_count=0,
            skipped_count=0,
            uploaded_vault_ids=[],
            failed_vault_ids=[],
            skipped_vault_ids=[],
        )

    uploaded: list[str] = []
    failed: list[str] = []
    skipped: list[str] = []

    with _CMSession(asset) as session:
        for att in attachments:
            vault_id = att["vault_id"]
            file_name = att["name"]
            file_path = att["path"]
            if not _is_yara_filename(file_name):
                logger.info(f"Skipping non-YARA file {file_name!r} (vault_id={vault_id})")
                skipped.append(vault_id)
                continue
            try:
                resp = _upload_one_yara(session, params.file_type, file_path, file_name)
                if 200 <= resp.status_code < 400:
                    uploaded.append(vault_id)
                else:
                    logger.warning(
                        f"YARA upload failed for {file_name!r}: "
                        f"HTTP {resp.status_code} {resp.text[:200]}"
                    )
                    failed.append(vault_id)
            except Exception as exc:
                logger.warning(f"YARA upload errored for {file_name!r}: {exc}")
                failed.append(vault_id)

    soar.set_message(
        f"Uploaded {len(uploaded)} YARA file(s) as type {params.file_type}; "
        f"skipped {len(skipped)} non-YARA; failed {len(failed)}."
    )
    return UploadAllYarasOutput(
        file_type=params.file_type,
        container_id=container_id,
        uploaded_count=len(uploaded),
        failed_count=len(failed),
        skipped_count=len(skipped),
        uploaded_vault_ids=uploaded,
        failed_vault_ids=failed,
        skipped_vault_ids=skipped,
    )


def _resolve_tmp_dir(soar: SOARClient) -> str:
    tmp_dir = soar.vault.get_vault_tmp_dir()
    try:
        os.makedirs(tmp_dir, exist_ok=True)
        return tmp_dir
    except (PermissionError, OSError):
        return tempfile.gettempdir()


def _vault_add(
    soar: SOARClient,
    *,
    container_id: int,
    file_path: str,
    file_name: str,
    metadata: dict | None = None,
) -> str:
    """Vault add helper that tolerates dict vs. tuple return shapes."""
    try:
        from phantom.vault import vault_add as _phantom_vault_add  # type: ignore
    except ImportError:
        _phantom_vault_add = None

    if _phantom_vault_add is not None:
        result = _phantom_vault_add(container_id, file_path, file_name, metadata or {})
        if isinstance(result, tuple):
            if len(result) >= 3 and result[0]:
                return str(result[2])
            raise RuntimeError(f"vault_add failed: {result}")
        if isinstance(result, dict):
            if not result.get("succeeded", True):
                raise RuntimeError(f"vault_add failed: {result.get('message')}")
            vid = result.get("vault_id") or result.get("hash")
            if not vid:
                raise RuntimeError(f"vault_add returned no vault_id: {result!r}")
            return str(vid)
        raise RuntimeError(f"vault_add returned unexpected type: {type(result).__name__}")

    return str(
        soar.vault.add_attachment(
            container_id=container_id,
            file_location=file_path,
            file_name=file_name,
            metadata=metadata or {},
        )
    )


def _vault_get(soar: SOARClient, vault_id: str) -> dict:
    """Look up a Vault file by ID; return ``{'vault_id', 'name', 'path'}``."""
    items = soar.vault.get_attachment(vault_id=vault_id)
    if not items:
        raise RuntimeError(f"Vault item {vault_id} not found.")
    att = items[0]
    return {"vault_id": att.vault_id, "name": att.name, "path": att.path}


def _vault_list_container(soar: SOARClient, container_id: int) -> list[dict]:
    """Enumerate Vault items in a container."""
    items = soar.vault.get_attachment(container_id=container_id)
    return [
        {"vault_id": att.vault_id, "name": att.name, "path": att.path}
        for att in (items or [])
    ]
